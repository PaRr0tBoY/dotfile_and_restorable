import React from '../npm/dom-chef.js';
import { isNotifications } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';
import observe from '../helpers/selector-observer.js';

function linkify(header) {
	header.append(
		React.createElement('a', { className: "color-fg-inherit", href: '/' + header.textContent.trim(),}
, header.firstChild
),
	);
}

function init(signal) {
	observe('.js-notifications-group h6', linkify, {signal});
}

void features.add(import.meta.url, {
	include: [
		isNotifications,
	],
	init,
});

/*

Test URLs:

https://github.com/notifications (Grouped by date)
https://github.com/notifications (Grouped by repo)

*/
