import { $$ } from '../npm/select-dom.js';
import delegate from '../npm/delegate-it-delegate.js';
import { hasRichTextEditor } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';

let submitting;

const prefix = '✏️ Comment - ';

function hasDraftComments() {
	// `[id^="convert-to-issue-body"]` excludes the hidden pre-filled textareas created when opening the dropdown menu of review comments
	return $$('textarea:not([id^="convert-to-issue-body"])').some(textarea =>
		textarea.value !== textarea.textContent, // Exclude comments being edited but not yet changed (and empty comment fields)
	);
}

function disableOnSubmit() {
	clearTimeout(submitting);
	submitting = window.setTimeout(() => {
		submitting = undefined;
	}, 2000);
}

function updateDocumentTitle() {
	if (submitting) {
		return;
	}

	if (document.visibilityState === 'hidden' && hasDraftComments()) {
		document.title = '✏️ Comment - ' + document.title;
	} else if (document.title.startsWith(prefix)) {
		document.title = document.title.replace(prefix, '');
	}
}

function init(signal) {
	delegate('form', 'submit', disableOnSubmit, {capture: true, signal});
	document.addEventListener('visibilitychange', updateDocumentTitle, {signal});
}

void features.add(import.meta.url, {
	include: [
		hasRichTextEditor,
	],
	init,
});

/*

Test URLs:

https://github.com/refined-github/sandbox/pull/4

*/
