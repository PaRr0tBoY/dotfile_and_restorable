import React from '../npm/dom-chef.js';
import elementReady from '../npm/element-ready.js';
import { isCommit, isPRCommit404, isPRCommit } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';
import { getCleanPathname } from '../github-helpers/index.js';

async function init() {
	let commitUrl = '/' + getCleanPathname();

	// Avoids a redirection
	if (isPRCommit()) {
		commitUrl = commitUrl.replace(/\/pull\/\d+\/commits/, '/commit');
	}

	const commitMeta = await elementReady('.commit-meta');
	commitMeta.classList.remove('no-wrap'); // #5987
	commitMeta.lastElementChild.append(
		React.createElement('span', { className: "sha-block", 'data-turbo': "false",}
, React.createElement('a', { href: `${commitUrl}.patch`, className: "sha",}, "patch")
, ' '
, React.createElement('a', { href: `${commitUrl}.diff`, className: "sha",}, "diff")
),
	);
}

void features.add(import.meta.url, {
	include: [
		isCommit,
	],
	exclude: [
		isPRCommit404,
	],
	deduplicate: 'has-rgh-inner',
	init,
});

/*

Test URLs:

- Commit:https://github.com/refined-github/refined-github/commit/132272786fdc058193e089d8c06f2a158844e101
- PR Commit: https://github.com/refined-github/refined-github/pull/7751/commits/07ddf838c211075701e9a681ab061a158b05ee79

*/
