import React from '../npm/dom-chef.js';
import LockIcon from '../npm/octicons-plain-react-components-Lock.js';
import { isLoggedIn, isConversation, isEnterprise } from '../npm/github-url-detection.js';
import elementReady from '../npm/element-ready.js';
import features from '../feature-manager.js';
import observe from '../helpers/selector-observer.js';

function LockedIndicator() {
	return (
		React.createElement('span', { title: "Locked", className: "State d-flex flex-items-center flex-shrink-0"   ,}
, React.createElement(LockIcon, { className: "flex-items-center mr-1" ,} ), "Locked"

)
	);
}

function addLock(element) {
	const classes = (element.closest('.gh-header-sticky') ? 'mr-2 ' : '') + 'mb-2 rgh-locked-issue';
	element.after(
		React.createElement(LockedIndicator, { className: classes,} ),
	);
}

async function init(signal) {
	// If reactions-menu exists, then .js-pick-reaction is the second child
	const reactions = await elementReady('.js-pick-reaction');
	if (!reactions?.matches(':first-child')) {
		return false;
	}

	observe([
		'.gh-header-meta > :first-child', // Issue title
		'.gh-header-sticky .flex-row > :first-child', // Sticky issue title
	], addLock, {signal});
}

void features.add(import.meta.url, {
	asLongAs: [
		// Logged out users never see the reactions menu used to determine lock status. This would lead to false positives.
		isLoggedIn,
	],
	include: [
		isConversation,
	],
	exclude: [
		// TODO: Find alternative detection that works even for GHE that don't have reactions enabled
		// https://github.com/refined-github/refined-github/issues/7063
		isEnterprise,
	],
	init,
});

/*

## Test URLs

- Locked issue: https://github.com/refined-github/sandbox/issues/74
- Locked PR: https://github.com/refined-github/sandbox/pull/48

*/
