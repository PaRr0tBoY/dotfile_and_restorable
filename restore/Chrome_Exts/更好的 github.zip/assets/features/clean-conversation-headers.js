import React from '../npm/dom-chef.js';
import { $ } from '../npm/select-dom.js';
import elementReady from '../npm/element-ready.js';
import ArrowLeftIcon from '../npm/octicons-plain-react-components-ArrowLeft.js';
import { isIssue, isPR, isPRConversation, isClosedPR } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';
import getDefaultBranch from '../github-helpers/get-default-branch.js';
import observe from '../helpers/selector-observer.js';

async function cleanIssueHeader(byline) {
	byline.classList.add('rgh-clean-conversation-headers', 'rgh-clean-conversation-headers-hide-author');

	// Shows on issues: octocat opened this issue on 1 Jan · [1 comments]
	// Removes on issues: octocat opened this issue on 1 Jan [·] 1 comments
	const commentCount = $('relative-time', byline).nextSibling;
	commentCount.replaceWith(React.createElement('span', null, commentCount.textContent.replace('·', '')));
}

async function cleanPrHeader(byline) {
	byline.classList.add('rgh-clean-conversation-headers');

	// Extra author name is only shown on `isPRConversation`
	// Hide if it's the same as the opener (always) or merger
	const shouldHideAuthor
		= isPRConversation()
		&& !byline.closest('.gh-header-sticky') // #7802
		&& $('.author', byline).textContent === (await elementReady('.TimelineItem .author')).textContent;

	if (shouldHideAuthor) {
		byline.classList.add('rgh-clean-conversation-headers-hide-author');
	}

	const base = $('.commit-ref', byline);
	const baseBranchDropdown = $('.commit-ref-dropdown', byline);

	// Shows on PRs: main [←] feature
	const arrowIcon = React.createElement(ArrowLeftIcon, { className: "v-align-middle mx-1" ,} );
	if (baseBranchDropdown) {
		baseBranchDropdown.after(React.createElement('span', null, arrowIcon)); // #5598
	} else {
		base.nextElementSibling.replaceChildren(arrowIcon);
	}

	const baseBranch = base.title.split(':')[1];
	const wasDefaultBranch = isClosedPR() && baseBranch === 'master';
	const isDefaultBranch = baseBranch === await getDefaultBranch();
	if (!isDefaultBranch && !wasDefaultBranch) {
		base.classList.add('rgh-clean-conversation-headers-non-default-branch');
	}
}

async function init(signal) {
	const cleanConversationHeader = isIssue() ? cleanIssueHeader : cleanPrHeader;
	observe([
		'.gh-header-meta > .flex-auto', // Real
		'.rgh-conversation-activity-filter', // Helper in case it runs first and breaks the `>` selector, because it wraps the .flex-auto element
	], cleanConversationHeader, {signal});
}

void features.add(import.meta.url, {
	include: [
		isIssue,
		isPR,
	],
	init,
});

/* Test URLs

- Open PR (default branch): https://github.com/refined-github/sandbox/pull/4
- Open PR (non-default branch): https://github.com/Kenshin/simpread/pull/698

- Merged PR (same author): https://github.com/sindresorhus/refined-github/pull/3402
- Merged PR (different author): https://github.com/parcel-bundler/parcel/pull/78
- Merged PR (different author + first published tag): https://github.com/sindresorhus/refined-github/pull/3227

- Closed PR: https://github.com/sindresorhus/refined-github/pull/4141

*/
