import React from '../npm/dom-chef.js';
import { $ } from '../npm/select-dom.js';
import InfoIcon from '../npm/octicons-plain-react-components-Info.js';
import elementReady from '../npm/element-ready.js';
import { isPRConversation, isOpenPR } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';
import onPrMerge from '../github-events/on-pr-merge.js';
import featureLink from '../helpers/feature-link.js';
import { canEditEveryComment } from './quick-comment-edit.js';
import { getBranches } from '../github-helpers/pr-branches.js';
import matchesAnyPattern from '../helpers/matches-any-patterns.js';

// TODO: Not an exact match; Moderators can edit comments but not create releases
const canCreateRelease = canEditEveryComment;

const exceptions = [
	'dev',
	'develop',
	'development',
	'main',
	'master',
	'next',
	'pre',
	'prod',
	'stage',
	'staging',
	/production/,
	/^release\//,
	/^v\d/,
];

async function init() {
	const deleteButton = $('[action$="/cleanup"] [type="submit"]');
	if (!deleteButton) {
		return;
	}

	if (matchesAnyPattern(getBranches().head.branch, exceptions)) {
		return;
	}

	deleteButton.dataset.disableWith = 'Auto-deleting…';
	deleteButton.click();

	const deletionEvent = await elementReady('.TimelineItem-body:has(.pull-request-ref-restore-text)', {
		stopOnDomReady: false,
		timeout: 2000,
	});

	const url = featureLink(features.getFeatureID(import.meta.url));
	deletionEvent.append(
		React.createElement('a', { className: "d-inline-block", href: url,}, "via Refined GitHub "   , React.createElement(InfoIcon, null )),
	);
}

void features.add(import.meta.url, {
	asLongAs: [
		isPRConversation,
		isOpenPR,
		canCreateRelease,
	],
	additionalListeners: [
		onPrMerge,
	],
	awaitDomReady: true, // TODO: Remove after https://github.com/refined-github/refined-github/issues/6566
	onlyAdditionalListeners: true,
	init,
});

/*

Test URLs:

1. Open https://github.com/pulls
2. Click on any PRs you can merge (in repositories without native auto-delete)
3. Merge the PR

*/
