import React from '../npm/dom-chef.js';
import { $$ } from '../npm/select-dom.js';
import { isPRConversation } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';
import { getBranches } from '../github-helpers/pr-branches.js';
import getDefaultBranch from '../github-helpers/get-default-branch.js';
import cleanCommitMessage from '../helpers/clean-commit-message.js';
import { userCanLikelyMergePR } from '../github-helpers/index.js';
import observe from '../helpers/selector-observer.js';

const isPrAgainstDefaultBranch = async () => getBranches().base.branch === await getDefaultBranch();

async function clear(messageField) {
	// Only run once so that it doesn't clear the field every time it's opened
	features.unload(import.meta.url);

	const originalMessage = messageField.value;
	const cleanedMessage = cleanCommitMessage(originalMessage, !await isPrAgainstDefaultBranch());

	if (cleanedMessage === originalMessage.trim()) {
		return false;
	}

	// Do not use `text-field-edit` #6348
	messageField.value = cleanedMessage ? cleanedMessage + '\n' : '';

	// Trigger `fit-textareas` if enabled
	messageField.dispatchEvent(new Event('input', {bubbles: true}));

	messageField.after(
		React.createElement('div', null
, React.createElement('p', { className: "note",}, "The description field was cleared by "
      , React.createElement('a', { target: "_blank", href: "https://github.com/refined-github/refined-github/wiki/Extended-feature-descriptions#clear-pr-merge-commit-message", rel: "noreferrer",}, "Refined GitHub" ), "."
)
, React.createElement('hr', null )
),
	);
}

function init(signal) {
	observe('textarea#merge_message_field', clear, {signal});
}

void features.add(import.meta.url, {
	asLongAs: [
		userCanLikelyMergePR,
	],
	include: [
		isPRConversation,
	],
	exclude: [
		// Don't clear 1-commit PRs #3140
		() => $$('.TimelineItem.js-commit').length === 1,
	],
	awaitDomReady: true, // Appears near the end of the page anyway
	init,
});

/*

Test URLs

PR against non-default branch:
https://github.com/refined-github/sandbox/pull/53

*/
