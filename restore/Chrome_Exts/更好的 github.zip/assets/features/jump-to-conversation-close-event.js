import React from '../npm/dom-chef.js';
import { any } from '../npm/code-tag.js';
import { lastElement } from '../npm/select-dom.js';
import { isConversation, isClosedIssue, isClosedPR } from '../npm/github-url-detection.js';
import { wrap } from '../helpers/dom-utils.js';
import features from '../feature-manager.js';
import observe from '../helpers/selector-observer.js';

const closedOrMergedMarkerSelector = any`
	#partial-discussion-header :is(
		[title^="Status: Closed"],
		[title^="Status: Merged"]
	)
`;

function getLastCloseEvent() {
	return lastElement(`
		.TimelineItem-badge :is(
			.octicon-issue-closed,
			.octicon-git-merge,
			.octicon-git-pull-request-closed,
			.octicon-skip
		)
	`).closest('.TimelineItem') ?? undefined;
}

function addToConversation(discussionHeader) {
	// Avoid native `title` by disabling pointer events, we have our own `aria-label`. We can't drop the `title` attribute because some features depend on it.
	discussionHeader.style.pointerEvents = 'none';

	wrap(
		discussionHeader,
		React.createElement('a', {
			'aria-label': "Scroll to most recent close event"     ,
			className: "tooltipped tooltipped-s" ,
			href: '#' + getLastCloseEvent().id,}
		),
	);
}

function init(signal) {
	observe(
		closedOrMergedMarkerSelector,
		addToConversation,
		{signal},
	);
}

void features.add(import.meta.url, {
	asLongAs: [
		isConversation,
	],
	include: [
		isClosedIssue,
		isClosedPR,
	],
	awaitDomReady: true, // We're specifically looking for the last event
	init,
});

/*
## Test URLs
Closed Issue: https://github.com/refined-github/sandbox/issues/2
Closed Issue (Not Planned): https://github.com/refined-github/sandbox/issues/24
Merged PR: https://github.com/refined-github/sandbox/pull/23
Closed PR: https://github.com/refined-github/sandbox/pull/22
*/

export { closedOrMergedMarkerSelector, getLastCloseEvent };
