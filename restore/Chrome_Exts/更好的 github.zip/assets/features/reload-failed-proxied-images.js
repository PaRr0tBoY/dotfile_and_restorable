import delay from '../npm/delay.js';
import onetime from '../npm/onetime.js';
import delegate from '../npm/delegate-it-delegate.js';
import features from '../feature-manager.js';

async function handleErroredImage({delegateTarget}) {
	console.log('Refined GitHub: image failed loading, will retry', delegateTarget.src);

	await delay(5000);
	try {
		// A clone image retries downloading
		const cloned = delegateTarget.cloneNode();
		await cloned.decode();
		// If successfully loaded, the failed image will be replaced.
		delegateTarget.replaceWith(cloned);
	} catch {}
}

function init(signal) {
	delegate('img[src^="https://camo.githubusercontent.com/"]', 'error', handleErroredImage, {capture: true, signal});
}

void features.add(import.meta.url, {
	init: onetime(init),
});

/*

Test URLs:

1. https://github.com/refined-github/sandbox/blob/7416/7416.md
2. See log in console

*/
