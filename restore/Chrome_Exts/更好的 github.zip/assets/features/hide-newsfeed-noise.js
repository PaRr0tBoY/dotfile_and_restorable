import { isDashboard } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url, [isDashboard]);

/*
Test URLs:

- https://github.com/
- https://github.com/orgs/refined-github/dashboard

*/
