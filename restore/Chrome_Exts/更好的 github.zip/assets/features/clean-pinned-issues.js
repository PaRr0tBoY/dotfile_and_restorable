import { isRepoIssueList } from '../npm/github-url-detection.js';
import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url, [isRepoIssueList]);

/*

Test URLs:

https://github.com/refined-github/sandbox/issues
https://github.com/eslint/eslint/issues

*/
