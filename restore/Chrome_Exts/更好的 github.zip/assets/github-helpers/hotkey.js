import React from '../npm/dom-chef.js';

function registerHotkey(hotkey, action, {signal}) {
	const element = typeof action === 'string'
		? React.createElement('a', { hidden: true, href: action, 'data-hotkey': hotkey,} )
		: React.createElement('button', { hidden: true, type: "button", 'data-hotkey': hotkey, onClick: action,} );

	document.body.append(element);

	signal?.addEventListener('abort', () => {
		element.remove();
	});
}

/** Safely add a hotkey to an element, preserving any existing ones and avoiding duplicates */
function addHotkey(button, hotkey) {
	if (button) {
		const hotkeys = new Set(button.dataset.hotkey?.split(','));
		hotkeys.add(hotkey);
		button.dataset.hotkey = [...hotkeys].join(',');
	}
}

export { addHotkey, registerHotkey };
