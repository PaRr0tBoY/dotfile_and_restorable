import React from '../npm/dom-chef.js';
import { wrapAll } from '../helpers/dom-utils.js';

// Wrap a list of elements with BtnGroup + ensure each has BtnGroup-item
function groupButtons(buttons) {
	// Ensure every button has this class
	for (let button of buttons) {
		if (!button.matches('button, .btn')) {
			button.classList.add('BtnGroup-parent');
			button = button.querySelector('.btn');
		}

		button.classList.add('BtnGroup-item');
	}

	// They may already be part of a group
	let group = buttons[0].closest('.BtnGroup');

	// If it doesn't exist, wrap them in a new group
	if (!group) {
		group = React.createElement('div', { className: "BtnGroup",} );
		wrapAll(group, ...buttons);
	}

	return group;
}

export { groupButtons };
