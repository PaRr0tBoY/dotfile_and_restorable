import React from '../npm/dom-chef.js';

function TimelineItem() {
	// Classes copied from #issuecomment-new + mt-3 added
	return React.createElement('div', { className: "ml-0 pl-0 ml-md-6 pl-md-3 mt-3"    ,} );
}

export { TimelineItem as default };
