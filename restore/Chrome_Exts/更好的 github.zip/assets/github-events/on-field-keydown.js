import { elementExists } from '../npm/select-dom.js';
import delegate from '../npm/delegate-it-delegate.js';

function onFieldKeydown(selector, callback, signal) {
	delegate(selector , 'keydown', event => {
		const field = event.delegateTarget;

		// The suggester is GitHub’s autocomplete dropdown
		if (elementExists('.suggester', field.form) || event.isComposing) {
			return;
		}

		callback(event);
	}, {
		// Adds support for `esc` key; GitHub seems to use `stopPropagation` on it
		capture: true,
		signal,
	});
}

function onCommentFieldKeydown(callback, signal) {
	onFieldKeydown('.js-comment-field, #commit-description-textarea, #merge_message_field', callback, signal);
}

function onConversationTitleFieldKeydown(callback, signal) {
	onFieldKeydown('#issue_title, #pull_request_title', callback, signal);
}

function onCommitTitleFieldKeydown(callback, signal) {
	onFieldKeydown('#commit-summary-input', callback, signal);
}

export { onCommentFieldKeydown, onCommitTitleFieldKeydown, onConversationTitleFieldKeydown };
