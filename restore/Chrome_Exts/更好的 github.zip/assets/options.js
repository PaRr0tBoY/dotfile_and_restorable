import { expectElement, $$, $ } from './npm/select-dom.js';
import fitTextarea from './npm/fit-textarea.js';
import prettyBytes from './npm/pretty-bytes.js';
import { enableTabToIndent } from './npm/indent-textarea.js';
import delegate from './npm/delegate-it-delegate.js';
import { isChrome, isFirefox } from './npm/webext-detect.js';
import clearCacheHandler from './helpers/clear-cache-handler.js';
import { styleHotfixes } from './helpers/hotfix.js';
import { importedFeatures } from './feature-data.js';
import getStorageBytesInUse from './helpers/used-storage.js';
import { perDomainOptions } from './options-storage.js';
import isDevelopmentVersion from './helpers/is-development-version.js';
import { doesBrowserActionOpenOptions } from './helpers/feature-utils.js';
import { state } from './helpers/bisect.js';
import initFeatureList, { updateListDom } from './options/feature-list.js';
import initTokenValidation from './options/token-validation.js';

const supportsFieldSizing = CSS.supports('field-sizing', 'content');

let syncedForm;

const {version} = chrome.runtime.getManifest();

async function updateStorageUsage(area) {
	const storage = chrome.storage[area];
	const used = await getStorageBytesInUse(area);
	const available = storage.QUOTA_BYTES - used;
	for (const output of $$(`.storage-${area}`)) {
		output.textContent = available < 1000
			? 'FULL!'
			: available < 100_000
				? `Only ${prettyBytes(available)} available`
				: `${prettyBytes(used)} used`;
	}
}

async function findFeatureHandler(event) {
	// TODO: Add support for GHE
	const options = await perDomainOptions.getOptionsForOrigin().getAll();
	const enabledFeatures = importedFeatures.filter(featureId => options['feature:' + featureId]);
	await state.set(enabledFeatures);

	const button = event.target ;
	button.disabled = true;
	setTimeout(() => {
		button.disabled = false;
	}, 10_000);

	expectElement('#find-feature-message').hidden = false;
}

function focusFirstField({delegateTarget: section}) {
	if (section.getBoundingClientRect().bottom > window.innerHeight) {
		section.scrollIntoView({behavior: 'smooth', block: 'nearest'});
	}

	if (section.open) {
		const field = $('input, textarea', section);
		if (field) {
			field.focus({preventScroll: true});
			if (!supportsFieldSizing && field instanceof HTMLTextAreaElement) {
				// #6404
				fitTextarea(field);
			}
		}
	}
}

function updateRateLink() {
	if (isChrome()) {
		return;
	}

	expectElement('a#rate-link').href = isFirefox() ? 'https://addons.mozilla.org/en-US/firefox/addon/refined-github-' : 'https://apps.apple.com/app/id1519867270?action=write-review';
}

function isEnterprise() {
	return syncedForm.getSelectedDomain() !== 'default';
}

async function showStoredCssHotfixes() {
	const cachedCSS = await styleHotfixes.getCached(version);
	expectElement('#hotfixes-field').textContent
		= isDevelopmentVersion()
			? 'Hotfixes are not applied in the development version.'
			: isEnterprise()
				? 'Hotfixes are not applied on GitHub Enterprise.'
				: cachedCSS ?? 'No CSS found in cache.';
}

function enableToggleAll({currentTarget: button}) {
	(button ).parentElement.remove();
	for (const ui of $$('.toggle-all-features')) {
		ui.hidden = false;
	}
}

function disableAllFeatures() {
	for (const enabledFeature of $$('.feature-checkbox:checked')) {
		enabledFeature.click();
	}

	expectElement('details#features').open = true;
}

function enableAllFeatures() {
	for (const disabledFeature of $$('.feature-checkbox:not(:checked)')) {
		disabledFeature.click();
	}

	expectElement('details#features').open = true;
}

async function generateDom() {
	// Generate list
	await initFeatureList();

	// Update list from saved options
	syncedForm = await perDomainOptions.syncForm('form');

	// Decorate list
	updateListDom();

	// Only now the form is ready, we can show it
	expectElement('#js-failed').remove();

	// Enable token validation
	void initTokenValidation(syncedForm);

	// Update rate link if necessary
	updateRateLink();

	// Update storage usage info
	void updateStorageUsage('local');
	void updateStorageUsage('sync');

	// Hide non-applicable "Button link" section
	if (doesBrowserActionOpenOptions) {
		expectElement('#action').hidden = true;
	}

	// Show stored CSS hotfixes
	void showStoredCssHotfixes();

	expectElement('#version').textContent = version;
}

function addEventListeners() {
	// Update domain-dependent page content when the domain is changed
	syncedForm?.onChange(async domain => {
		// Point the link to the right domain
		expectElement('a#personal-token-link').host = domain === 'default' ? 'github.com' : domain;

		// Delay to let options load first
		setTimeout(updateListDom, 100);
	});

	// Refresh page when permissions are changed (because the dropdown selector needs to be regenerated)
	chrome.permissions.onRemoved.addListener(() => {
		location.reload();
	});
	chrome.permissions.onAdded.addListener(() => {
		location.reload();
	});

	// Update storage usage info
	chrome.storage.onChanged.addListener((_, areaName) => {
		void updateStorageUsage(areaName );
	});

	// Improve textareas editing
	enableTabToIndent('textarea');
	if (!supportsFieldSizing) {
		fitTextarea.watch('textarea');
	}

	// Automatically focus field when a section is toggled open
	delegate('details', 'toggle', focusFirstField, {capture: true});

	// Add cache clearer
	expectElement('#clear-cache').addEventListener('click', clearCacheHandler);

	// Add bisect tool
	expectElement('#find-feature').addEventListener('click', findFeatureHandler);

	// Handle "Toggle all" buttons
	expectElement('#toggle-all-features').addEventListener('click', enableToggleAll);
	expectElement('#disable-all-features').addEventListener('click', disableAllFeatures);
	expectElement('#enable-all-features').addEventListener('click', enableAllFeatures);
}

async function init() {
	await generateDom();
	addEventListeners();
}

void init();
