import createHtmlElement from './create-html-element.js';

const urlRegex = () => (/((?<!\+)https?:\/\/(?:www\.)?(?:[-\p{Letter}.]+?[.@][a-zA-Z\d]{2,}|localhost)(?:[-\w\p{Letter}.:%+~#*$!?&/=@]*?(?:,(?!\s))*?)*)/gu);
const linkify = (href, options = {}) => createHtmlElement({
	name: 'a',
	attributes: {
		href: '',
		...options.attributes,
		href,
	},
	text: options.value === undefined ? href : undefined,
	html: options.value === undefined ? undefined
		: (typeof options.value === 'function' ? options.value(href) : options.value),
});
const domify = html => document.createRange().createContextualFragment(html);
const isTruncated = (url, peek) =>
	url.endsWith('...')
	|| peek.startsWith('…');
function linkifyUrlsToDom(string, options) {
	const fragment = document.createDocumentFragment();
	const parts = string.split(urlRegex());
	for (const [index, text] of parts.entries()) {
		if (index % 2 && !isTruncated(text, parts[index + 1])) {
			fragment.append(domify(linkify(text, options)));
		} else if (text.length > 0) {
			fragment.append(text);
		}
	}
	return fragment;
}

export { linkifyUrlsToDom };
