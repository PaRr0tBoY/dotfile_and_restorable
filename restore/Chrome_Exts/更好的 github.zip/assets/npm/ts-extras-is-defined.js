function isDefined(value) {
    return value !== undefined;
}

export { isDefined };
