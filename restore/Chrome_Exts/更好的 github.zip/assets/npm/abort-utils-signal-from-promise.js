function signalFromPromise(promise) {
    const controller = new AbortController();
    promise
        .finally(() => {
        controller.abort();
    })
        .catch(() => undefined);
    return controller.signal;
}

export { signalFromPromise };
