const objectToString = Object.prototype.toString;
const uint8ArrayStringified = '[object Uint8Array]';
const arrayBufferStringified = '[object ArrayBuffer]';
function isType(value, typeConstructor, typeStringified) {
	if (!value) {
		return false;
	}
	if (value.constructor === typeConstructor) {
		return true;
	}
	return objectToString.call(value) === typeStringified;
}
function isUint8Array(value) {
	return isType(value, Uint8Array, uint8ArrayStringified);
}
function isArrayBuffer(value) {
	return isType(value, ArrayBuffer, arrayBufferStringified);
}
function isUint8ArrayOrArrayBuffer(value) {
	return isUint8Array(value) || isArrayBuffer(value);
}
function assertUint8Array(value) {
	if (!isUint8Array(value)) {
		throw new TypeError(`Expected \`Uint8Array\`, got \`${typeof value}\``);
	}
}
function assertUint8ArrayOrArrayBuffer(value) {
	if (!isUint8ArrayOrArrayBuffer(value)) {
		throw new TypeError(`Expected \`Uint8Array\` or \`ArrayBuffer\`, got \`${typeof value}\``);
	}
}
const cachedDecoders = {
	utf8: new globalThis.TextDecoder('utf8'),
};
function uint8ArrayToString(array, encoding = 'utf8') {
	assertUint8ArrayOrArrayBuffer(array);
	cachedDecoders[encoding] ??= new globalThis.TextDecoder(encoding);
	return cachedDecoders[encoding].decode(array);
}
function assertString(value) {
	if (typeof value !== 'string') {
		throw new TypeError(`Expected \`string\`, got \`${typeof value}\``);
	}
}
const cachedEncoder = new globalThis.TextEncoder();
function stringToUint8Array(string) {
	assertString(string);
	return cachedEncoder.encode(string);
}
function base64ToBase64Url(base64) {
	return base64.replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
}
function base64UrlToBase64(base64url) {
	return base64url.replaceAll('-', '+').replaceAll('_', '/');
}
const MAX_BLOCK_SIZE = 65_535;
function uint8ArrayToBase64(array, {urlSafe = false} = {}) {
	assertUint8Array(array);
	let base64;
	if (array.length < MAX_BLOCK_SIZE) {
		base64 = globalThis.btoa(String.fromCodePoint.apply(this, array));
	} else {
		base64 = '';
		for (const value of array) {
			base64 += String.fromCodePoint(value);
		}
		base64 = globalThis.btoa(base64);
	}
	return urlSafe ? base64ToBase64Url(base64) : base64;
}
function base64ToUint8Array(base64String) {
	assertString(base64String);
	return Uint8Array.from(globalThis.atob(base64UrlToBase64(base64String)), x => x.codePointAt(0));
}
function stringToBase64(string, {urlSafe = false} = {}) {
	assertString(string);
	return uint8ArrayToBase64(stringToUint8Array(string), {urlSafe});
}
function base64ToString(base64String) {
	assertString(base64String);
	return uint8ArrayToString(base64ToUint8Array(base64String));
}
Array.from({length: 256}, (_, index) => index.toString(16).padStart(2, '0'));

export { assertUint8Array, assertUint8ArrayOrArrayBuffer, base64ToString, base64ToUint8Array, isUint8Array, stringToBase64, stringToUint8Array, uint8ArrayToBase64, uint8ArrayToString };
