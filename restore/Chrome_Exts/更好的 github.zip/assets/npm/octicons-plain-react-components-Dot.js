import { createElement } from './dom-chef.js';

const DotIcon = (props) => (
  createElement('svg', {
    className: "octicon octicon-dot" ,
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 16 16"   ,
    role: "img",
    'aria-hidden': "true",
    ...props,}

    , createElement('path', { d: "M4 8a4 4 0 1 1 8 0 4 4 0 0 1-8 0Zm4-2.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"                         ,} )
  )
);

export { DotIcon as default };
