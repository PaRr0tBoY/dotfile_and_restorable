import require$$0 from './html-tags-html-tags-void.json.js';

var _void;
var hasRequired_void;
function require_void () {
	if (hasRequired_void) return _void;
	hasRequired_void = 1;
	_void = require$$0;
	return _void;
}

export { require_void as __require };
