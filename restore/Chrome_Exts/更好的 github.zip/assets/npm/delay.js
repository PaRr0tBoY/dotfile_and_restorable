const createAbortError = () => {
	const error = new Error('Delay aborted');
	error.name = 'AbortError';
	return error;
};
const clearMethods = new WeakMap();
function createDelay({clearTimeout: defaultClear, setTimeout: defaultSet} = {}) {
	return (milliseconds, {value, signal} = {}) => {
		if (signal?.aborted) {
			return Promise.reject(createAbortError());
		}
		let timeoutId;
		let settle;
		let rejectFunction;
		const clear = defaultClear ?? clearTimeout;
		const signalListener = () => {
			clear(timeoutId);
			rejectFunction(createAbortError());
		};
		const cleanup = () => {
			if (signal) {
				signal.removeEventListener('abort', signalListener);
			}
		};
		const delayPromise = new Promise((resolve, reject) => {
			settle = () => {
				cleanup();
				resolve(value);
			};
			rejectFunction = reject;
			timeoutId = (defaultSet ?? setTimeout)(settle, milliseconds);
		});
		if (signal) {
			signal.addEventListener('abort', signalListener, {once: true});
		}
		clearMethods.set(delayPromise, () => {
			clear(timeoutId);
			timeoutId = null;
			settle();
		});
		return delayPromise;
	};
}
const delay = createDelay();

export { createDelay, delay as default };
