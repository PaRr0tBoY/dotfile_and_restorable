import React from './npm/dom-chef.js';
import { elementExists, $ } from './npm/select-dom.js';
import domLoaded from './npm/dom-loaded.js';
import stripIndent from './npm/strip-indent.js';
import { is500, isPasswordConfirmation, isEnterprise, is404 } from './npm/github-url-detection.js';
import { isWebPage } from './npm/webext-detect.js';
import waitFor from './helpers/wait-for.js';
import onAbort from './helpers/abort-controller.js';
import ArrayMap from './helpers/map-of-arrays.js';
import bisectFeatures from './helpers/bisect.js';
import { isFeaturePrivate, shouldFeatureRun } from './helpers/feature-utils.js';
import optionsStorage, { isFeatureDisabled } from './options-storage.js';
import { getLocalHotfixesAsOptions, preloadSyncLocalStrings, applyStyleHotfixes, brokenFeatures, _ } from './helpers/hotfix.js';
import asyncForEach from './helpers/async-for-each.js';
import { messageBackground } from './helpers/messaging.js';

const {version} = chrome.runtime.getManifest();

const shortcutMap = new Map();
const getFeatureID = (url) => url.split('/').pop().split('.')[0] ;

const currentFeatureControllers = new ArrayMap();
const fineGrainedTokenSuggestion = 'Please use a GitHub App, OAuth App, or a personal access token with fine-grained permissions.';
const preferredMessage = 'Refined GitHub does not support per-organization fine-grained tokens. https://github.com/refined-github/refined-github/wiki/Security';

function logError(url, error) {
	const id = getFeatureID(url);
	const message = error instanceof Error ? error.message : String(error);

	if (message.endsWith(fineGrainedTokenSuggestion)) {
		console.log('ℹ️', id, '→', message.replace(fineGrainedTokenSuggestion, preferredMessage));
		return;
	}

	if (message.includes('token')) {
		console.log('ℹ️', id, '→', message);
		return;
	}

	const searchIssueUrl = new URL('https://github.com/refined-github/refined-github/issues');
	searchIssueUrl.searchParams.set('q', `is:issue is:open label:bug ${id}`);

	const newIssueUrl = new URL('https://github.com/refined-github/refined-github/issues/new');
	newIssueUrl.searchParams.set('template', '1_bug_report.yml');
	newIssueUrl.searchParams.set('title', `\`${id}\`: ${message}`);
	newIssueUrl.searchParams.set('repro', location.href);
	newIssueUrl.searchParams.set('description', [
		'```',
		String(error instanceof Error ? error.stack : error).trim(),
		'```',
	].join('\n'));

	// Don't change this to `throw Error` because Firefox doesn't show extensions' errors in the console
	console.group(`❌ ${id}`); // Safari supports only one parameter
	console.log(`📕 ${version} ${isEnterprise() ? 'GHE →' : '→'}`, error); // One parameter improves Safari formatting
	console.log('🔍 Search issue', searchIssueUrl.href);
	console.log('🚨 Report issue', newIssueUrl.href);
	console.groupEnd();
}

const log = {
	info: console.log,
	http: console.log.bind(console, '🌏'),
	error: logError,
};

// eslint-disable-next-line no-async-promise-executor -- Rule assumes we don't want to leave it pending
const globalReady = new Promise(async resolve => {
	// This file may be imported in the options
	if (!isWebPage()) {
		return;
	}

	const [options, localHotfixes, bisectedFeatures] = await Promise.all([
		optionsStorage.getAll(),
		getLocalHotfixesAsOptions(),
		bisectFeatures(),
		preloadSyncLocalStrings(),
	]);

	await waitFor(() => document.body);

	if (is500() || isPasswordConfirmation()) {
		return;
	}

	if (elementExists('[refined-github]')) {
		console.warn(stripIndent(`
			Refined GitHub has been loaded twice. This may be because:

			• You loaded the developer version, or
			• The extension just updated

			If you see this at every load, please open an issue mentioning the browser you're using and the URL where this appears.
		`));
		return;
	}

	document.documentElement.setAttribute('refined-github', '');

	// Request in the background page to avoid showing a 404 request in the console
	// https://github.com/refined-github/refined-github/issues/6433
	void messageBackground({getStyleHotfixes: true}).then(applyStyleHotfixes);

	if (options.customCSS.trim().length > 0) {
		// Review #5857 and #5493 before making changes
		document.head.append(React.createElement('style', null, options.customCSS));
	}

	if (bisectedFeatures) {
		Object.assign(options, bisectedFeatures);
	} else {
		// If features are remotely marked as "seriously breaking" by the maintainers, disable them without having to wait for proper updates to propagate #3529
		void brokenFeatures.get();
		Object.assign(options, localHotfixes);
	}

	// Create logging function
	if (!options.logging) {
		log.info = () => {/* No logging */};
	}

	if (!options.logHTTP) {
		log.http = () => {/* No logging */};
	}

	if (elementExists('body.logged-out')) {
		console.warn('Refined GitHub is only expected to work when you’re logged in to GitHub. Errors will not be shown.');
		// eslint-disable-next-line ts/no-use-before-define -- TODO: Drop in https://github.com/refined-github/refined-github/issues/7750
		features.log.error = () => {/* No logging */};
	}

	// Detect unload via two events to catch both clicks and history navigation
	// https://github.com/refined-github/refined-github/issues/6437#issuecomment-1489921988
	document.addEventListener('turbo:before-fetch-request', unloadAll); // Clicks
	document.addEventListener('turbo:visit', unloadAll); // Back/forward button

	resolve(options);
});

function castArray(value) {
	return Array.isArray(value) ? value : [value];
}

async function setupPageLoad(id, config) {
	const {asLongAs, include, exclude, init, additionalListeners, onlyAdditionalListeners, shortcuts} = config;

	if (!await shouldFeatureRun({asLongAs, include, exclude})) {
		return;
	}

	const featureController = new AbortController();
	currentFeatureControllers.append(id, featureController);

	const runFeature = async () => {
		await asyncForEach(castArray(init), async init => {
			let result;
			try {
				result = await init(featureController.signal);
				// Features can return `false` when they decide not to run on the current page
				if (result !== false && !isFeaturePrivate(id)) {
					log.info('✅', id);
					// Register feature shortcuts
					for (const [hotkey, description] of Object.entries(shortcuts)) {
						shortcutMap.set(hotkey, description);
					}
				}
			} catch (error) {
				log.error(id, error);
			}

			if (result) {
				onAbort(featureController, result);
			}
		});
	};

	if (!onlyAdditionalListeners) {
		await runFeature();
	}

	await domLoaded; // Listeners likely need to work on the whole page
	for (const listener of additionalListeners) {
		const deinit = listener(runFeature, featureController.signal);
		if (deinit && !(deinit instanceof Promise)) {
			onAbort(featureController, deinit);
		}
	}
}












function getIdentifiers(url) {
	const id = getFeatureID(url);
	return {
		id,
		class: 'rgh-' + id,
		selector: '.rgh-' + id,
	};
}

/** Register a new feature */
async function add(url, ...loaders) {
	const id = getFeatureID(url);
	/* Feature filtering and running */
	const options = await globalReady;
	// Skip disabled features, unless the feature is private
	if (isFeatureDisabled(options, id) && !isFeaturePrivate(id)) {
		log.info('↩️', 'Skipping', id);
		return;
	}

	for (const loader of loaders) {
		// Input defaults and validation
		const {
			shortcuts = {},
			asLongAs,
			include,
			exclude,
			init,
			awaitDomReady = false,
			deduplicate = false,
			onlyAdditionalListeners = false,
			additionalListeners = [],
		} = loader;

		if (include?.length === 0) {
			throw new Error(`${id}: \`include\` cannot be an empty array, it means "run nowhere"`);
		}

		// 404 pages should only run 404-only features
		if (is404() && !include?.includes(is404) && !asLongAs?.includes(is404)) {
			continue;
		}

		const details = {
			asLongAs,
			include,
			exclude,
			init,
			additionalListeners,
			onlyAdditionalListeners,
			shortcuts,
		};
		if (awaitDomReady) {
			(async () => {
				await domLoaded;
				await setupPageLoad(id, details);
			})();
		} else {
			void setupPageLoad(id, details);
		}

		document.addEventListener('turbo:render', () => {
			if (!deduplicate || !elementExists(deduplicate)) {
				void setupPageLoad(id, details);
			}
		});
	}
}

async function addCssFeature(url, include) {
	const id = getFeatureID(url);
	void add(id, {
		include,
		init() {
			document.documentElement.setAttribute('rgh-' + id, '');
		},
	});
}

function unload(featureUrl) {
	const id = getFeatureID(featureUrl);
	for (const controller of currentFeatureControllers.get(id) ?? []) {
		controller.abort();
	}
}

function unloadAll() {
	for (const feature of currentFeatureControllers.values()) {
		for (const controller of feature) {
			controller.abort();
		}
	}

	currentFeatureControllers.clear();
}

/*
When navigating back and forth in history, GitHub will preserve the DOM changes;
This means that the old features will still be on the page and don't need to re-run.

This marks each as "processed"
*/
void add('rgh-deduplicator' , {
	awaitDomReady: true,
	async init() {
		// `await` kicks it to the next tick, after the other features have checked for 'has-rgh', so they can run once.
		await Promise.resolve();
		$('has-rgh')?.remove(); // https://github.com/refined-github/refined-github/issues/6568
		$(_`#js-repo-pjax-container, #js-pjax-container`)?.append(React.createElement('has-rgh', null ));
		$(_`turbo-frame`)?.append(React.createElement('has-rgh-inner', null )); // #4567
	},
});

const features = {
	add,
	unload,
	addCssFeature,
	log,
	shortcutMap,
	getFeatureID,
	getIdentifiers,
};

export { features as default };
