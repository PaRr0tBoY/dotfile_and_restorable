import { __require as requireEscapeGoat } from '../npm/stringify-attributes-escape-goat.js';

var escapeGoatExports = requireEscapeGoat();

export { escapeGoatExports as e };
