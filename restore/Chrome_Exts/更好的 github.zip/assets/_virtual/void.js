import { getDefaultExportFromCjs } from './_commonjsHelpers.js';
import { __require as require_void } from '../npm/html-tags-void.js';

var _voidExports = require_void();
var htmlTags = /*@__PURE__*/getDefaultExportFromCjs(_voidExports);

export { htmlTags as default };
