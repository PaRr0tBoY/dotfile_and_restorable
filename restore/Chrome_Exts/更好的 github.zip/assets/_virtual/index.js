import { __require as requireDist } from '../npm/js-abbreviation-number.js';

var distExports = requireDist();

export { distExports as d };
