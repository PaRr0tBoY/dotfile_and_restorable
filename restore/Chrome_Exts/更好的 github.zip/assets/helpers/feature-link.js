function featureLink(id) {
	return `https://github.com/refined-github/refined-github/blob/main/source/features/${id}.tsx`;
}

export { featureLink as default };
