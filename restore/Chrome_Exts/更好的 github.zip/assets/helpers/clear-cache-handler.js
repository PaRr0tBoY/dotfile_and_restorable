import { globalCache } from '../npm/webext-storage-cache.js';

async function clearCacheHandler(event) {
	await globalCache.clear();
	const button = event.target ;
	const initialText = button.textContent;
	button.textContent = 'Cache cleared!';
	button.disabled = true;
	setTimeout(() => {
		button.textContent = initialText;
		button.disabled = false;
	}, 2000);
}

export { clearCacheHandler as default };
