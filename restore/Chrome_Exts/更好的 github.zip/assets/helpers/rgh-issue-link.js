import React from '../npm/dom-chef.js';

function createRghIssueLink(issueNumber) {
	const issueUrl = getRghIssueUrl(issueNumber);
	return (
		React.createElement('a', { target: "_blank", rel: "noopener noreferrer" , 'data-hovercard-type': "issue", 'data-hovercard-url': issueUrl + '/hovercard', href: issueUrl,}, "#"
, issueNumber
)
	);
}

/** @deprecated Only use this function for dynamic URLs. For static URLs, paste the full URL string instead */
function getRghIssueUrl(issueNumber) {
	return `https://github.com/refined-github/refined-github/issues/${issueNumber}`;
}

export { createRghIssueLink as default };
