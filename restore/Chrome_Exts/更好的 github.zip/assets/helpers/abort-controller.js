function callHandle(handle) {
	if ('disconnect' in handle) { // Browser observers
		handle.disconnect();
	} else if ('abort' in handle) {
		handle.abort();
	} else if (typeof handle === 'function') {
		handle();
	}
}

function onAbort(abort, ...callbacks) {
	const signal = abort instanceof AbortController ? abort.signal : abort;
	signal.addEventListener('abort', () => {
		for (const callback of callbacks) {
			callHandle(callback);
		}
	});
}

export { onAbort as default };
