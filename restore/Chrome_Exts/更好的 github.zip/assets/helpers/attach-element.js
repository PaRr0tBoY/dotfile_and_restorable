import { $, elementExists } from '../npm/select-dom.js';
import getCallerID from './caller-id.js';
import { isDefined } from '../npm/ts-extras-is-defined.js';

function attachElement(
	// eslint-disable-next-line ts/no-restricted-types --  Allows dom traversing without requiring `!`
	anchor,
	{
		className = 'rgh-' + getCallerID(),
		append,
		prepend,
		before,
		after,
		forEach,
		allowMissingAnchor = false,
	},
) {
	const anchorElement = typeof anchor === 'string' ? $(anchor) : anchor;
	if (!anchorElement) {
		if (allowMissingAnchor) {
			return [];
		}

		throw new Error('Element not found');
	}

	if (elementExists('.' + className, anchorElement.parentElement ?? anchorElement)) {
		return [];
	}

	const call = (position, create) => {
		const element = create(anchorElement);
		element.classList.add(className);

		// Attach the created element, unless the callback already took care of that
		if (position !== 'forEach') {
			anchorElement[position](element);
		}

		return element;
	};

	return [
		append && call('append', append),
		prepend && call('prepend', prepend),
		before && call('before', before),
		after && call('after', after),
		forEach && call('forEach', forEach),
		// eslint-disable-next-line unicorn/no-array-callback-reference -- It only works this way. TS, AMIRITE?
	].filter(isDefined);
}

export { attachElement as default };
