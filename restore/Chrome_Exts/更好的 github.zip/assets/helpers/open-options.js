import { messageBackground } from './messaging.js';

function openOptions(event) {
	event.preventDefault();
	void messageBackground({openOptionsPage: true});
}

export { openOptions as default };
