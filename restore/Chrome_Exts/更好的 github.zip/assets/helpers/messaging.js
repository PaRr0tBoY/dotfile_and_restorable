import { serializeError, deserializeError } from '../npm/serialize-error.js';

/** They must return a promise to mark the message as handled */
 

function handleMessages(handlers) {
	chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
		for (const id of Object.keys(message)) {
			if (id in handlers) {
				handlers[id](message[id], sender).then(sendResponse, error => {
					sendResponse({$$error: serializeError(error)});
					throw error;
				});

				// Chrome does not support returning a promise
				return true;
			}
		}
	});
}

async function messageBackground(message) {
	const response = await chrome.runtime.sendMessage(message);
	if (response?.$$error) {
		throw new Error(response.$$error.message, {
			cause: deserializeError(response.$$error),
		});
	}

	return response;
}

export { handleMessages, messageBackground };
