// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils, saveAs */

// Reminder: chrome.runtime is the ONLY chrome API allowed inside offscreen documents.

chrome.runtime.onMessage.addListener(
    function(message) {
        if (message.target !== 'offscreen') {
            logMulti(`Target is not for offscreen (got '${message.target}')`);
            return;
        }

        logMulti(`Received ${message.command} command from service worker`);

        let worker = new Worker( utils.workerUrl('worker.js') );
        worker.addEventListener('message', function(e) {
            try {
                if (e.data.statusUpdate == null) {
                    logMulti(`Received ${e.data.command} command from worker`);
                }

                if (e.data.command == 'download') {
                    saveAs( e.data.url, e.data.filename );
                    setTimeout(function() { URL.revokeObjectURL(e.data.url); }, 60_000);

                    if ( e.data.isLast ) {
                        logMulti(`Download complete.`);
                    }
                }
                else if ( e.data.statusUpdate != null ) {
                    logMulti(`worker: ${e.data.statusUpdate}`);
                }
                else if ( e.data.error ) {
                    logMulti(`worker: ${e.data.error}`);
                }
                else {
                    e.data.target = 'background';
                    chrome.runtime.sendMessage(e.data);
                }
            }
            catch(e) {
                logMulti(e);
                throw e;
            }
        });
        worker.postMessage(message);
    }
);


function logMulti(value) {
    let msg = `offscreen: ${value}`;
    utils.logInfo(msg);
    chrome.runtime.sendMessage({
        target: 'background',
        command: 'log',
        logInfo: [ msg ]
    });
}


