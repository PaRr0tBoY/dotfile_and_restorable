// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* All filters:
     * url          (e.g., "http://www.example.com")
     * domain       (e.g., "example.com", or "news.example.com")
     * transition   (e.g., "link")
     * hour         (e.g., 0 - 23)
     * weekday      (e.g., 0 - 6)
     * monthday     (e.g., 1 - 31)
     * month        (e.g., 0-11)
     * date         (e.g., "Mon Jan 28 2013")
     * year         (e.g., "2013")
*/

class Filters {   // eslint-disable-line no-unused-vars

    constructor(json) {
        if ( json ) {
            this._filters = JSON.parse(json);
        }
        else {
            this._filters = JSON.parse(window.sessionStorage.getItem("filters")) ?? {};
        }

        // Convert milliseconds from string to int
        if (this._filters.date) {
            this._filters.date = parseInt(this._filters.date);
        }
    }

    /*
        getAll()

        Returns an array of objects for all active filters.
        Each object has the following attributes:
        * key   => filter name
        * value => filter value
        * displayValue  => The filter value formatted for displaying to the user.
    */
    getAll() {
        let all = [];
        for (let key in this._filters) {
            let value = this._filters[key];
            all.push({ key: key, value: value });
        }
        return all.length ? all : null;
    }

    /*
        set(key, value)

        Sets the value for the given filter name.
    */
    set(key, value) {
        this._filters[key] = value;
        this.save();
    }

    /*
        get(key)

        Returns the value for the given filter.
    */
    get(key) {
        return (key in this._filters ? this._filters[key] : null);
    }

    /*
        save()

        Persists the current filter state to session storage
    */
    save() {
        if ( !(window && window.sessionStorage) ) {
            throw new Error('sessionStorage is not available');
        }
        window.sessionStorage.setItem("filters", JSON.stringify( this._filters ));
    }

    /*
        remove(key)

        Deletes the value for the given filter. Changes are saved automatically.
    */
    remove(key) {
        delete this._filters[key];
        this.save();
    }

    /*
        removeAll()

        Deletes all filters. Changes are saved automatically.
    */
    removeAll() {
        this._filters = {};
        this.save();
    }

    /*
        getUrl()
        setUrl(url)

        Gets/sets the url filter.
    */
    setUrl(value) {
        this.set("url", value);
    }
    getUrl() {
        return this.get("url");
    }

    /*
        getDomain()
        setDomain(domain)

        Gets/sets the domain filter.
    */
    setDomain(value) {
        this.set("domain", value);
    }
    getDomain() {
        return this.get("domain");
    }

    /*
        getDate()
        setDate(date)

        Gets/sets the date filter.
    */
    setDate(value) {
        this.set("date", value);
    }
    getDate() {
        return this.get("date");
    }

    /*
        getHour()
        setHour(hour)

        Gets/sets the hour filter.
    */
    setHour(value) {
        this.set("hour", value);
    }
    getHour() {
        return this.get("hour");
    }

    /*
        getWeekday()
        setWeekday(weekday)

        Gets/sets the weekday filter.
    */
    setWeekday(value) {
        this.set("weekday", value);
    }
    getWeekday() {
        return this.get("weekday");
    }

    /*

        getMonthday()
        setMonthday(monthday)

        Gets/sets the monthday filter.
    */
    setMonthday(value) {
        this.set("monthday", value);
    }
    getMonthday() {
        return this.get("monthday");
    }

    /*
        getMonth()
        setMonth(month)

        Gets/sets the month filter.
    */
    setMonth(value) {
        this.set("month", value);
    }
    getMonth() {
        return this.get("month");
    }

    /*
        getTransition()
        setTransition(transition)

        Gets/sets the transition filter.
    */
    setTransition(value) {
        this.set("transition", value);
    }
    getTransition() {
        return this.get("transition");
    }

    /*
        getYear()
        setYear(year)

        Gets/sets the year filter.
    */
    setYear(value) {
        this.set("year", value);
    }
    getYear() {
        return this.get("year");
    }

    /*
        toJSON()
    */
    toJSON() {
        return JSON.stringify( this._filters );
    }
}
