// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

$(document).ready(function(){
    $("#sidebar").append('<ul id="navigation">');
    let items = [
        { name: "Trends",    page: "trends.html" },
        { name: "Search",    page: "search.html" },
        { name: "Options",   page: "options.html" },
        { name: "Changelog", page: "changelog.html" }
    ];
    
    let nav = $("#navigation");
    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let id = 'nav_' + item.name.toLowerCase();
        let url = chrome.runtime.getURL(item.page);
        let is_selected = window.location == url;

        let attrs = '';
        if (is_selected) {
            attrs = ' class="selected"';
        }
        nav.append('<li id="' + id + '"' + attrs + '>' + item.name + '</li>');

        if (!is_selected) {
            let getOnClickCallback = function(name, url) {
                return function() { 
                    if (name == "Trends") {
                        window.sessionStorage.clear();
                    }
                    window.location = url; 
                };
            };
            $('#' + id).on( 'click', getOnClickCallback(item.name, url) );
        }
    }
});
