// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/*
    All storage preferences:
        * autoBackup           => "true", "false"
        * autoBackupInterval   => \d+
        * autoBackupType       => "full", "incremental"
        * autoBackupCompression => "true", "false"
        * hourFormat           => 12, 24
        * ignoreVisitsDuration  => Float, >= 0, stored as string
        * lastAutoBackupDate    => \d+ (ms since epoch)
        * lastHistorySyncTime   => \d+ (ms since epoch)
        * limiter              => 'limiter_all' or 'limiter_\d+'
        * rollingAverage       => "true", "false"
        * rollingAveragePeriod => \d+
        * startPage            => 'search' or 'trends'
*/

// The language argument is optional; it's only used by unit tests.
class Preferences{  // eslint-disable-line no-unused-vars
    #storage;
    #locale;
    #formatters = {};
    #defaultIgnoreVisitsDuration = 2.0.toFixed(1);
    #changedKeys = [];

    constructor( storage = {}, language ) {
        this.#storage = storage;
        this.#locale = language ? language : navigator.language;
        this.#generateFormatters();
    }

    #generateFormatters() {
        let hourCycle = this.getHourFormat() == 12 ? 'h12' : 'h23';
        let locale = this.getLocale();

        this.#formatters.hourDisplayFormat         = new Intl.DateTimeFormat( locale, {hour: "numeric", hourCycle} );
        this.#formatters.weekdayDisplayLongFormat  = new Intl.DateTimeFormat( locale, {weekday: "long"} );
        this.#formatters.weekdayDisplayShortFormat = new Intl.DateTimeFormat( locale, {weekday: "short"} );
        this.#formatters.monthDisplayFormat        = new Intl.DateTimeFormat( locale, {month: "short"} );
        this.#formatters.trendsDateDisplayFormat   = new Intl.DateTimeFormat( locale, {weekday: "short", month: "long", day: "2-digit", year: "numeric"} );
        this.#formatters.searchTimeStringFormat    = new Intl.DateTimeFormat( locale, {hourCycle, hour:"numeric", minute:"2-digit", second:"2-digit"} );
        this.#formatters.searchDateDisplayFormat   = new Intl.DateTimeFormat( locale, {weekday:"long", month:"long", day:"2-digit", year:"numeric"} );
        this.#formatters.numberDisplayFormat       = new Intl.NumberFormat( locale, {style: "decimal"} );
        this.#formatters.percentDisplayFormat      = new Intl.NumberFormat( locale, {style: "percent", maximumFractionDigits:"0"} );
        this.#formatters.chartDailyFormat          = new Intl.DateTimeFormat( locale, {month: "short", day: "2-digit"} );
        this.#formatters.chartMonthlyFormat        = new Intl.DateTimeFormat( locale, {month: "short", year: "numeric"} );
        this.#formatters.chartYearlyFormat         = new Intl.DateTimeFormat( locale, {year: "numeric"} );
    }

    rollingAverage() {
        let enabled = this.#storage.rollingAverage;
        return enabled == true;
    }

    setRollingAverage(value) {
        this.#storage.rollingAverage = !!value;
        this.#changedKeys.push('rollingAverage');
    }

    rollingAveragePeriod() {
        return this.#storage.rollingAveragePeriod || 14;
    }

    setRollingAveragePeriod(value) {
        let number = parseInt(value);
        if (!isNaN(number) && number > 0) {
            this.#storage.rollingAveragePeriod = number;
            this.#changedKeys.push('rollingAveragePeriod');
        }
    }

    startPage() {
        return this.#storage.startPage || 'search';
    }

    setStartPage(value) {
        if (value == "trends" || value == "search") {
            this.#storage.startPage = value;
            this.#changedKeys.push('startPage');
        }
    }

    getLimiter() {
        return this.#storage.limiter || "limiter_all";
    }

    setLimiter(value) {
        if (value == "limiter_all" || value.match("^limiter_\\d+$") != null) {
            this.#storage.limiter = value;
            this.#changedKeys.push('limiter');
        }
    }

    getLocale() {
        return this.#locale;
    }

    getHourFormat() {
        let hourFormat = this.#storage.hourFormat;

        if (!hourFormat) {
            // Determine whether the user sees 12 or 24 hour time.
            let d = new Date();
            let timeDefault = d.toLocaleTimeString(this.#locale);
            let time12Hour  = d.toLocaleTimeString(this.#locale, {hour12: true});
            hourFormat = timeDefault == time12Hour ? 12 : 24;
            this.setHourFormat( hourFormat );
        }

        return hourFormat;
    }

    setHourFormat(newFormat) {
        if (newFormat == 12 || newFormat == 24) {
            this.#storage.hourFormat = newFormat;
            this.#generateFormatters();
            this.#changedKeys.push('hourFormat');
        }
    }

    getHourDisplay(hour24) {
        let d = new Date();
        d.setHours( hour24, 0, 0 );
        return this.#formatters.hourDisplayFormat.format(d);
    }

    // The baseDate argument is optional. It's only used by unit tests.
    getWeekdayDisplay(index, baseDate) {
        return this.#weekdayDisplay( 'weekdayDisplayLongFormat', index, baseDate );
    }

    getWeekdayShortDisplay(index, baseDate) {
        return this.#weekdayDisplay( 'weekdayDisplayShortFormat', index, baseDate );
    }

    #weekdayDisplay( key, index, baseDate ) {
        let d = baseDate ? baseDate : new Date();
        if (d.getDay() != index) {
            d.setDate( d.getDate() + (index - d.getDay()) );
        }
        return this.#formatters[key].format(d);
    }

    getMonthDisplay(index) {
        let d = new Date();
        d.setMonth( index, 1 );
        return this.#formatters.monthDisplayFormat.format(d);
    }

    getTrendsDateDisplay(milliseconds) {
        return this.#formatters.trendsDateDisplayFormat.format( new Date(milliseconds) );
    }

    getSearchDateDisplay(date) {
        return this.#formatters.searchDateDisplayFormat.format( date );
    }

    getSearchTimeString(date) {
        return this.#formatters.searchTimeStringFormat.format(date);
    }

    getNumberDisplay(number) {
        return this.#formatters.numberDisplayFormat.format( number );
    }

    getPercentDisplay(number) {
        return this.#formatters.percentDisplayFormat.format( number );
    }

    getChartDateString(date, granularity) {
        if (granularity == "yearly") {
            return this.#formatters.chartYearlyFormat.format( date );
        }
        else if (granularity == "monthly") {
            return this.#formatters.chartMonthlyFormat.format( date );
        }
        else {
            return this.#formatters.chartDailyFormat.format( date );
        }
    }

    autoBackup() {
        let enabled = this.#storage.autoBackup ?? true;
        return enabled == true;
    }

    setAutoBackup(value) {
        this.#storage.autoBackup = !!value;
        if (!value) {
            this.setLastAutoBackupDate( undefined );
        }
        this.#changedKeys.push('autoBackup');
    }

    autoBackupInterval() {
        return this.#storage.autoBackupInterval || 7;
    }

    setAutoBackupInterval(value) {
        let number = parseInt(value);
        if (!isNaN(number) && number > 0) {
            this.#storage.autoBackupInterval = number;
            this.#changedKeys.push('autoBackupInterval');
        }
    }

    autoBackupType() {
        return this.#storage.autoBackupType || 'incremental';
    }

    setAutoBackupType(value) {
        if (value == "full" || value == "incremental") {
            this.#storage.autoBackupType = value;
            this.#changedKeys.push('autoBackupType');
        }
    }

    lastAutoBackupDate() {
        let milliseconds = this.#storage.lastAutoBackupDate;
        if (milliseconds != null) {
            return new Date( parseInt(milliseconds) );
        }
        return;
    }

    setLastAutoBackupDate(value) {
        if (value instanceof Date) {
            this.#storage.lastAutoBackupDate = value.getTime();
        }
        else if (Number.isInteger(value)) {
            this.#storage.lastAutoBackupDate = value;
        }
        else if (value == undefined) {
            this.#storage.lastAutoBackupDate = null;
        }
        this.#changedKeys.push('lastAutoBackupDate');
    }

    lastHistorySyncTime() {
        let milliseconds = this.#storage.lastHistorySyncTime;
        if ( milliseconds ) {
            return parseFloat( milliseconds );
        }
        return 0;
    }

    setLastHistorySyncTime(milliseconds) {
        this.#storage.lastHistorySyncTime = milliseconds;
        this.#changedKeys.push('lastHistorySyncTime');
    }

    autoBackupCompression() {
        let enabled = this.#storage.autoBackupCompression;
        return enabled == true;
    }

    setAutoBackupCompression(value) {
        this.#storage.autoBackupCompression = !!value;
        this.#changedKeys.push('autoBackupCompression');
    }

    ignoreVisitsDurationInSeconds() {
        let value = this.#storage.ignoreVisitsDuration;
        let number = parseFloat( value );
        if ( isNaN(number) || number < 0 ) {
            number = this.#defaultIgnoreVisitsDuration;
        }
        else if ( Number.isInteger(number) ) {
            number = number.toFixed(1);     // Make integers have one decimal.
        }
        return number;
    }

    setIgnoreVisitsDurationInSeconds(value) {
        let number = parseFloat(value);
        if (isNaN(number) || number < 0) {
            number = this.#defaultIgnoreVisitsDuration;
        }
        this.#storage.ignoreVisitsDuration = number;
        this.#changedKeys.push('ignoreVisitsDuration');
    }

    storage() {
        let clone = {};
        for (const property in this.#storage) {
            clone[property] = this.#storage[property];
        }
        return clone;
    }

    async persist(callback) {
        if ( this.#changedKeys.length ) {
            let saveObj = {};
            for ( const key of this.#changedKeys ) {
                saveObj[key] = this.#storage[key];
            }
            await chrome.storage.local.set(saveObj);
            this.#changedKeys = [];
        }
        if ( callback ) {
            callback();
        }
    }

    static async fetch() {
        let storage = await chrome.storage.local.get(null);
        return new Preferences(storage);
    }
}
