// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils */

let importer = {
    prefs: null
};

importer.importHandler = async function(e, prefs) {
    importer.prefs = prefs;

    let file = e.target.files[0];
    if (!file) {
        return;
    }

    if ( file.type == "application/zip" ) {
        $("#import_error_stats").text('Zip files are not supported. Only text files can be imported.');
        $("#import_complete").show();
        return;
    }

    let worker = new Worker( utils.workerUrl('import-worker.js') );
    worker.addEventListener('message', function(e) {
        if ( e.data.type == 'error' ) {
            importer.onImportError( e.data.value );
        }
        else if ( e.data.type == 'update' ) {
            importer.updateImportProgress( e.data.value );
        }
        else if ( e.data.type == 'complete' ) {
            importer.onImportDone( e.data.value );
            worker.terminate();
        }
        else {
            importer.onImportError( "Unrecognized return value from import-worker" );
            console.error( e.data );
        }
    });

    utils.logInfo("import: begin");
    importer.startImportProgress();

    worker.postMessage({
        file: file
    });

};


importer.onImportDone = function(importState) {
    utils.logInfo("import: grand totals: " + importState.numParsed + " parsed, " + importState.numErrors + " errors");
    utils.logInfo("import: grand totals: " + 
        importState.urlsInserted + " urls inserted, " + 
        importState.visitsInserted + " visits inserted, " + 
        importState.visitsIgnored  + " visits ignored"
    );

    document.getElementById("import_progress").style.display = "none";
    document.getElementById("import_success_stats").innerHTML = chrome.i18n.getMessage(
        "import_stats", 
        [
            importer.prefs.getNumberDisplay( importState.urlsInserted ), 
            importer.prefs.getNumberDisplay( importState.visitsInserted )
        ]
    );

    if (importState.visitsIgnored) {
        document.getElementById("import_ignored_stats").innerHTML = chrome.i18n.getMessage(
            "import_ignored_stats",
            [importer.prefs.getNumberDisplay( importState.visitsIgnored )]
        );
    }

    if (importState.numErrors) {
        document.getElementById("import_error_stats").innerHTML = chrome.i18n.getMessage(
            "import_errors",
            [importer.prefs.getNumberDisplay( importState.numErrors )]
        );
    }

    document.getElementById("import_complete").style.display = "block";
};

importer.startImportProgress = function() {
    document.getElementById('import_progress').style.display = "block";

    // Hide the Import completion div, and empty the stats.
    document.getElementById('import_complete').style.display = "none";
    document.getElementById('import_success_stats').innerHTML = '';
    document.getElementById('import_ignored_stats').innerHTML = '';
    document.getElementById('import_error_stats').innerHTML = '';

    importer.updateImportProgress(0);
};

importer.updateImportProgress = function(percent) {
    document.getElementById("import_percent").innerHTML = chrome.i18n.getMessage("import_progress", [importer.prefs.getNumberDisplay(percent)]);
};


importer.onImportError = function(msg) {
    document.getElementById('import_progress').innerHTML = msg;
};
