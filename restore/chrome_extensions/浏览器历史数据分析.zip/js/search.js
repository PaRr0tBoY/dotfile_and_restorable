// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils, Preferences, Mustache, HistoryWorker */

const search = {
    worker      : null,
    prefs       : null,
    pageNumber  : 1,
    sortby      : 'newest',
    lastChecked : null,   // The checkbox most recently clicked.
    checkboxes  : null,   // An array of all the checkboxes on the current page.
    model: {    // Object responsible for performing the search.
        type              : null, // Either 'all', 'basic', 'advanced', or 'refresh'.
        criteria          : null, // Object describing what to search for. Maps input names to values. Null if type is 'all'.
        totalVisitCount   : null, // Total number of visits in the search result.
        pageVisitCount    : null, // Number of visits on the current page.
        isLastPage        : null, // 1 if true, otherwise null.
        maxVisitsPerPage  : 100,  // Max number of visits per page.
        bold_marker_start : '__htu_b_start__',
        bold_marker_end   : '__htu_b_end__'
    }
};



$(document).ready(async function() {
    search.prefs = await Preferences.fetch();
    search.worker = new HistoryWorker(search.prefs);

    search.setupSearchTips();
    search.setupDeleteVisits();
    search.setupDeleteAllResults();
    search.setupExportDialog();
    search.setupAdvancedSearch();
    search.setupDeleteCorruptedDatabase();

    // Set the click handler for clearing a search.
    $('#clear_search').on( 'click', search.clearSearch );

    // Put the cursor focus on the search box.
    $("#keywords").trigger( 'focus' );

    // On startup, sync history and display browse results.
    $('#waiting_container').show();

    search.fetchResults( 'all', null, 1, search.sortby );

    // Perform search when clicking the Go button, or when pressing enter in keywords field.
    let searchbarCallback = function() {
        search.clearAdvancedFields();
        search.submit('basic', { keywords: $('#keywords').val() });
    };
    $('#search').on( 'click', searchbarCallback );
    $('#keywords').on(
        'keyup',
        function(e) {
            if (e.which == 13) {
                searchbarCallback();
            }
        }
    );

    $('.delete_btn').on( 'click', function () { $('#confirm_delete_visits').dialog('open'); } );
    $('.cancel_btn').on( 'click', search.turnDeleteModeOff );
    $('.previous_btn').on( 'click', search.prevPageAction );
    $('.next_btn').on( 'click', search.nextPageAction );
    $('#sortby').on( 'change', search.sortByAction );
});


// Syncs history and performs a search.
search.submit = function(type, criteria, onComplete) {
    if ( type == 'basic' || type == 'advanced' ) {
        search.reset();
        if ( search.isEmptySearch( criteria ) ) {
            type = 'all';
            criteria = null;
        }
    }

    search.fetchResults( type, criteria, 1, search.sortby, onComplete );
};


search.reset = function() {
    search.pageNumber  = 1;
    search.lastChecked = null;
    search.checkboxes  = null;
    search.model.reset();

    search.turnDeleteModeOff();

    return;
};


// Performs a search.
search.fetchResults = function( type, criteria, pageNumber, sortby ) {
    // Hide bottom controls to prevent flickering when table is emptied.
    search.hideDeleteAllButton();
    $('#search_result_controls_bottom').hide();
    $('#results').hide(); // Prevents flickering of bottom border.
    $('#waiting_container').show();
    $('#alerts').remove();
    $('#results').empty();

    search.worker.run('performSearch', {
        syncHistory    : type != 'refresh',
        workerArguments: search.model.getExecuteArguments( type, criteria, pageNumber, sortby ),
        onComplete     : search.onSearchPerformed,
        onError        : search.onError,
        onStatusUpdate : function(message) {
            $('#waiting_progress').html( `${message}<span id="syncing_spinner" class="spinner-image" />` );
        }
    });
};


search.onSearchPerformed = function({ rows, isLastPage, totalVisitCount }) {
    search.model.isLastPage = isLastPage;
    search.model.pageVisitCount = rows.length;
    if ( totalVisitCount != undefined ) {
        search.model.totalVisitCount = totalVisitCount;
    }

    let last_date = '';
    let date_link_index = 0;
    
    for (let i = 0; i < rows.length; i++) {
        let item = rows[i];
        let visitTime = Number.parseFloat(item.visit_time);

        // When we reach a new day, display a header row with the full date.
        let dateObj = new Date(visitTime);
        let new_date = search.prefs.getSearchDateDisplay( dateObj );
        if (new_date != last_date) {
            ++date_link_index;
            let context = {
                newDate: new_date, 
                dateSearch: utils.dateToString( new Date(visitTime) ),
                index: date_link_index
            };
            $('#results').append( Mustache.render( $('#template-browse-divider').html(), context ) );
            last_date = new_date;
        }

        let title = item.title == null ? item.url : item.title;
        // Escape HTML and then add in the <b> tags for matching terms.
        title = utils.htmlEscape(title);
        title = title.replaceAll(search.model.bold_marker_start, '<b>');
        title = title.replaceAll(search.model.bold_marker_end, '</b>');

        let row = {
            visitTime: search.prefs.getSearchTimeString(dateObj),
            title_encoded: title,
            url: item.url,
            faviconUrl: utils.faviconURL(item.url),
            host: utils.extractHost(item.url),
            visitId: item.visitid,
            index: i+1,
            title_url_different: item.title != item.url
        };
        $('#results').append( Mustache.render( $('#template-result-row').html(), row ) );
    }

    if (rows.length) {
        search.drawSearchResultControls();

        // Apply click event to new_day dividers
        $('#results td.new_day a').on( 'click', search.dateSearchAction );

        // Apply click event to checkboxes
        search.checkboxes = $('#results input[type="checkbox"]');
        search.checkboxes.on( 'click', search.visitCheckboxAction );
    }
    else {
        // no results found
        search.addSearchResultExceptionRow( '#template-no-results-row', {} );
    }

    if ( search.model.criteria ) {
        search.showClearButton();
    }

    search.displayTemporaryAlerts();

    search.showSearchResults();

    return;
};


search.onError = function(message) {
    message = message.toString();

    if (message.match(/SQLITE_BUSY/)) {
        search.addSearchResultExceptionRow( '#template-database-locked', {} );
    }
    else {
        if (message.match(/corrupt/i) && !$('#faq_corrupt_link').length) {
            search.showCorruptionAlert();
        }
        search.addSearchResultExceptionRow( '#template-error-row', { error_message: message } );
    }

    utils.logError('Search error: ' + message);
    search.showSearchResults();
};


search.model.getExecuteArguments = function( searchType, searchCriteria, pageNumber, sortby ) {
    if ( searchType == 'all' ) {
        search.model.type = searchType;
        search.model.criteria = null;
        pageNumber = 1;
    }
    else if ( searchType == 'basic' || searchType == 'advanced' ) {
        search.model.type = searchType;
        search.model.criteria = searchCriteria;
        pageNumber = 1;
    }
    else {  // searchType == 'refresh'
        // Reuse the existing type and criteria, with the new pageNumber.
    }

    let sqlAndBinds = search.model.getSqlAndBinds( sortby );

    return {
        sql: sqlAndBinds.sql,
        binds: sqlAndBinds.binds,
        pageNumber: pageNumber,
        needsTotalVisitCount: (searchType == 'basic' || searchType == 'advanced'),
        maxVisitsPerPage: search.model.maxVisitsPerPage
    };
};


search.model.reset = function() {
    search.model.type = null;
    search.model.criteria = null;
    search.model.totalVisitCount = null;
    search.model.pageVisitCount = null;
    search.model.isLastPage = null;
};


search.model.getSqlAndBinds = function( sortby ) {
    let criteria = search.model.criteria;
    if ( search.model.type == 'basic' && criteria && criteria.keywords ) {
        criteria = utils.extractDateFromKeywords( criteria.keywords );
    }

    let whereFragments = [];
    let binds = [];
    let query = criteria || {};
    let ftsFragments = [];

    if ( query.keywords != undefined && query.keywords.length ) {
        try {
            ftsFragments.push('search_urls MATCH ?');
            let fts5query = utils.keywordsToFTS5Query( query.keywords );
            binds.push( fts5query );
        }
        catch (e) {
            search.onError(e.message);
            throw e;
        }
    }

    if ( query.date != undefined && query.date.length ) {
        whereFragments.push( "v.visit_date = ?" );
        binds.push( query.date );
    }

    if ( query.fromdate != undefined && query.fromdate.length ) {
        whereFragments.push("v.visit_date >= ?" );
        binds.push( query.fromdate );
    }

    if ( query.todate != undefined && query.todate.length ) {
        whereFragments.push("v.visit_date <= ?" );
        binds.push( query.todate );
    }

    if ( query.years != undefined && query.years.length ) {
        whereFragments.push("v.year IN (" + utils.arrayToBindString( query.years ) + ")");
        binds = binds.concat( query.years );
    }

    if ( query.monthdays != undefined && query.monthdays.length ) {
        whereFragments.push("v.month_day IN (" + utils.arrayToBindString( query.monthdays ) + ")");
        binds = binds.concat( query.monthdays );
    }

    if ( query.weekdays != undefined && query.weekdays.length ) {
        whereFragments.push("v.week_day IN (" + utils.arrayToBindString( query.weekdays ) + ")");
        binds = binds.concat( query.weekdays );
    }

    if ( query.months != undefined && query.months.length ) {
        whereFragments.push("v.month IN (" + utils.arrayToBindString( query.months ) + ")");
        binds = binds.concat( query.months );
    }

    if ( query.hours != undefined && query.hours.length ) {
        whereFragments.push("v.hour IN (" + utils.arrayToBindString( query.hours ) + ")");
        binds = binds.concat( query.hours );
    }

    if ( query.transitions != undefined && query.transitions.length ) {
        whereFragments.push("v.transition_type IN (" + utils.arrayToBindString( query.transitions ) + ")");
        binds = binds.concat( query.transitions );
    }

    if ( query.urls != undefined && query.urls.length ) {
        whereFragments.push("u.url IN (" + utils.arrayToBindString( query.urls ) + ")");
        binds = binds.concat( query.urls );
    }

    if ( query.domains != undefined && query.domains.length ) {
        let domainClauses = [];
        for (let i = 0; i < query.domains.length; i++) {
            let domain = query.domains[i];
            if ( domain.match( /^=/ ) ) {
                domainClauses.push( "u.host = ?" );
                binds.push( domain.replace( /^=/, '' ) );
            }
            else {
                domainClauses.push( "(u.host = ? OR u.host LIKE '%.' || ?)" );
                binds.push( domain, domain );
            }
        }
        whereFragments.push( '(' + domainClauses.join(" OR ") + ')' );
    }

    if ( query.title != undefined && query.title.length ) {
        try {
            ftsFragments.push('title MATCH ?');
            let fts5query = utils.keywordsToFTS5Query( query.title );
            binds.push( fts5query );
        }
        catch (e) {
            search.onError(e.message);
            throw e;
        }
    }

    let whereSql = '';
    if ( whereFragments.length ) {
        whereSql = 'WHERE ' + whereFragments.join(' AND ');
    }

    let orderBySql = 'ORDER BY v.visit_time';
    if ( sortby != undefined && sortby == 'oldest' ) {
        orderBySql += ' ASC';
    }
    else {
        orderBySql += ' DESC';
    }
    orderBySql += ", u.root_domain, u.host, u.url";

    let selectSql = '';
    let fromSql = '';
    if ( ftsFragments.length ) {
        selectSql = "SELECT u.url, ifnull(matches.title,matches.url) AS title, v.visitid, v.visit_time"; // Use title from matches subquery.
        fromSql = `
FROM
(
    SELECT
        rowid AS urlid,
        highlight(search_urls, 1, '${search.model.bold_marker_start}', '${search.model.bold_marker_end}') AS title,
        highlight(search_urls, 0, '${search.model.bold_marker_start}', '${search.model.bold_marker_end}') AS url
    FROM
        search_urls
    WHERE
        ${ ftsFragments.join(' OR ') }
) matches
INNER JOIN urls u ON matches.urlid = u.urlid
INNER JOIN visits v ON u.urlid = v.urlid
`;
    }
    else {
        selectSql = "SELECT u.url, u.title, v.visitid, v.visit_time";       // Use title from URLS table.
        fromSql = 'FROM urls u INNER JOIN visits v ON u.urlid=v.urlid';
    }

    return { 
        selectSql  : selectSql,
        fromSql    : fromSql,
        whereSql   : whereSql,
        orderBySql : orderBySql,
        sql        : `${selectSql} ${fromSql} ${whereSql} ${orderBySql}`,
        binds      : binds
    };
};


search.showSearchResults = function() {
    $('#waiting_container').hide();
    $('#results').show();
};

search.addSearchResultExceptionRow = function( selector, options ) {
    search.hideSearchResultControls();
    $('#results').append( Mustache.render( $(selector).html(), options ) );
    return;
};

search.hideSearchResultControls = function() {
    $('#search_result_controls_top').hide();
    $('#search_result_controls_bottom').hide();
    return;
};

search.showSearchResultControls = function() {
    $('#search_result_controls_top').show();
    $('#search_result_controls_bottom').show();
    return;
};

search.drawSearchResultControls = function() {
    // Draw the "Showing results for..." message.
    $('.pagination').text(
        utils.getPaginationText(
            search.model.type,
            search.prefs.getNumberDisplay( search.pageNumber ),
            search.prefs.getNumberDisplay( search.model.totalVisitCount )
        )
    );

    if ( search.model.pageVisitCount && search.model.criteria ) {
        search.showDeleteAllButton();
    }
    else {
        search.hideDeleteAllButton();
    }

    let ids = ['previous_top', 'previous_bottom', 'next_top', 'next_bottom'];
    let is_single_page = search.pageNumber == 1 && search.model.isLastPage;

    // Don't show pager buttons for single-page results.
    if (is_single_page) {
        ids.forEach(function(elem) { $('#'+elem).addClass('invisible'); });
        search.showSearchResultControls();
        return;
    }

    // Draw the pager buttons
    for (let i = 0; i < ids.length; i++) {
        let id = ids[i];
        let selector = '#' + id;

        if ( id.match( /^next/ ) ) {
            $(selector).attr('disabled', search.model.isLastPage);
        }
        else {
            $(selector).attr('disabled', search.pageNumber == 1);
        }

        $(selector).removeClass('invisible');
    }

    search.showSearchResultControls();
};

search.showClearButton = function() {
    $('#clear_search').removeClass('invisible');
    return;
};

search.hideClearButton = function() {
    $('#clear_search').addClass('invisible');
};

search.hideDeleteAllButton = function() {
    $('#show_delete_all').hide();
};

search.showDeleteAllButton = function() {
    $('#show_delete_all').show();
};

search.nextPageAction = function() {
    ++search.pageNumber;
    search.fetchResults('refresh', null, search.pageNumber, search.sortby);
};

search.prevPageAction = function() {
    --search.pageNumber;
    search.fetchResults('refresh', null, search.pageNumber, search.sortby);
};

search.sortByAction = function() {
    search.pageNumber = 1;
    search.sortby = $('#sortby option:selected').val();
    search.fetchResults('refresh', null, search.pageNumber, search.sortby);
};

search.clearSearch = function() {
    search.reset();

    // Empty out keywords field
    $('#keywords')
        .val('')
        .focus()
    ;

    // Reset sortby to newest
    $('#sortby').val('newest');
    search.sortby = 'newest';

    search.hideClearButton();
    search.hideDeleteAllButton();
    search.clearAdvancedFields();
    search.submit( 'all', null );
};


search.dateSearchAction = function(e) {
    search.clearAdvancedFields();

    let yyyymmdd = $(e.target).attr('data-datesearch');
    let keywords = 'date:' + yyyymmdd;
    $('#keywords').val(keywords);

    search.submit('basic', { keywords: keywords });

    return false;
};

search.visitCheckboxAction = function(e) {
    // Select multiple checkboxes during shift-click.
    // https://stackoverflow.com/a/659571/2063505
    if (!search.lastChecked) {
        search.lastChecked = this;
        search.turnDeleteModeOn();
    }
    if (e.shiftKey) {
        let start = search.checkboxes.index(this);
        let end = search.checkboxes.index(search.lastChecked);
        search.checkboxes.slice(Math.min(start,end), Math.max(start,end)+1).prop('checked', search.lastChecked.checked);
    }
    search.lastChecked = this;

    let numChecked = search.checkboxes.filter(':checked').length;
    if ( numChecked ) {
        // Display the number of checked boxes.
        $('.num_selected').text(numChecked);
    }
    else {
        // Hide the delete controls.
        search.turnDeleteModeOff();
    }
};

search.turnDeleteModeOff = function() {
    $('.delete_mode_row').hide();
    $('.results_mode_row').show();
    $('.timeColumn input[type="checkbox"]:checked').prop('checked', false);
    search.lastChecked = null;
};

search.turnDeleteModeOn = function() {
    $('.delete_mode_row').show();
    $('.results_mode_row').hide();
};


search.setupAdvancedSearch = function() {
    // Set up advanced search dialog
    $( "#advanced_search" ).dialog({
        autoOpen: false,
        height: 600,
        width: 450,
        modal: true,
        buttons: {
            Search: function() {
                let dialog = this;
                search.handleAdvancedSearch( dialog );
            },
            Clear: function() {
                search.clearAdvancedFields();
            },
            Cancel: function() {
                $( this ).dialog( "close" );
            }
        },
        open: function(e, ui) {     // eslint-disable-line no-unused-vars
            // Pressing enter in any advanced search text input will submit the search.
            let dialog = this;
            $('#advanced_search input[type="text"]')
                .unbind('keyup')
                .on(
                    'keyup',
                    function(e) {
                        if (e.which == 13) {
                            search.handleAdvancedSearch( dialog );
                        }
                    }
                );
        }
    });

    // Show dialog when Advanced link is clicked.
    $('#show_advanced_search').on(
        'click',
        function() { 
            $('#advanced_search').dialog( 'open' ); 
            return false; 
        }
    );

    // Set up datepickers in Advanced dialog.
    let dateFormat = "yy-mm-dd";
    $('.adv_datepicker').datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: "c-10:c",
        dateFormat: dateFormat
    });

    // Make date ranges change the other's min/max date.
    let from = $('#adv_fromdate');
    let to = $('#adv_todate');
    from.on('change', function() { to.datepicker('option','minDate', getDate(this)); });
    to.on('change', function() { from.datepicker('option','maxDate', getDate(this)); });

    function getDate( element ) {
        let date;
        try {
            date = $.datepicker.parseDate( dateFormat, element.value );
        } catch( error ) {
            date = null;
        }
        return date;
    }

    // Set month checkbox labels for user's locale.
    for (let i = 0; i < 12; i++) {
        $('label[for="adv_month' + (i+1) + '"]').text( search.prefs.getMonthDisplay(i) );
    }

    // Set weekday checkbox labels for user's locale.
    for (let i = 0; i < 7; i++) {   // eslint-disable-line no-redeclare
        $('label[for="adv_weekday' + (i+1) + '"]').text( search.prefs.getWeekdayShortDisplay(i) );
    }

    // Make weekdays and months be checkbox radios.
    $('#advanced_search input[type="checkbox"]').checkboxradio({ icon: false });

    // Set up tooltips.
    let tip_single = 'Single value';
    let tip_comma  = 'Commas separate values';
    let tip_dash   = 'Dash specifies a range';
    let tooltips = {
        'adv_year':
            search.tooltip_table(
                'Enter 4-digit years:', [
                    [ '2017',      tip_single ],
                    [ '2015,2017', tip_comma  ],
                    [ '2010-2012', tip_dash   ]
                ]
            ),
        'adv_monthday':
            search.tooltip_table(
                'Enter numbers from <strong>1-31</strong>:', [
                    [ '31',    tip_single ],
                    [ '30,31', tip_comma  ],
                    [ '1-15',  tip_dash   ]
                ]
            ),
        'adv_hour':
            search.tooltip_table(
                'Enter numbers from <strong>0-23</strong>:', [
                    [ '0',     '0 = midnight'],
                    [ '12',    '12 = noon'   ],
                    [ '6,8,10', tip_comma  ],
                    [ '20-23',  tip_dash   ]
                ]
            ),
        'adv_transition':
            search.tooltip_table(
                'Enter transition types:', [
                    [ 'reload',     tip_single ],
                    [ 'typed,link', tip_comma  ]
                ]
            ),
        'adv_url':
            "Separate URLs with a comma",
        'adv_domain':
            search.tooltip_table(
                    'Enter domains or subdomains:', [
                        [ 'google.com', 'Matches google.com and *.google.com' ],
                        [ '=google.com', 'Matches google.com only' ],
                        [ 't.co,goo.gl', tip_comma ]
                    ]
            ),
        'adv_title':
            "Enter any portion of a page title"
    };
    for (let id in tooltips) {
        $( '#' + id ).tooltip({
            position: {
                my: "left top",
                at: "right+5 top",
                collision: "none"
            },
            content: tooltips[id]
        });
    }
};

search.clearAdvancedFields = function() {
    $('#advanced_search input[type="text"]').val('');
    $('#advanced_search input[type="checkbox"]')
        .prop('checked', false)
        .checkboxradio('refresh'); // refreshes visual state of checkboxes
    $('.adv_datepicker')
        .datepicker('option','minDate',null)
        .datepicker('option','maxDate',null)
    ;
    $('#adv_keywords').focus();
    $('#advanced_search .ui-state-error').removeClass('ui-state-error');
};


search.isEmptySearch = function(criteria) {
    for (let prop in criteria) {
        if ( criteria[prop].length ) {
            return false;
        }
    }
    return true;
};

search.getAdvancedSearchCriteria = function() {
    let criteria = {};

    let keywords = $('#adv_keywords').val().trim();
    if ( keywords.length ) {
        criteria.keywords = keywords;
    }

    let date = search.validateDateInput('#adv_date');
    if ( date != undefined ) {
        criteria.date = date;
    }

    let fromdate = search.validateDateInput('#adv_fromdate');
    if ( fromdate != undefined ) {
        criteria.fromdate = fromdate;
    }

    let todate = search.validateDateInput('#adv_todate');
    if ( todate != undefined ) {
        criteria.todate = todate;
    }

    let years = $('#adv_year').val().trim();
    if ( years.length ) {
        let yearsRange = utils.parseYears( years );
        if ( yearsRange != undefined ) {
            criteria.years = yearsRange;
        }
        else {
            $('#adv_year').addClass('ui-state-error');
        }
    }

    let monthdays = $('#adv_monthday').val().trim();
    if ( monthdays.length ) {
        let monthdayRange = utils.parseMonthDays( monthdays );
        if ( monthdayRange != undefined ) {
            criteria.monthdays = monthdayRange;
        }
        else {
            $('#adv_monthday').addClass('ui-state-error');
        }
    }

    let weekdays = $('input[name="adv_weekday"]:checked');
    if ( weekdays.length ) {
        let weekday_integers = weekdays.map(function() { return this.value; }).get();
        criteria.weekdays = weekday_integers;
    }

    let months = $('input[name="adv_month"]:checked');
    if ( months.length ) {
        let month_integers = months.map(function() { return this.value; }).get();
        criteria.months = month_integers;
    }

    let hours = $('#adv_hour').val().trim();
    if ( hours.length ) {
        let hoursRange = utils.parseHours( hours );
        if ( hoursRange != undefined ) {
            criteria.hours = hoursRange;
        }
        else {
            $('#adv_hour').addClass('ui-state-error');
        }
    }

    let transitions = $('#adv_transition').val().trim();
    if ( transitions.length ) {
        let transition_array = utils.textToArray( transitions );
        if ( transition_array != undefined ) {
            criteria.transitions = transition_array;
        }
        else {
            $('#adv_transition').addClass('ui-state-error');
        }
    }

    let urls = $('#adv_url').val().trim();
    if ( urls.length ) {
        let url_array = utils.textToArray( urls );
        if ( url_array != undefined ) {
            criteria.urls = url_array;
        }
        else {
            $('#adv_url').addClass('ui-state-error');
        }
    }

    let domains = $('#adv_domain').val().trim();
    if ( domains.length ) {
        let domain_array = utils.textToArray( domains );
        if ( domain_array != undefined ) {
            criteria.domains = domain_array;
        }
        else {
            $('#adv_domain').addClass('ui-state-error');
        }
    }

    let title = $('#adv_title').val().trim();
    if ( title.length ) {
        criteria.title = title;
    }

    // If any errors exist, return nothing.
    if ( $('#advanced_search .ui-state-error').length ) {
        return;
    }

    // If there are no search criteria, return nothing.
    if ( $.isEmptyObject(criteria) ) {
        return;
    }

    return criteria;
};


search.validateDateInput = function(selector) {
    let date = $(selector).val().trim();
    if ( date.length ) {
        if ( date.match(/^\d{4}-\d\d-\d\d$/) ) {
            return date;
        }
        $(selector).addClass('ui-state-error');
    }
    return;
};

search.handleAdvancedSearch = function(dialog) {
    // Clear any existing errors.
    $('#advanced_search .ui-state-error').removeClass('ui-state-error');

    let criteria = search.getAdvancedSearchCriteria();
    let numErrors = $('#advanced_search .ui-state-error').length;

    if ( criteria != undefined ) {
        // Advanced search criteria exist, so submit the search.
        $( dialog ).dialog( "close" );
        $('#keywords').val(''); // Clear searchbar
        search.submit( 'advanced', criteria );
    }
    else if ( criteria == undefined && !numErrors ) { 
        // If the user clicked search with no search criteria, 
        // clear the search and close the dialog.
        $( dialog ).dialog( "close" );
        search.clearSearch();
    }
};


search.tooltip_table = function(label, rows) {
    return Mustache.render(
        $('#template-tooltip-row').html(),
        { label: label, rows: rows }
    );
};


search.setupSearchTips = function() {
    // Set up dialog box for search tips
    $( "#search_tips" ).dialog({
        autoOpen: false,
        height: 360,
        width: 600,
        modal: true,
        buttons: {
            Ok: function() {
                $( this ).dialog( "close" );
            }
        }
    });
    $('#show_search_tips').on(
        'click',
        function() {
            $('#search_tips').dialog( 'open' );
            return false;
        }
    );
};


search.setupDeleteVisits = function() {
    // Set up delete items confirmation.
    $('#confirm_delete_visits').dialog({
        autoOpen: false,
        resizable: false,
        height: 150,
        modal: true,
        buttons: [
            {
                id: 'delete_visits_button',
                class: 'delete-buttons',
                text: 'Delete',
                click: function() {
                    // Disable buttons and change the delete button's label.
                    $('.delete-buttons').button('disable');
                    $('#delete_visits_button').text('Deleting ...');

                    let visitids = $('#results input:checked').map( function() { return this.value; } ).get();

                    search.worker.run('deleteVisits', {
                        workerArguments: { visitids },
                        onComplete: function() {
                            // Re-enable buttons on delete popup.
                            $('#delete_visits_button').text('Delete');
                            $('.delete-buttons').button('enable');

                            $('#confirm_delete_visits').dialog('close');
                            search.turnDeleteModeOff();
                            search.submit('refresh', null);
                        },
                        onError: search.onError
                    });
                }
            },
            {
                class: 'delete-buttons',
                text: 'Cancel',
                click: function() {
                    $(this).dialog('close');
                    search.turnDeleteModeOff();
                }
            }
        ]
    });
};


search.setupDeleteAllResults = function() {
    $('#confirm_delete_all').dialog({
        autoOpen: false,
        resizable: true,
        height: 180,
        width: 330,
        modal: true,
        buttons: [
            {
                id    : 'delete_all_button',
                class : 'delete-buttons',
                text  : 'Delete',
                click : function() {
                    // Disable buttons and change the delete button's label.
                    $('.delete-buttons').button('disable');
                    $('#delete_all_button').text('Deleting ...');

                    let sqlAndBinds = search.model.getSqlAndBinds();
                    search.worker.run('deleteAllSearchResults', {
                        workerArguments: {
                            sql: `DELETE FROM visits WHERE visitid IN (SELECT v.visitid ${sqlAndBinds.fromSql} ${sqlAndBinds.whereSql})`,
                            binds: sqlAndBinds.binds
                        },
                        onComplete: function() {
                            // Re-enable buttons on delete popup.
                            $('#delete_all_button').text('Delete');
                            $('.delete-buttons').button('enable');
                            // Close dialog.
                            $('#confirm_delete_all').dialog('close');
                            // Set a message to display after the search is cleared.
                            search.setTemporaryAlert(
                                Mustache.render(
                                    $('#template-delete-alert').html(),
                                    { count: search.prefs.getNumberDisplay( search.model.totalVisitCount ) }
                                )
                            );
                            search.clearSearch();
                        },
                        onError: search.onError
                    });
                }
            },
            {
                class : 'delete-buttons',
                text  : 'Cancel',
                click : function() {
                    $(this).dialog('close');
                }
            }
        ]
    });
    // Show dialog when 'Delete All' button is clicked
    $('#show_delete_all').on(
        'click',
        function() {
            $('#delete_all_count').text(
                search.prefs.getNumberDisplay( search.model.totalVisitCount )
            );
            $('#confirm_delete_all').dialog( 'open' );
            return false;
        }
    );
};


search.getTemporaryAlerts = function() {
    let got = window.sessionStorage.getItem('tempSearchAlerts');
    if ( got != null ) {
        got = JSON.parse(got);
    }
    return got ?? [];
};


search.clearTemporaryAlerts = function() {
    window.sessionStorage.removeItem('tempSearchAlerts');
};


search.setTemporaryAlert = function(html) {
    let alerts = search.getTemporaryAlerts();
    alerts.push(html);
    window.sessionStorage.setItem('tempSearchAlerts', JSON.stringify(alerts));
};


search.displayTemporaryAlerts = function() {
    for (const html of search.getTemporaryAlerts()) {
        $('#results').before(html);
    }
    search.clearTemporaryAlerts();
};


search.setupExportDialog = function() {
    // Set up Search Export dialog.
    $('#search_export').dialog({
        autoOpen: false,
        resizable: false,
        width: 350,
        modal: true,
        buttons: [
            {
                id: 'search_export_button',
                text: 'Export',
                click: function() {
                    $('#search_export_button').before(
                        '<span id="export_spinner" class="spinner-image-dialog" style="padding-right: 10px; vertical-align: middle;" />'
                    );
                    let sqlAndBinds = search.model.getSqlAndBinds();
                    search.worker.run('exportSearch', {
                        workerArguments: {
                            whereClause  : `WHERE (u.urlid, v.visitid) IN (SELECT u.urlid, v.visitid ${sqlAndBinds.fromSql} ${sqlAndBinds.whereSql})`,
                            binds        : sqlAndBinds.binds,
                            orderBy      : search.sortby,
                            baseFilename : 'htu_analyze_' + utils.dateToTimestamp(new Date(), '_'),
                            format       : 'analysis',
                            compressFile : false
                        },
                        onComplete: function() {
                            $('#export_spinner').remove();
                            $('#search_export').dialog( "close" );
                        },
                        onError: function(message) {
                            $('#export_spinner').remove();
                            $('#search_export_button').before(
                                `<span id="export_error_text" class="error">An error occurred: ${message} </span>&nbsp;`
                            );
                        }
                    });
                }
            },
            {
                id: 'search_export_cancel',
                text: 'Cancel',
                click: function() {
                    $(this).dialog('close');
                }
            }
        ]
    });
    // Show dialog when 'Export These Results' is clicked
    $('.show_search_export').on(
        'click',
        function() {
            $('#search_export').dialog( 'open' );
            return false;
        }
    );
    $( "#export_more_details" ).attr('href', chrome.runtime.getURL("export_details.html"));
};


search.showCorruptionAlert = function() {
    $('#header').after(
        Mustache.render( $('#corruption-alert').html(), {} )
    );
    // Show dialog when 'Delete Corrupted Database' is clicked. Must come after the corruption-alert template is rendered.
    $('#delete_database').on(
        'click',
        function() {
            $('#delete_database_confirm').dialog('open');
            return false;
        }
    );
};


search.setupDeleteCorruptedDatabase = function() {
    // Set up confirm dialog.
    $('#delete_database_confirm').dialog({
        autoOpen: false,
        resizable: false,
        width: 350,
        modal: true,
        buttons: [
            {
                id: 'delete_database_ok',
                text: 'Delete',
                click: function() {
                    $('#delete_database_ok')
                        .button('disable')
                        .before('<span id="delete_database_spinner" class="spinner-image-dialog" style="padding-right: 10px; vertical-align: middle;" />')
                    ;
                    search.worker.run('deleteDatabase', {
                        workerArguments: {},
                        onComplete: function() {
                            $('#delete_database_ok').button('enable');
                            $('#delete_database_spinner').remove();
                            // Reset the last sync time so all of the browser's
                            // history will be imported during the next sync.
                            search.prefs.setLastHistorySyncTime(0);
                            search.prefs.persist(function() {
                                $('#delete_database_confirm').dialog('close');
                                $('#delete_database_success').dialog('open');
                            });
                        },
                        onError: function(message) {
                            $('#delete_database_ok').button('enable');
                            $('#delete_database_spinner').remove();
                            $('#delete_database_confirm').append(
                                `<p id="export_error_text" class="error">${message}</p>`
                            );
                        }
                    });
                }
            },
            {
                id: 'delete_database_cancel',
                text: 'Cancel',
                click: function() {
                    $(this).dialog('close');
                }
            }
        ]
    });
    // Set up delete-success dialog.
    $('#delete_database_success').dialog({
        autoOpen: false,
        resizable: false,
        width: 550,
        modal: true,
        dialogClass: 'no-close',
        buttons: [
            {
                id: 'delete_database_success_ok',
                text: 'Ok',
                click: function() {
                    window.location = window.location; // eslint-disable-line no-self-assign
                }
            }
        ]
    });
};


