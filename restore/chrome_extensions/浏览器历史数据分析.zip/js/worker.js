// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils, JSZip, Preferences, Filters */

importScripts('utils.js');
importScripts(
    'preferences.js',
    'public_suffix.js',
    'filters.js',
    utils.sqliteFile(),
    '../external/jszip-3.1.5.min.js'
);

let worker = {
    db: null,
    sqlite3: null,
    trends: {}
};

self.onmessage = async function(ev) {
    let request = ev.data;
    let { command, workerArguments } = request;

    try {
        worker.logInfo(`Received ${command} message.`);

        if ( !worker.sqlite3 ) {
            worker.logInfo("Loading sqlite");
            postMessage({ command, statusUpdate: 'Loading...' });
            worker.sqlite3 = await self.sqlite3InitModule();
        }
        
        worker.logInfo("Opening db");
        worker.db = new worker.sqlite3.oo1.DB({
            filename: utils.databaseName(),
            vfs: 'opfs',
            flags: 'c'
        });
        worker.createTablesIfNeeded();

        let prefs = new Preferences(request.storage);

        if ( request.history ) {
            postMessage({ command, statusUpdate: 'Saving history...' });
            worker.saveHistory( request.history );
        }

        switch (command) {
            case 'performSearch':
                postMessage({ command, statusUpdate: 'Searching...' });
                worker.performSearch( command, workerArguments );
                break;

            case 'deleteVisits':
                worker.deleteVisits( command, workerArguments );
                break;

            case 'deleteAllSearchResults':
                worker.deleteAllSearchResults( command, workerArguments );
                break;

            case 'deleteDatabase':
                worker.deleteDatabase( command, workerArguments );
                break;

            case 'autoBackupIfNeeded':
                worker.autoBackupIfNeeded(command, prefs);
                break;

            case 'autoBackupNow':
                worker.autoBackupNow(command, new Date(), prefs);
                break;

            case 'exportHistory':
                worker.exportHistory( command );
                break;

            case 'exportSearch':
                worker.exportSearch( command, workerArguments );
                break;

            case 'exportTrends':
                worker.exportTrends( command, workerArguments, prefs );
                break;

            case 'storageStats':
                worker.storageStats( command );
                break;

            case 'calcTrends':
                worker.calcTrends( command, workerArguments, prefs );
                break;

            default:
                throw new Error(`Unknown command: ${request.command}`);
        }
    }
    catch (e) {
        self.postMessage({
            command: request.command,
            error: e
        });
        throw e;
    }
    finally {
        worker.logInfo("Closing db");
        worker.db.close();
    }
};


worker.createTablesIfNeeded = function() {
    worker.db.exec({
        sql: [
            "CREATE TABLE IF NOT EXISTS urls(" +
                "urlid INTEGER PRIMARY KEY ASC" +
                ",url TEXT" +
                ",host TEXT" +
                ",root_domain TEXT" +
                ",title TEXT" +
            ");",
            "CREATE TABLE IF NOT EXISTS visits(" +
                "visitid INTEGER PRIMARY KEY ASC " +
                ",urlid INTEGER " +
                ",visit_time TEXT " +
                ",visit_date TEXT " +
                ",year INTEGER " +
                ",month INTEGER " +
                ",month_day INTEGER " +
                ",week_day INTEGER " +
                ",hour INTEGER " +
                ",transition_type TEXT" +
            ");",
            "CREATE VIRTUAL TABLE IF NOT EXISTS search_urls USING fts5(url, title, tokenize = 'unicode61 remove_diacritics 2');",
            "CREATE UNIQUE INDEX IF NOT EXISTS urls_url ON urls(url);",
            "CREATE INDEX IF NOT EXISTS urls_host ON urls(host);",
            "CREATE INDEX IF NOT EXISTS urls_root_domain ON urls(root_domain);",
            "CREATE UNIQUE INDEX IF NOT EXISTS visits_urlid_visit_time ON visits(urlid, visit_time);",
            "CREATE INDEX IF NOT EXISTS visits_visit_time ON visits(visit_time);",
            "CREATE INDEX IF NOT EXISTS visits_visit_date ON visits(visit_date);"
        ]
    });
};


worker.saveHistory = function(history) {
    worker.logInfo(`Saving history since ${new Date(history.syncStartTime).toString()}`);

    let urlsInserted = 0;
    let visitsInserted = 0;
    let totalVisits = 0;

    worker.db.exec('BEGIN');

    for (const historyItem of history.results) {
        const url = historyItem.url;
        const title = historyItem.title;
        const host = utils.extractHost(url);
        const root_domain = utils.getDomainPortion(host);
        let titleFromHistory = utils.formatTitle(title);

        if (titleFromHistory == "") {
            titleFromHistory = null;
        }

        let newUrlid = worker.db.selectValue(
            "INSERT OR IGNORE INTO urls (url, host, root_domain, title) VALUES (?, ?, ?, ?) RETURNING urlid", 
            [url, (host === undefined ? null : host), (root_domain === undefined ? null : root_domain), titleFromHistory]
        );

        if ( newUrlid ) {
            ++urlsInserted; 
            worker.db.exec({
                sql: "INSERT OR IGNORE INTO search_urls (rowid, url, title) SELECT ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM search_urls WHERE rowid=?)",
                bind: [newUrlid, url, titleFromHistory, newUrlid]
            });
        }

        let urlRow = worker.db.selectObject("SELECT urlid, title FROM urls WHERE url=?", [url]);
        if ( urlRow ) {
            let urlid = urlRow.urlid;
            let titleFromDb = urlRow.title;
            if (titleFromDb != titleFromHistory) {
                worker.logInfo("Updating title for urlid=" + urlid);
                worker.db.exec({ sql: "UPDATE urls SET title=? WHERE urlid=?", bind: [titleFromHistory, urlid] });
                worker.db.exec({ sql: "UPDATE search_urls SET title=? WHERE rowid=?", bind: [titleFromHistory, urlid] });
            }
        }
        else {
            utils.logError(`Could not find urlid for url=${url}. Skipping it and its ${historyItem.visits.length} visits.`);
            continue;
        }

        const insertSql = 
            "INSERT OR IGNORE INTO visits (" +
                "urlid, visit_time, visit_date, year, month, month_day, week_day, hour, transition_type" +
            ") VALUES (" +
                "    ?,          ?,          ?,    ?,     ?,         ?,        ?,    ?,               ?" +
            ") RETURNING visitid"
        ;
        for (const visitItem of historyItem.visits) {
            const visitDate = new Date(visitItem.visitTime);
            const dateString = utils.dateToString(visitDate);

            const visitId = worker.db.selectValue(
                insertSql,
                [
                    urlRow.urlid, visitItem.visitTime.toString(), dateString, visitDate.getFullYear(), visitDate.getMonth(),
                    visitDate.getDate(), visitDate.getDay(), visitDate.getHours(), visitItem.transition
                ]
            );
            if ( visitId ) {
                ++visitsInserted;
            }
        }
        totalVisits += historyItem.visits.length;
    }

    worker.db.exec('COMMIT');

    let urlMsg = `URLS: ${history.results.length} found. ${urlsInserted}.`;
    let visitMsg = `VISITS: ${totalVisits} found. ${visitsInserted} inserted.`;
    worker.logInfo(urlMsg);
    worker.logInfo(visitMsg);

    postMessage({
        command: 'historySynced',
        maxVisitTimeSeen: history.maxVisitTimeSeen,
        logInfo: [ urlMsg, visitMsg ]
    });
};


// Inputs:
// * needsTotalVisitCount
// * sql
// * binds
// * pageNumber
// * maxVisitsPerPage
// Outputs
// * command
// * rows
// * isLastPage
// * totalVisitCount (optional)
worker.performSearch = function( command, args ) {
    let response = { command };

    worker.logInfo('Searching started');
    if ( args.needsTotalVisitCount ) {
        let countSql = `SELECT COUNT(*) FROM (${args.sql})`;
        response.totalVisitCount = worker.db.selectValue( countSql, args.binds );
        worker.logInfo(`Found ${response.totalVisitCount} rows`);
    }

    // Limit SQL to the requested page.
    let sql = args.sql;
    let binds = args.binds;
    if ( args.pageNumber ) {
        sql += " LIMIT ? OFFSET ?";
        let offset = args.maxVisitsPerPage * (args.pageNumber - 1);
        let limit  = args.maxVisitsPerPage + 1;  // One more than needed, so we can snoop if a next page exists.
        binds.push( limit, offset );
    }

    // Perform the search.
    response.rows = worker.db.selectObjects( sql, binds );
    worker.logInfo('Searching ended');

    if ( response.rows.length > args.maxVisitsPerPage ) {
        response.isLastPage = false;
        response.rows.pop();
    }
    else {
        response.isLastPage = true;
    }

    postMessage( response );
};


// Inputs:
// * visitids
// Outputs:
// * command
// * deletedVisitCount
worker.deleteVisits = function( command, args ) {
    worker.logInfo("Begin deleting " + args.visitids.length + " visits");

    // Delete the given visits.
    worker.db.exec('BEGIN');
    worker.db.exec( `DELETE FROM visits WHERE visitid IN (${args.visitids.join(',')})` );

    let deletedVisitCount = worker.db.changes();
    worker.logInfo(`Deleted ${deletedVisitCount} visits`);

    worker.deleteOrphanedUrls();
    worker.db.exec('COMMIT');

    postMessage({ command, deletedVisitCount });
};


worker.deleteOrphanedUrls = function() {
    // Find any URLs that no longer have visits.
    let urlids = worker.db.selectArray( "SELECT urlid FROM urls WHERE urlid NOT IN (SELECT urlid FROM visits)" ) || [];
    worker.logInfo(`Found ${urlids.length} orphaned URLs`);

    if ( urlids.length ) {
        let urlids_clause = urlids.join(',');
        // Delete the URLs with no visits from the urls and full-text-search table.
        for (const obj of [
            { table: 'urls',        column: 'urlid' },
            { table: 'search_urls', column: 'rowid' }
        ]) {
            worker.db.exec( `DELETE FROM ${obj.table} WHERE ${obj.column} IN (${urlids_clause})` );
            worker.logInfo(`Deleted ${worker.db.changes()} orphaned rows from ${obj.table}`);
        }
    }
};


// Inputs:
// * sql
// * binds
// Outputs:
// * command
// * deletedVisitCount
worker.deleteAllSearchResults = function(command, args) {
    worker.logInfo("Begin deleting all search results");

    worker.db.exec('BEGIN');
    worker.db.exec({ sql: args.sql, bind: args.binds });

    let deletedVisitCount = worker.db.changes();
    worker.logInfo(`Deleted ${deletedVisitCount} search results`);

    worker.deleteOrphanedUrls();
    worker.db.exec('COMMIT');

    postMessage({ command, deletedVisitCount });
};


worker.deleteDatabase = function(command, args) {   // eslint-disable-line no-unused-vars
    worker.vfsUnlink('opfs', utils.databaseName());
    postMessage({ command });
};


// https://sqlite.org/forum/forumpost/6fe79e897d
worker.vfsUnlink = function(vfsName,filename){
    const pVfs = worker.sqlite3.capi.sqlite3_vfs_find(vfsName || 0);
    if( !pVfs ) return false;
    const vfs = new worker.sqlite3.capi.sqlite3_vfs(pVfs);
    const xDelete = worker.sqlite3.wasm.functionEntry( vfs.$xDelete );
    if( !xDelete ) return false;
    return 0===worker.sqlite3.wasm.xCallWrapped( xDelete, 'int', ['*','string','int'], pVfs, filename, 1 );
};


worker.autoBackupIfNeeded = function(command, prefs) {
    const now = new Date();

    if ( utils.backupIsNeeded( prefs, now ) ) {
        worker.autoBackupNow(command, now, prefs);
    }
    else {
        worker.logInfo(`autoBackup is not needed`);
        self.postMessage({ command });
    }
};


worker.autoBackupNow = function(command, now, prefs) {
    const backupType = prefs.autoBackupType();
    const backupDate = prefs.lastAutoBackupDate();
    const baseFilename = `htu_autobackup_${ utils.dateToString( now, '' ) }_${backupType}`;

    let whereClause;
    let binds;
    if (backupType == "incremental" && backupDate ) {
        whereClause = "WHERE v.visit_time > ?";
        binds = [ backupDate.getTime() ];
    }

    worker.logInfo(`autoBackup (${backupType}) started`);
    worker.exportResults({
        baseFilename,
        whereClause,
        binds,
        format: 'archived',
        compressFile: prefs.autoBackupCompression()
    });
    worker.logInfo(`autoBackup (${backupType}) ended`);

    self.postMessage({
        command,
        lastAutoBackupDate: now.getTime()
    });
};


worker.exportHistory = function( command ) {
    worker.exportResults({
        baseFilename: 'htu_backup_' + utils.dateToTimestamp(new Date(), '_'),
        format: 'archived',
        compressFile: false
    });
    postMessage({ command });
};

worker.exportSearch = function( command, args ) {
    worker.exportResults( args );
    postMessage({ command });
};


worker.exportTrends = function( command, args, prefs ) {
    let filters = new Filters( args.filterJSON );
    let whereInfo = worker.trends.buildWhereClause(prefs, filters);
    worker.exportResults({
        baseFilename: args.baseFilename,
        format      : 'analysis',
        whereClause : whereInfo.sql,
        binds       : whereInfo.binds,
        compressFile: false
    });
    postMessage({ command });
};


worker.storageStats = async function( command ) {
    const estimate = await navigator.storage.estimate();

    const dir = await navigator.storage.getDirectory();
    const fileHandle = await dir.getFileHandle( utils.databaseName() );
    const file = await fileHandle.getFile();

    postMessage({
        command,
        storageQuota: utils.humanReadableBytes( estimate.quota ),
        percentUsed: (estimate.usage / estimate.quota),
        databaseSize: utils.humanReadableBytes( file.size )
    });
};


/*
 * exportResults( args )
 *
 * args is on object containing the following properties:
 *
 * baseFilename: name of exported file (without extension). Either '.tsv' or '.zip' will be used, based on compressFile.
 * format      : either 'archived' or 'analysis'
 * whereClause : string containing the WHERE clause (including the 'WHERE' keyword)
 * binds       : array of bind values (only needed if whereClause contains bind vars)
 * orderBy     : either 'newest', 'oldest', or undefined (which uses the default sort of root_domain/host/url/visit_time)
 * compressFile: boolean indicating if file should be compressed.
 */

worker.exportResults = function({ baseFilename, format, whereClause = '', binds, orderBy, compressFile }) {
    let archivedSql = `
SELECT
    IFNULL( u.url, '' ) || char(9) ||
    'U' || IFNULL( v.visit_time, '' ) || char(9) ||
    IFNULL( ${utils.textToTransitionAsCase('v.transition_type')}, '' ) || char(9) ||
    IFNULL( u.title, '' ) || char(13, 10) AS export_line
FROM
    urls u
    INNER JOIN visits v ON u.urlid = v.urlid
`;

    let analysisSql = `
SELECT
    IFNULL( u.url, '' ) || char(9) ||
    IFNULL( u.host, '' ) || char(9) ||
    IFNULL( u.root_domain, '' ) || char(9) ||
    IFNULL( v.visit_time, '' ) || char(9) ||
    IFNULL( datetime( CAST(v.visit_time AS INTEGER) / 1000, 'unixepoch', 'localtime' ), '' ) || char(9) ||
    IFNULL( strftime( '%w', v.visit_time / 1000, 'unixepoch', 'localtime' ), '') || char(9) ||
    IFNULL( v.transition_type, '' ) || char(9) ||
    IFNULL( u.title, '' ) || char(13, 10) AS export_line
FROM
    urls u
    INNER JOIN visits v ON u.urlid = v.urlid
`;

    let orderBySql;
    if (orderBy == 'oldest') {
        orderBySql = " ORDER BY v.visit_time, u.root_domain, u.host, u.url";
    }
    else if (orderBy == 'newest') {
        orderBySql = " ORDER BY v.visit_time DESC, u.root_domain, u.host, u.url";
    }
    else {
        orderBySql = " ORDER BY u.root_domain, u.host, u.url, v.visit_time";
    }

    let sql = (format == 'archived' ? archivedSql : analysisSql) + whereClause + orderBySql;

    worker.logInfo("Starting export query");

    // On my machine, using only ASCII characters, 536_870_888 is the max string length.
    // Avoid hitting that limit.
    let maxStringLength = 200_000_000;
    let fileCount = 0;
    let zip;
    if ( compressFile ) {
        zip = new JSZip();
    }

    var exportString = '';

    var postBlobUrl = function(isLast) {
        ++fileCount;
        let fullFilename = utils.getExportFilename( baseFilename, fileCount, isLast );

        if (compressFile) {
            worker.logInfo(`File ${fileCount}: Compression started`);
            zip.file(fullFilename, exportString);
            if ( isLast ) {
                zip.generateAsync({
                    type: "blob",
                    compression: "DEFLATE",
                    compressionOptions: { level: 3 }  // 3 is arbitrary. 1=best-speed .. 9=best-compression
                }).then(
                    function(blob) {
                        const blobUrl = URL.createObjectURL(blob);
                        self.postMessage({
                            command: 'download',
                            url: blobUrl,
                            filename: `${baseFilename}.zip`,
                            isLast: isLast
                        });
                    }
                );
            }
        }
        else {
            worker.logInfo(`File ${fileCount}: Generating blob`);
            const blob = new Blob([exportString], {type: "text/plain;charset=utf-8"});
            const blobUrl = URL.createObjectURL(blob);
            self.postMessage({
                command: 'download',
                url: blobUrl,
                filename: fullFilename,
                isLast: isLast
            });
        }

        exportString = '';
    };

    let rowCount = 0;
    worker.db.exec({
        sql: sql,
        bind: binds,
        rowMode: 'array',
        callback: function(row) {
            ++rowCount;
            if ( rowCount % 100_000 == 0 ) {
                worker.logInfo( rowCount );
            }

            exportString += row[0];

            if ( exportString.length >= maxStringLength ) {
                postBlobUrl(false);
            }
        }
    });
    worker.logInfo("exec complete");

    postBlobUrl(true);
};


worker.logInfo = function(msg) {
    utils.logInfo(`worker: ${msg}`);
};


worker.calcTrends = function( command, args, prefs ) {
    postMessage({ command, statusUpdate: worker.trends.analyzeText(0) });

    const stats = {
        "historyItems": 0, 
        "visitItems": 0,
        "byTransition": {},
        "byMinute": [],
        "byHour": [],
        "byDay": [],
        "byDayOfMonth": [],
        "byMonth": [],
        "byYear": {},
        "byBusiestDay": {},
        "topDays": [],
        "topUrls": [],
        "topDomains": [],
        "topUniqueVisits": []
    };
  
    // Mass initialization
    for (let i = 0; i < 60; i++)  { stats.byMinute[i] = 0; }
    for (let i = 0; i < 24; i++)  { stats.byHour[i]   = 0; }
    for (let i = 0; i < 7; i++)   { stats.byDay[i]    = 0; }
    for (let i = 1; i <= 31; i++) { stats.byDayOfMonth[i] = 0; }
    for (let i = 0; i < 12; i++)  { stats.byMonth[i]      = 0; }

    let filters = new Filters( args.filterJSON );
    let whereInfo = worker.trends.buildWhereClause(prefs, filters);
    let whereSql = whereInfo.sql;
    let whereBinds = whereInfo.binds;
    let fromSql = worker.trends.buildFromClause( whereInfo.tables );

    let calculationFunctions = [
        // Visit count
        function() {
            let sql = `
            SELECT
                COUNT(*) AS num_visits,
                MIN(v.visit_time) AS min_visit_time,
                MAX(v.visit_time) AS max_visit_time
            ${fromSql}
            ${whereSql}
            `;
            let row = worker.db.selectObject(sql, whereBinds);
            stats.visitItems = row.num_visits;
            stats.minVisitTime = row.min_visit_time;
            stats.maxVisitTime = row.max_visit_time;
        },

        // Date counts
        function() {
            let sql = `
            WITH matches AS (
                SELECT
                    v.visit_date,
                    COUNT(*) AS visit_date_count
                ${fromSql}
                ${whereSql}
                GROUP BY
                    v.visit_date
            ),
            dates(date) AS (
                SELECT MIN(visit_date) FROM matches
                UNION ALL
                SELECT date(date,'+1 day') FROM dates WHERE date < (SELECT MAX(visit_date) FROM matches)
            )
            SELECT
                dates.date AS visit_date,
                IFNULL(matches.visit_date_count, 0) AS visit_date_count
            FROM
                dates
                LEFT OUTER JOIN matches ON dates.date = matches.visit_date
            WHERE
                dates.date IS NOT NULL
            ORDER BY
                visit_date_count DESC
            `;
            let rows = worker.db.selectObjects(sql, whereBinds);
            let countsExceptToday = [];
            let todayString = utils.dateToString(new Date());

            for (let i = 0; i < rows.length; i++) {
                let item = rows[i];
                let dateObj = utils.stringToDate(item.visit_date);

                stats.byBusiestDay[dateObj.toDateString()] = item.visit_date_count;

                if (i < 100 && item.visit_date_count) {
                    stats.topDays.push([
                        dateObj.getTime(),
                        item.visit_date_count
                    ]);
                }

                if (item.visit_date != todayString && item.visit_date_count) {
                    countsExceptToday.push(item.visit_date_count);
                }
            }

            // TODO: Use SQLite's math functions to compute mean/median.
            stats.busiestDayMean = utils.calcMean(countsExceptToday);
            stats.busiestDayMedian = utils.calcMedian(countsExceptToday);
        },

        // Top Domain counts
        function() {
            // As an optimization, if there's no domain filter, we can query the
            // root_domain column. Otherwise, we need to use the host column.
            let column = "root_domain";
            let domainFilter = filters.getDomain();
            if (domainFilter) {
                column = "host";
            }

            // exclude the oddball urls for which we don't handle host/domains.
            // e.g., ip-addresses and file:///
            let excludeNulls = '';
            if (whereSql.length) {
                excludeNulls = `AND u.${column} IS NOT NULL`;
            }
            else {
                excludeNulls = `WHERE u.${column} IS NOT NULL`;
            }

            let fromSql = worker.trends.buildFromClause( { ...whereInfo.tables, urls: 1 } );
            let sql = `
                SELECT
                    u.${column} AS domain,
                    COUNT(*) AS domain_count
                ${fromSql}
                ${whereSql}
                ${excludeNulls}
                GROUP BY
                    u.${column}
                ORDER BY
                    COUNT(*) DESC
            `;

            let rows = worker.db.selectObjects( sql, whereBinds );

            if ( domainFilter ) {
                // When filtering by domain, we need to preprocess the results to
                // collapse similar domains into one (e.g., if filter='z.com', then
                // collapse 'a.z.com' and 'b.z.com' into 'z.com'). Because SQLite
                // doesn't have built-in support for regexes, we have to do this in JS.
                let domainCounts = {};
                for (const item of rows) {
                    let portion = utils.getDomainPortion(item.domain, domainFilter);
                    if (!domainCounts[ portion ]) {
                        domainCounts[ portion ] = 0;
                    }
                    domainCounts[ portion ] = item.domain_count + domainCounts[ portion ];
                }
                let i = 0;
                for (const domain in domainCounts) {
                    if (i > 99) { break; }
                    stats.topDomains.push([ domain, domainCounts[ domain ] ]);
                    i++;
                }
            }
            else {
                // When there is no domain filter, we can use the root_domain column as
                // an optimization, preventing the need for preprocessing.
                for (let i = 0; i < rows.length; i++) {
                    if (i > 99) { break; }
                    let item = rows[i];
                    stats.topDomains.push([ item.domain, item.domain_count ]);
                }
            }
        },

        // Unique URLs per Domain counts
        function() {
            // As an optimization, if there's no domain filter, we can query the
            // root_domain column. Otherwise, we need to use the host column.
            let column = "root_domain";
            let domainFilter = filters.getDomain();
            if (domainFilter) {
                column = "host";
            }

            // exclude the oddball urls for which we don't handle host/domains.
            // e.g., ip-addresses and file:///
            let excludeNulls = "";
            if (whereSql.length) {
                excludeNulls = " AND u." + column + " IS NOT NULL ";
            }
            else {
                excludeNulls = " WHERE u." + column + " IS NOT NULL ";
            }

            let fromSql = worker.trends.buildFromClause( { ...whereInfo.tables, urls: 1 } );

            if (domainFilter) {
                let sql = `
                    SELECT
                        u.url,
                        u.${column} AS domain,
                        COUNT(*) as visit_count
                    ${fromSql}
                    ${whereSql}
                    ${excludeNulls}
                    GROUP BY
                        u.url,
                        u.${column}
                `;
                let rows = worker.db.selectObjects( sql, whereBinds );

                let urlCounts = {};
                for (const item of rows) {
                    let domain = utils.getDomainPortion( item.domain, domainFilter );
                    if (!urlCounts[ domain ]) {
                        urlCounts[ domain ] = { url_count: 0, visit_count: 0 };
                    }
                    urlCounts[ domain ].url_count++;
                    urlCounts[ domain ].visit_count += item.visit_count;
                }

                let urlCountArray = [];
                for (const d in urlCounts) {
                    urlCountArray.push({ 
                        domain: d, 
                        url_count: urlCounts[ d ].url_count, 
                        visit_count: urlCounts[ d ].visit_count
                    });
                }
                urlCountArray.sort(function(a,b) { return b.url_count - a.url_count; });

                for (let i = 0; i < urlCountArray.length; i++) {
                    if (i > 99) { break; }
                    let item = urlCountArray[ i ];
                    stats.topUniqueVisits.push([ 
                        item.domain, 
                        item.url_count, 
                        item.visit_count,  
                        item.url_count / item.visit_count
                    ]);
                }
            }
            else {
                let sql = `
                    SELECT * FROM (
                        SELECT
                            u.${column} AS domain,
                            COUNT(DISTINCT u.urlid) AS url_count,
                            COUNT(*) AS visit_count
                        ${fromSql}
                        ${whereSql}
                        ${excludeNulls}
                        GROUP BY u.${column}
                        ORDER BY
                            COUNT(DISTINCT u.urlid) DESC,
                            visit_count DESC
                    ) LIMIT 100
                `;
                let rows = worker.db.selectObjects( sql, whereBinds );
                for (const item of rows) {
                    stats.topUniqueVisits.push([ 
                        item.domain, 
                        item.url_count, 
                        item.visit_count,  
                        item.url_count / item.visit_count
                    ]);
                }
            }
        },

        // Top URL counts
        function() {
            let sql = `
                SELECT * FROM (
                    SELECT
                        u.url,
                        t.url_count,
                        COUNT(*) OVER () AS all_urls_count
                    FROM (
                        SELECT
                            v.urlid,
                            COUNT(*) AS url_count
                        ${fromSql}
                        ${whereSql}
                        GROUP BY
                            v.urlid
                    ) t
                    INNER JOIN urls u ON t.urlid = u.urlid
                    ORDER BY
                        t.url_count DESC, u.url
                )
                LIMIT 100
            `;
            let rows = worker.db.selectObjects( sql, whereBinds );
            stats.historyItems = rows.length ? rows[0].all_urls_count : 0;
            for (const item of rows ) {
                stats.topUrls.push([ item.url, item.url_count ]);
            }
        },

        // Hour counts
        function() {
            let sql = `SELECT v.hour, COUNT(*) as hour_count ${fromSql} ${whereSql} GROUP BY v.hour ORDER BY hour`;
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byHour[item.hour] = item.hour_count;
            }
        },

        // Weekday counts
        function() {
            let sql = 
                "SELECT v.week_day, COUNT(*) AS week_day_count " + 
                fromSql +
                whereSql + 
                "GROUP BY v.week_day ORDER BY week_day"
            ;
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byDay[item.week_day] = item.week_day_count;
            }
        },

        // Monthday counts
        function() {
            let sql =
                "SELECT v.month_day, COUNT(*) AS month_day_count " +
                fromSql +
                whereSql + 
                "GROUP BY v.month_day ORDER BY month_day"
            ;
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byDayOfMonth[item.month_day] = item.month_day_count;
            }
        },

        // Month counts
        function() {
            let sql = "SELECT v.month, COUNT(*) AS month_count " + fromSql + whereSql + " GROUP BY v.month ORDER BY month";
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byMonth[item.month] = item.month_count;
            }
        },

        // Year counts
        function() {
            let sql = "SELECT v.year AS year, COUNT(*) AS year_count " + fromSql + whereSql + " GROUP BY v.year ORDER BY v.year";
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byYear[item.year] = item.year_count;
            }
        },

        // Transition Type counts
        function() {
            let sql =
                "SELECT v.transition_type, COUNT(*) AS transition_type_count " +
                fromSql +
                whereSql +
                "GROUP BY v.transition_type"
            ;
            let rows = worker.db.selectObjects( sql, whereBinds );
            for (const item of rows) {
                stats.byTransition[item.transition_type] = item.transition_type_count;
            }
        }
    ];

    worker.logInfo("Calculating stats started");
    let calcStart = Date.now();

    calculationFunctions.forEach(
        function(fxn, index, array) {
            let fxnStart = Date.now();
            fxn();
            worker.logInfo(`Calculation ${index+1} took ${(Date.now() - fxnStart) / 1000} seconds`);

            postMessage({
                command,
                statusUpdate: worker.trends.analyzeText( Math.round( (index/array.length) * 100) )
            });
        }
    );

    worker.logInfo(`Calculating all stats took ${(Date.now() - calcStart) / 1000} seconds`);
    postMessage({ command, stats });
};


worker.trends.analyzeText = function(percent) {
    return `Analyzing history... ${percent}%`;
};


worker.trends.buildWhereClause = function(prefs, filters) {
    let clauses = [];
    let binds = [];
    let tables = { urls: 0, visits: 1 };

    let url = filters.getUrl();
    if (url) {
        clauses.push("url = ?");
        binds.push(url);
        tables.urls = 1;
    }

    let domain = filters.getDomain();
    if (domain) {
        // if the domain filter is present, we must query the urls.host column.
        // urls.domain is only used as an optimization when no domain filter exists.
        clauses.push("(host = ? OR host LIKE '%.' || ?)");
        binds.push(domain, domain);
        tables.urls = 1;
    }

    let date = filters.getDate();
    if (date) {
        clauses.push("visit_date = ?");
        let d = new Date(date);
        binds.push( utils.dateToString(d) );
        tables.visits = 1;
    }

    let hour = filters.getHour();
    if (hour) {
        clauses.push("hour = ?");
        binds.push( hour );
        tables.visits = 1;
    }

    let weekday = filters.getWeekday();
    if (weekday) {
        clauses.push("week_day = ?");
        binds.push( weekday );
        tables.visits = 1;
    }

    let monthday = filters.getMonthday();
    if (monthday) {
        clauses.push("month_day = ?");
        binds.push( monthday );
        tables.visits = 1;
    }

    let month = filters.getMonth();
    if (month) {
        clauses.push("month = ?");
        binds.push( month );
        tables.visits = 1;
    }

    let year = filters.getYear();
    if (year) {
        clauses.push("year = ?");
        binds.push( year );
        tables.visits = 1;
    }

    let transition = filters.getTransition();
    if (transition) {
        clauses.push("transition_type = ?");
        binds.push( transition );
        tables.visits = 1;
    }

    let limiter = prefs.getLimiter();
    if (limiter != "limiter_all") {
        clauses.push("visit_time >= ?");
        binds.push( utils.limiterToVisitTime( limiter, (new Date()).getTime() ) );
        tables.visits = 1;
    }

    let sql = "";
    if (clauses.length) {
        sql = " WHERE " + clauses.join(" AND ") + " ";
    }

    if ( binds.length == 0 ) {
        binds = undefined;
    }

    return { sql: sql, binds: binds, tables: tables };
};


worker.trends.buildFromClause = function(tables) {
    if ( tables.urls && tables.visits ) {
        return " FROM urls u INNER JOIN visits v ON u.urlid = v.urlid ";
    }
    else if ( tables.visits ) {
        return " FROM visits v ";
    }

    throw new Error('Visits table is required');
};


