// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals trends, utils */

let ui = {};

ui.createOverview = function(stats, divId) {
    // keep track of events, mapping element ids 
    // to their event callback
    let events = {
        click: {},
        keyup: {},
        change: {}
    };

    let div = document.getElementById(divId);

    // Display total counts
    ui.populateCounts(stats);
    div.appendChild( ui.createLimiterDiv(events) );
    div.appendChild( ui.createClearDiv() );

    // Display list of current filters with Clear buttons
    div.appendChild( ui.createFilterDiv(events) );

    div.appendChild( ui.createDomainBackLink(events) );
    
    // Add a div to clear prior floats
    div.appendChild( ui.createClearDiv() );

    // Determine the active tab.  The id attribute on the <body> tag must be set to the
    // active tab for it to display properly.
    let activeTab = utils.getActiveTab();
    document.body.setAttribute('id', activeTab);

    // Create a container for tabs
    let tabsDiv = ui.createTabsContainer(events);
    
    // Display the Top 10 Most Visited Domains table
    let domainProperties = {
        rows: stats.topDomains,
        rowIdPrefix: 'domainlink',
        onclickFunction: ui.applyDomainFilter,
        linkTitle: chrome.i18n.getMessage('domain_hover_text'),
        containerId: 'domain_container',
        tableId: 'domain_table',
        tableClass: 'tab_2col',
        tableHeaders: {
            normal: [ 'top10_domains',  'visit_count' ],
            popup:  [ 'top100_domains', 'visit_count' ]
        },
        dataTableColumns: [
            { sWidth: "70%" },
            { sType: "data-sort-numeric", sWidth: "30%" }
        ],
        popupWidth: "50%",
        columnFormats: ["t", "n"],
        filterTextBoxId: 'domain_custom_filter_text',
        filterSubmitId: 'domain_custom_filter_go',
        filterText: chrome.i18n.getMessage('filter_by_domain'),
        filterPlaceholder: 'example.com'
    };
    tabsDiv.appendChild( ui.createTab('tab1', activeTab, domainProperties, events) );

    // Display the Top 10 Most Visited URLs table 
    let urlProperties = {
        rows: stats.topUrls,
        rowIdPrefix: 'urllink',
        onclickFunction: ui.applyUrlFilter,
        linkTitle: chrome.i18n.getMessage('url_hover_text'),
        containerId: 'url_container',
        tableId: 'url_table',
        tableClass: 'tab_2col',
        tableHeaders: {
            normal: [ 'top10_urls',  'visit_count' ],
            popup:  [ 'top100_urls', 'visit_count' ]
        },
        dataTableColumns: [
            null,
            { sType: "data-sort-numeric" }
        ],
        popupWidth: "60%",
        columnFormats: ["t", "n"],
        filterTextBoxId: 'url_custom_filter_text',
        filterSubmitId: 'url_custom_filter_go',
        filterText: chrome.i18n.getMessage('filter_by_url'),
        filterPlaceholder: 'http://www.example.com/'
    };
    tabsDiv.appendChild( ui.createTab('tab2', activeTab, urlProperties, events) );
    div.appendChild( tabsDiv );

    // Display the Top 10 Domains with most unique URLs
    let uniqueUrlColumns = [
        'top10_unique_urls',
        'unique_url_count',
        'visit_count',
        'percent_unique_visits'
    ];
    let uniqueUrlProperties = {
        rows: stats.topUniqueVisits,
        rowIdPrefix: 'uniqueUrlLink',
        onclickFunction: ui.applyDomainFilter,
        linkTitle: chrome.i18n.getMessage('domain_hover_text'),
        containerId: 'unique_url_container',
        tableId: 'unique_url_table',
        tableClass: 'tab_4col',
        tableHeaders: {
            normal: uniqueUrlColumns,
            popup:  uniqueUrlColumns
        },
        dataTableColumns: [
            null,
            { sType: "data-sort-numeric" },
            { sType: "data-sort-numeric" },
            { sType: "data-sort-numeric" }
        ],
        popupWidth: "70%",
        columnFormats: ["t", "n", "n", "p"]
    };
    tabsDiv.appendChild( ui.createTab('tab3', activeTab, uniqueUrlProperties, events) );

    // Create the Daily Stats and Visit Dates table
    let dailyStats = ui.createDailyStats(stats);
    let visitDateStats = ui.createVisitDateStats(stats);
    let rightColumnDiv = document.createElement('div');
    rightColumnDiv.appendChild(dailyStats);
    rightColumnDiv.appendChild(visitDateStats);

    // Display the Top 10 Busiest Days table
    let daysProperties = {
        rows: stats.topDays,
        rowIdPrefix: 'busiestday',
        containerId: 'busiest_days_container',
        tableId: 'busiest_days',
        tableClass: 'tab_2col',
        onclickFunction: ui.applyDateFilter,
        linkTitle: chrome.i18n.getMessage('day_hover_text'),
        tableHeaders: {
            normal: [ 'top10_days',  'visit_count' ],
            popup:  [ 'top100_days', 'visit_count' ]
        },
        dataTableColumns: [
            { sType: "data-sort-numeric" },
            { sType: "data-sort-numeric" }
        ],
        columnFormats: ["d", "n"],
        popupWidth: "50%"
    };
    let busiestDays = ui.createTable(daysProperties, events);
    let dailyStatsDiv = document.createElement('div');
    dailyStatsDiv.appendChild(
        ui.buildTable(
            [],
            [
                [ busiestDays, rightColumnDiv ]
            ],
            { 'id': 'daily_stats_container', 'width': '100%' }
        )
    );
    div.appendChild( dailyStatsDiv );

    // Define callbacks for clicking a link in each table
    let domainLinkCallback = function() {
        ui.applyDomainFilter( $(this).attr('data-sort') );
        return false;
    };
    let urlLinkCallback = function() {
        ui.applyUrlFilter( $(this).attr('data-sort') );
        return false;
    };
    let dateLinkCallback = function() {
        ui.applyDateFilter( $(this).attr('data-sort') );
        return false;
    };

    let setupArray = [
        // Top 10 tables
        [ domainProperties.tableId,    domainLinkCallback ],
        [ uniqueUrlProperties.tableId, domainLinkCallback ],
        [ urlProperties.tableId,       urlLinkCallback    ],
        [ daysProperties.tableId,      dateLinkCallback   ],
        // Top 100 tables (popups)
        [ domainProperties.containerId    + '_more', domainLinkCallback ],
        [ uniqueUrlProperties.containerId + '_more', domainLinkCallback ],
        [ urlProperties.containerId       + '_more', urlLinkCallback    ],
        [ daysProperties.containerId      + '_more', dateLinkCallback   ],
        // Daily Stats table
        [ 'per_day_stats',     dateLinkCallback ],
        // Visit Dates table
        [ 'visit_date_stats', dateLinkCallback ]
    ];
    for (let i = 0; i < setupArray.length; i++) {
        let row = setupArray[i];
        $('#' + row[0]).on( 'click', 'a', row[1] );
    }

    // set up event listeners
    for (let eventType in events) {
        for (let id in events[eventType]) {
            document.getElementById(id).addEventListener(eventType, events[eventType][id]);
        }
    }

    return;
};


ui.buildTable = function(headers, rows, props) {
    let table = document.createElement('table');
    for (let key in props) {
        table.setAttribute(key, props[key]);
    }

    let thead = document.createElement('thead');
    
    if (headers) {
        let tr = document.createElement('tr');
        for (let i = 0; i < headers.length; i++) {
            let th = document.createElement('th');
            th.appendChild(document.createTextNode(headers[i][0]));
            let headerProps = headers[i][1];
            for (let headerKey in headerProps) {
                th.setAttribute(headerKey, headerProps[headerKey]);
            }
            th.setAttribute('class', 'col' + (i + 1));
            tr.appendChild(th);
        }
        thead.appendChild(tr);
    }

    let tbody = document.createElement('tbody');

    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
        let tr = document.createElement('tr');      // eslint-disable-line no-redeclare
        let row = rows[rowIndex];
        for (let colIndex = 0; colIndex < row.length; colIndex++) {
            let td = document.createElement('td');
            td.setAttribute('class', 'col' + (colIndex + 1));
            td.appendChild(row[colIndex]);
            tr.appendChild(td);
        }
        tbody.appendChild(tr);
    }
    
    table.appendChild(thead);
    table.appendChild(tbody);
    
    return table;
};



/* 
    ui.switchTab( tabName )

    Called when a user switches to a new tab.  Does the work of hiding
    the current tab and displaying the new tab.
*/
ui.switchTab = function(tabName) {
    window.sessionStorage.setItem('activeTab', tabName);
    document.getElementById('domain_container').style.display = (tabName == 'tab1' ? '' : 'none');
    document.getElementById('url_container').style.display = (tabName == 'tab2' ? '' : 'none');
    document.getElementById('unique_url_container').style.display = (tabName == 'tab3' ? '' : 'none');
    document.body.setAttribute('id', tabName);
};


/*
    ui.applyUrlFilter( url )

    Called when a user clicks on a URL. Adds the URL filter and reloads the page.
*/

ui.applyUrlFilter = function(url) {
    trends.filters.setUrl(url);
    ui.reload();
};


/*
    ui.applyDomainFilter( domain )

    Called when a user clicks on a domain.  Adds the domain filter and reloads the page.
*/
ui.applyDomainFilter = function(domain) {
    trends.filters.setDomain(domain);
    ui.reload();
};


/*
    ui.applyDateFilter( date )

    Called when a user clicks on a date.  Adds the date filter and reloads the page.
    The date argument should be the result of calling toDateString() on a Date object.
*/
ui.applyDateFilter = function(day) {
    trends.filters.setDate(day);
    ui.reload();
};


/*
    ui.applyRemoveAllFilters()

    Called when a user clicks the "Clear All Filters" button.  Removes all filters and reloads the page.
*/
ui.applyRemoveAllFilters = function() {
    trends.filters.removeAll();
    ui.reload();
};


/*
    ui.applyRemoveFilter( filter )

    Called when a user clicks the "Clear" button for a filter.  Removes the filter and reloads the page.
*/
ui.applyRemoveFilter = function(filter) {
    trends.filters.remove(filter);
    ui.reload();
};

/*
    ui.applyLimiter( value )

    Called when a user changes the limiter option.  Sets the new limiter and reloads the page.
*/
ui.applyLimiter = function(value) {
    trends.prefs.setLimiter(value);
    trends.prefs.persist(function() { ui.reload(); });
};


// Display a list of current filters along with a "Clear All" button
ui.createFilterDiv = function(events) {
    let filterDiv = document.createElement('div');
    filterDiv.setAttribute('id', 'filters');

    let filters = trends.filters.getAll();
    if (!filters) {
        return filterDiv;
    }

    let html = chrome.i18n.getMessage('results_filtered') + '<br />';
    let filterCount = 0;
    for (let i = 0; i < filters.length; i++) {
        let obj = filters[i];
        ++filterCount;
        let id = "removeFilter" + filterCount;
        html += 
            '<div class="filter_value">' + 
                `<span id="filterValue${filterCount}">${ui.getFilterDisplayValue(obj.key, obj.value)}</span>` +
                '&nbsp;&nbsp;&nbsp;' + 
                '<input id="' + id + '" type="submit" value="' + chrome.i18n.getMessage('clear') + '" />' +
            ' </div>';
        // use a closure to preserve the value of key
        let generate_callback = function(key) {
            return function() { ui.applyRemoveFilter(key); };
        };
        events.click[id] = generate_callback(obj.key);
    }
    if (filterCount > 1) {
        html += 
            '<div class="filter_value">' +
            '<input id="clear_all" type="submit" value="' + chrome.i18n.getMessage('clear_all') + '" />' +
            '</div>'
        ;
        events.click.clear_all = ui.applyRemoveAllFilters;
    }
    filterDiv.innerHTML += html;
    
    return filterDiv;
};

ui.getFilterDisplayValue = function(key, value) {
    if (key == "url") {
        return "URL";
    }
    else if (key == "domain") {
        return value;
    }
    else if (key == "date") {
        return trends.prefs.getTrendsDateDisplay(value);
    }
    else if (key == "hour") {
        return trends.prefs.getHourDisplay(value);
    }
    else if (key == "weekday") {
        return trends.prefs.getWeekdayDisplay(value);
    }
    else if (key == "monthday") {
        return value;
    }
    else if (key == "month") {
        return trends.prefs.getMonthDisplay(value);
    }
    else if (key == "year") {
        return value;
    }
    else if (key == "transition") {
        return value;
    }

    utils.logError("unrecognized key: " + key + ", value: " + value);
};


// Display a count of URLs visited and number of times visited.
ui.populateCounts = function(stats) {
    let historyItemsDisplay = trends.prefs.getNumberDisplay( stats.historyItems );
    let visitItemsDisplay = trends.prefs.getNumberDisplay( stats.visitItems );

    document.getElementById('counts').appendChild(
        document.createTextNode(
            chrome.i18n.getMessage('url_stats', [historyItemsDisplay, visitItemsDisplay])
        )
    );
};

ui.createLimiterDiv = function(events) {
    let limiterDiv = document.createElement('div');
    limiterDiv.setAttribute('id', 'limiter_container');

    limiterDiv.appendChild( document.createTextNode( chrome.i18n.getMessage('limiter_label') ) );
    let select = document.createElement('select');
    select.setAttribute('id', 'limiter');
    select.setAttribute("name", "limiter");

    let options = [
        "limiter_7",
        "limiter_30",
        "limiter_90",
        "limiter_180",
        "limiter_365",
        "limiter_all"
    ];

    let currentLimiter = trends.prefs.getLimiter();

    for (let i = 0; i < options.length; i++) {
        let value = options[i];
        let option = document.createElement('option');
        option.setAttribute("value", value);

        if (value == currentLimiter) {
            option.setAttribute("selected", "selected");
        }

        option.appendChild( document.createTextNode( chrome.i18n.getMessage( value ) ) );
        select.appendChild( option );
    }

    events.change.limiter = function(e) {
        ui.applyLimiter(e.target.value);
    };

    limiterDiv.appendChild( select );
    return limiterDiv;
};

// Set up the tabs container
ui.createTabsContainer = function(events) {
    let tabsDiv = document.createElement('div');
    tabsDiv.setAttribute('id', 'tab_container');
    
    let domainTabName = chrome.i18n.getMessage('domain_tab_name');
    let urlTabName = chrome.i18n.getMessage('url_tab_name');
    let uniqueUrlTabName = chrome.i18n.getMessage('unique_url_tab_name');
    
    tabsDiv.innerHTML =
        '<ul id="tabnav">' +
            '<li class="tab1"><a id="tablink1" href="javascript:void(0);">' + domainTabName + '</a></li>' +
            '<li class="tab2"><a id="tablink2" href="javascript:void(0);">' + urlTabName + '</a></li>' +
            '<li class="tab3"><a id="tablink3" href="javascript:void(0);">' + uniqueUrlTabName + '</a></li>' +
        '</ul>'
    ;
    
    events.click.tablink1 = function(e) { ui.switchTab('tab1'); e.preventDefault(); };
    events.click.tablink2 = function(e) { ui.switchTab('tab2'); e.preventDefault(); };
    events.click.tablink3 = function(e) { ui.switchTab('tab3'); e.preventDefault(); };

    return tabsDiv;
};


ui.createTab = function(tabName, activeTab, props, events) {
    let tabContainer = ui.createTable(props, events);

    // Hide the tab if it's not active
    if (activeTab != tabName) {
        tabContainer.setAttribute('style', 'display: none;');
    }

    return tabContainer;
};


/*
    ui.createTable(props, events)

    The props argument contains the following keys/values:
        rows:               array of domain/url objects
        rowIdPrefix:        id prefix for each domain/url link
        onclickFunction:    applyDomainFilter/applyUrlFilter
        linkTitle:          'Filter by this Domain/URL'
        containerId:        'domain_container'/'url_container'
        tableClass:         class for table tag
        tableHeaders:       hash mapping "normal"/"popup" to array of column names
        dataTableColumns:   array to pass to aoColumns property of dataTable()
        columnFormats:      one-letter format codes for each column:
                            t => text (i.e., no formatting)
                            d => date string
                            p => integer percent
                            n => integer
        filterTextBoxId:    Id of textbox for custom domain/url
        filterSubmitId:     Id of submit button for custom domain/url
        filterText:         'Filter by domain: '/'Filter by URL: '
        filterPlaceholder:  'example.com'/'http://www.example.com/'
*/

ui.createTable = function(props, events) {
    let container = document.createElement('div');
    container.setAttribute('id', props.containerId);
    container.setAttribute('class', 'light_background');
    
    let maxRows = props.rows.length > 10 ? 10 : props.rows.length;
    let tableRows = ui.createTableRows(props, 0, maxRows);

    let smallHeaderColumns = [];
    for (let i = 0; i < props.tableHeaders.normal.length; i++) {
        smallHeaderColumns.push( [ chrome.i18n.getMessage( props.tableHeaders.normal[i] ), { 'class': 'col' + (i + 1) } ] );
    }

    let tableClass = props.tableClass ? ' ' + props.tableClass : '';

    container.appendChild(
        ui.buildTable(
            smallHeaderColumns,
            tableRows, 
            { 
                id: props.tableId, 
                'class': 'top10 main_table' + tableClass
            }
        )
    );

    // Display controls to search for a specific Domain or URL

    let bottomRowDiv = document.createElement('div');
    bottomRowDiv.setAttribute('class', 'tab_bottom_row');
    
    if (props.filterTextBoxId) {
        let filterDiv = document.createElement('div');
        filterDiv.setAttribute('class', 'filter_controls');
        filterDiv.appendChild(document.createTextNode(props.filterText));

        let filterText = document.createElement('input');
        filterText.setAttribute('id', props.filterTextBoxId);
        filterText.setAttribute('type','text');
        filterText.setAttribute('placeholder', props.filterPlaceholder);
        filterText.setAttribute('size','35');
        filterDiv.appendChild(filterText);
        
        let filterButton = document.createElement('input');
        filterButton.setAttribute('type', 'submit');
        filterButton.setAttribute('id', props.filterSubmitId);
        filterButton.setAttribute('value', chrome.i18n.getMessage('go'));
        filterDiv.appendChild(filterButton);
    
        bottomRowDiv.appendChild(filterDiv);
        events.click[props.filterSubmitId] = function() { 
            props.onclickFunction(document.getElementById(props.filterTextBoxId).value);
        };
        events.keyup[props.filterTextBoxId] = function (e) {
            if (e.which == 13) {
                props.onclickFunction(document.getElementById(props.filterTextBoxId).value);
            }
        };
    }


    if (props.rows.length > 10) {
        // Create a hidden div containing content for the View More Domains/URLs link

        let moreMaxRows = props.rows.length > 100 ? 100 : props.rows.length;
        let moreTableRows = ui.createTableRows(props, 0, moreMaxRows);

        let popupHeaderColumns = [];
        for (let i = 0; i < props.tableHeaders.popup.length; i++) {     // eslint-disable-line no-redeclare
            popupHeaderColumns.push( [ chrome.i18n.getMessage( props.tableHeaders.popup[i] ), { 'class': 'col' + (i + 1) } ] );
        }
        let moreTableId = props.tableId + '_more';
        let hiddenDiv = document.createElement('div');
        let hiddenDivId = props.containerId + '_more';
        hiddenDiv.setAttribute('id', hiddenDivId);
        hiddenDiv.appendChild(
            ui.buildTable(
                popupHeaderColumns,
                moreTableRows, 
                {
                    id: moreTableId,
                    'class': 'top10 main_table light_background popup' + tableClass 
                }
            )
        );
        let hiddenParentDiv = document.createElement('div');
        hiddenParentDiv.setAttribute('style', 'display: none;');
        hiddenParentDiv.appendChild(hiddenDiv);

        container.appendChild(hiddenParentDiv);

        // Display a link to View More of the top URLs

        let viewMoreAnchor = document.createElement('a');
        let viewMoreAnchorId = hiddenDivId + '_link';
        viewMoreAnchor.setAttribute('href', 'javascript:void(0);');
        viewMoreAnchor.setAttribute('id', viewMoreAnchorId);
        viewMoreAnchor.appendChild(document.createTextNode(chrome.i18n.getMessage('view_more')));

        let generate_callback = function(divId, tableId) {
            return function(e) { 
                $.colorbox({
                    inline:true, 
                    transition: 'none',
                    fadeOut: 0,
                    href:"#" + divId, 
                    height:"85%", 
                    width: props.popupWidth,
                    onComplete: function() {
                        $("#" + tableId ).dataTable({
                            aaSorting: [[1, "desc"]],
                            aoColumns: props.dataTableColumns,
                            bAutoWidth: false,
                            bPaginate: false,
                            bProcessing: false,
                            bSort: true,
                            bStateSave: false,
                            bFilter: false,
                            bInfo: false,
                            bRetrieve: true
                        });
                    }
                }); 
                e.preventDefault();
            };
        };
        events.click[viewMoreAnchorId] = generate_callback(hiddenDivId, moreTableId);

        let viewMoreDiv = document.createElement('div');
        viewMoreDiv.setAttribute('class', 'tab_view_more');
        viewMoreDiv.appendChild(viewMoreAnchor);
        
        bottomRowDiv.appendChild(viewMoreDiv);
    }
    
    container.appendChild(bottomRowDiv);

    return container;
};


ui.createTableRows = function(props, startIndex, stopIndex) {
    let tableRows = [];

    for (let i = startIndex; i < stopIndex; i++) {
        let row = [];
        let text = ui.formatValue( props.rows[i][0], props.columnFormats[0] );
        let anchor = document.createElement('a');
        let id = props.rowIdPrefix + i;
        anchor.setAttribute('href', 'javascript:void(0);');
        anchor.setAttribute('id', id);
        anchor.setAttribute('title', props.linkTitle);
        anchor.setAttribute('data-sort', props.rows[i][0]);
        anchor.appendChild( document.createTextNode(text) );
        row.push( anchor );

        for (let j = 1; j < props.rows[i].length; j++) {
            let rawValue = props.rows[i][j];
            let formattedValue = ui.formatValue( rawValue, props.columnFormats[j] );

            let span = document.createElement('span');
            span.setAttribute( 'data-sort', rawValue );
            span.appendChild( document.createTextNode(formattedValue) );

            row.push( span );
        }

        tableRows.push( row );
    }

    return tableRows;
};



ui.createDailyStats = function(stats) {
    // Create a link to filter for Today's visits

    let todayLink = document.createElement('a');
    let todayLinkId = 'todaylink';
    todayLink.setAttribute('href', 'javascript: void(0);');
    todayLink.setAttribute('id', todayLinkId);
    todayLink.setAttribute('title', chrome.i18n.getMessage('today_hover_text'));
    todayLink.setAttribute('data-sort', new Date().getTime());
    todayLink.appendChild(document.createTextNode(chrome.i18n.getMessage('today')));

    // Display the Daily Stats table

    let container = document.createElement('div');
    container.setAttribute('id', 'per_day_stats_container');
    container.setAttribute('class', 'light_background');
    
    let mean_visits_text = chrome.i18n.getMessage('mean_visits');
    let median_visits_text = chrome.i18n.getMessage('median_visits');
    let not_applicable_text = chrome.i18n.getMessage('not_applicable');
    
    let busiestDayMeanDisplay;
    if (stats.busiestDayMean) {
        busiestDayMeanDisplay = trends.prefs.getNumberDisplay( stats.busiestDayMean );
    }

    let busiestDayMedianDisplay;
    if (stats.busiestDayMedian) {
        busiestDayMedianDisplay = trends.prefs.getNumberDisplay( stats.busiestDayMedian );
    }

    let todayCountDisplay;
    let todayCount = stats.byBusiestDay[ (new Date()).toDateString() ];
    if (todayCount) {
        todayCountDisplay = trends.prefs.getNumberDisplay( todayCount );
    }

    container.appendChild(
        ui.buildTable(
            [
                [chrome.i18n.getMessage('daily_stats'), {}],
                ['', {}]
            ],
            [
                [document.createTextNode(mean_visits_text), ui.spanWrap('meanVisits', (busiestDayMeanDisplay || not_applicable_text))],
                [document.createTextNode(median_visits_text), ui.spanWrap('medianVisits', (busiestDayMedianDisplay || not_applicable_text))],
                [todayLink, ui.spanWrap('todayVisits', (todayCountDisplay || not_applicable_text))]
            ],
            { id: 'per_day_stats', 'class': 'top10 light_background' }
        )
    );

    return container;
};

ui.spanWrap = function( id, text ) {
    let span = document.createElement('span');
    span.setAttribute('id', id);
    span.appendChild(
        document.createTextNode(text)
    );
    return span;
};


ui.createVisitDateStats = function(stats) {
    let oldest_visit_text   = chrome.i18n.getMessage('min_visit_date');
    let newest_visit_text   = chrome.i18n.getMessage('max_visit_date');
    let not_applicable_text = chrome.i18n.getMessage('not_applicable');

    let minVisitElement;
    let minVisitId = 'minVisitLink';
    if (stats.minVisitTime) {
        let minVisitTimeDisplay = trends.prefs.getTrendsDateDisplay( Number.parseFloat(stats.minVisitTime) );

        minVisitElement = document.createElement('a');
        minVisitElement.setAttribute('href', 'javascript: void(0);');
        minVisitElement.setAttribute('id', minVisitId);
        minVisitElement.setAttribute('title', chrome.i18n.getMessage('day_hover_text'));
        minVisitElement.setAttribute('data-sort', stats.minVisitTime);
        minVisitElement.appendChild(document.createTextNode(minVisitTimeDisplay));
    }
    else {
        minVisitElement = ui.spanWrap( minVisitId, not_applicable_text );
    }

    let maxVisitElement;
    let maxVisitId = 'maxVisitLink';
    if (stats.maxVisitTime) {
        let maxVisitTimeDisplay = trends.prefs.getTrendsDateDisplay( Number.parseFloat(stats.maxVisitTime) );

        maxVisitElement = document.createElement('a');
        maxVisitElement.setAttribute('href', 'javascript: void(0);');
        maxVisitElement.setAttribute('id', maxVisitId);
        maxVisitElement.setAttribute('title', chrome.i18n.getMessage('day_hover_text'));
        maxVisitElement.setAttribute('data-sort', stats.maxVisitTime);
        maxVisitElement.appendChild(document.createTextNode(maxVisitTimeDisplay));
    }
    else {
        maxVisitElement = ui.spanWrap( maxVisitId, not_applicable_text );
    }

    let container = document.createElement('div');
    container.setAttribute('id', 'visit_date_stats_container');
    container.setAttribute('class', 'light_background');
    
    container.appendChild(
        ui.buildTable(
            [
                [chrome.i18n.getMessage('visit_dates'), { 'colspan': 2 }]
            ],
            [
                [ document.createTextNode(oldest_visit_text), minVisitElement ],
                [ document.createTextNode(newest_visit_text), maxVisitElement ]
            ],
            { id: 'visit_date_stats', 'class': 'top10' }
        )
    );

    return container;
};


ui.createClearDiv = function() {
    let clear_div = document.createElement('div');
    clear_div.setAttribute('style', 'clear: both;');
    return clear_div;
};


ui.createDomainBackLink = function(events) {
    let backDiv = document.createElement('div');
    backDiv.setAttribute('id', 'back_domain');

    let domain = trends.filters.getDomain();
    if (domain) { 
        let newDomain = utils.stripSubDomain(domain);
        if (newDomain) {
            let id = 'back_domain_link';
            let anchor = document.createElement('a');
            anchor.setAttribute('href', 'javascript:void(0);');
            anchor.setAttribute('id', id);
            anchor.appendChild(document.createTextNode(chrome.i18n.getMessage('return_to', newDomain)));
            backDiv.appendChild(anchor);

            events.click[id] = function(e) { 
                ui.applyDomainFilter(newDomain);
                e.preventDefault();
            };
        }
    }

    return backDiv;
};

ui.formatValue = function( value, code ) {
    let formatted;

    if (code == "p") {
        formatted = trends.prefs.getPercentDisplay( value );
    }
    else if (code == "n") {
        formatted = trends.prefs.getNumberDisplay( value );
    }
    else if (code == "d") {
        formatted = trends.prefs.getTrendsDateDisplay( value );
    }
    else {
        formatted = value;
    }

    return formatted;
};

ui.reload = function() {
    window.location = window.location;  // eslint-disable-line no-self-assign
};


