// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils, saveAs */

class HistoryWorker {   // eslint-disable-line no-unused-vars
    constructor(prefs) {
        this.prefs = prefs;
        this.callbacks = {};
        const instance = this;

        this.worker = new Worker( utils.workerUrl('worker.js') );
        this.worker.addEventListener('message', function(evt) {
            let response = evt.data;
            if ( response.command === 'historySynced' ) {
                utils.logInfo(`Setting last history sync time: ${response.maxVisitTimeSeen}`);
                instance.prefs.setLastHistorySyncTime( response.maxVisitTimeSeen );
                instance.prefs.persist();
            }
            else if ( response.command == 'download' ) {
                saveAs( response.url, response.filename );
                setTimeout(function() { URL.revokeObjectURL(response.url); }, 60_000);

                if ( response.isLast ) {
                    utils.logInfo(`Download complete.`);
                }
            }
            else {
                let callback = instance.callbacks[response.command];
                if ( callback == null ) {
                    console.error(response);
                    throw new Error(`No callback regsitered for ${response.callback}`);
                }

                if (response.error != null) {
                    callback.onError(response.error);
                }
                else if ( response.statusUpdate != null ) {
                    callback.onStatusUpdate?.(response.statusUpdate);
                }
                else {
                    callback.onComplete(response);
                }
            }
        });
    }

    async run(command, props) {
        this.callbacks[command] = {
            onComplete: props.onComplete,
            onError: props.onError,
            onStatusUpdate: props.onStatusUpdate
        };

        let history;
        if ( props.syncHistory ) {
            this.callbacks[command].onStatusUpdate?.("Finding local history");
            history = await HistoryWorker.getHistory(this.prefs);
        }

        this.worker.postMessage({
            storage: this.prefs.storage(),
            history: history,
            command: command,
            workerArguments: props.workerArguments
        });
    }

    // getHistory() return value:
    //  {
    //      results: [
    //          {
    //              url: 'https://www.example.com/',
    //              title: 'Example Page Title',
    //              visits: [
    //                  { transition: <string>, visitTime: <integer in milliseconds> },
    //                  ...
    //              ]
    //          },
    //          ...
    //      ],
    //      maxVisitTimeSeen: <integer in milliseconds>
    //      syncStartTime: <integer in milliseconds>
    //  }
    static async getHistory(prefs) {
        let lastSyncTime  = prefs.lastHistorySyncTime();
        let nowMilliseconds = Date.now();

        // Ignore the lastSyncTime if it's in the future.
        if ( lastSyncTime && (lastSyncTime > nowMilliseconds) ) {
            utils.logInfo(`Ignoring a last sync time in the future: ${ (new Date(lastSyncTime).toString()) }`);
            lastSyncTime = 0;
        }

        let syncStartTime = lastSyncTime + 1;
        utils.logInfo(`Finding visits since ${syncStartTime}`);

        let historyItems = await chrome.history.search({
            'text': '',                // Return every history item....
            'maxResults': 1000000000,  // Have to specify something, so why not a billion?
            'startTime': syncStartTime
        });

        let results = [];
        let ignoreMilliseconds = prefs.ignoreVisitsDurationInSeconds() * 1000;
        let maxVisitTimeSeen = syncStartTime;

        for (const historyItem of historyItems) {
            let visitItems = await chrome.history.getVisits({ url: historyItem.url });
            let acceptableVisits = [];

            // Sort by visitTime, ascending.
            visitItems.sort(function(a, b) { return a.visitTime - b.visitTime; });

            let previousVisitTime = 0;
            for (const visitItem of visitItems) {
                let currentVisitTime = visitItem.visitTime;

                // Ignore visits prior to the syncStartTime.
                if (currentVisitTime < syncStartTime) {
                    continue;
                }

                // Ignore visits that occurred too close to the previous visit.
                if ( currentVisitTime - previousVisitTime > ignoreMilliseconds ) {
                    acceptableVisits.push({
                        transition: visitItem.transition,
                        visitTime:  visitItem.visitTime
                    });
                }
                previousVisitTime = currentVisitTime;

                // Track the highest visit time seen, being careful to ignore future visits.
                if ((currentVisitTime <= nowMilliseconds) && (currentVisitTime > maxVisitTimeSeen)) {
                    maxVisitTimeSeen = currentVisitTime;
                }
            }

            results.push({
                url: historyItem.url,
                title: historyItem.title,
                visits: acceptableVisits
            });
        }

        return {
            results: results,
            maxVisitTimeSeen: maxVisitTimeSeen,
            syncStartTime: syncStartTime
        };
    }
}


