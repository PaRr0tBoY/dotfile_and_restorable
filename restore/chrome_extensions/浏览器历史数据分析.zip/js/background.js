// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals Preferences, utils, HistoryWorker */

importScripts(
    'utils.js',
    'preferences.js',
    'historyWorker.js'
);

chrome.action.onClicked.addListener(async function() {
    let prefs = await Preferences.fetch();
    let page = "trends.html";
    if (prefs.startPage() == "search") {
        page = "search.html";
    }
    chrome.tabs.create({url:chrome.runtime.getURL( page )});
});


chrome.runtime.onStartup.addListener(async function() {
    utils.logInfo('background: Startup process begun');

    let prefs = await Preferences.fetch();
    let history = await HistoryWorker.getHistory(prefs);

    utils.logInfo('background: Creating offscreen document');

    let reasons = [];
    if ( chrome.offscreen.Reason.WORKERS ) {
        reasons.push('WORKERS');
    }
    if ( chrome.offscreen.Reason.BLOBS ) {
        reasons.push('BLOBS');
    }

    await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: reasons,
        justification: "Use SQLite WASM to export the user's data"
    });

    utils.logInfo('background: Posting autoBackupIfNeeded message to offscreen document');

    chrome.runtime.sendMessage({
        target:  'offscreen',
        command: 'autoBackupIfNeeded',
        storage: prefs.storage(),
        history: history,
        workerArguments: {}
    });
});


chrome.runtime.onMessage.addListener(
    async function(message) {
        if (message.target !== 'background') {
            utils.logInfo(`background: Target is not background (got '${message.command}')`);
            return;
        }

        if (message.command != 'log') {
            utils.logInfo(`background: Received ${message.command} message`);
        }

        for (const msg of (message.logInfo || [])) {
            utils.logInfo(msg);
        }
        for (const msg of (message.logError || [])) {
            utils.logError(msg);
        }

        if (message.command == 'historySynced') {
            utils.logInfo(`background: Setting last history sync time: ${message.maxVisitTimeSeen}`);
            let prefs = await Preferences.fetch();
            prefs.setLastHistorySyncTime( message.maxVisitTimeSeen );
            await prefs.persist();
        }
        else if (message.command == 'autoBackupIfNeeded') {
            if ( message.lastAutoBackupDate ) {
                utils.logInfo(`background: Setting last autoBackup date: ${message.lastAutoBackupDate}`);
                let prefs = await Preferences.fetch();
                prefs.setLastAutoBackupDate( message.lastAutoBackupDate );
                await prefs.persist();
                utils.logInfo('background: Closing offscreen document');
                setTimeout( () => chrome.offscreen.closeDocument(), 5_000 );
            }
            else {
                utils.logInfo('background: autoBackup not needed. Closing offscreen document');
                await chrome.offscreen.closeDocument();
            }
        }
        else if (message.command == 'log') {
            // Handled by logInfo/logError above.
        }
        else {
            throw new Error(`Unrecognized command: '${message.command}'`);
        }
    }
);
