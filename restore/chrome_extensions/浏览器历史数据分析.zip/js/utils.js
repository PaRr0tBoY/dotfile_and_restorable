// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals public_suffix */

let utils = {};

utils.stripSubDomain = function(host) {
    if (host == public_suffix.get_root_domain(host)) {
        return;
    }
    let matches = host.match(/^[^.]+\.([^.]+\..+)$/);
    return matches ? matches[1] : undefined;
};

/* 
    utils.getActiveTab()
    
    Returns the active tab.  Defaults to 'tab1' if no active tab is set. 
*/

utils.getActiveTab = function() {
    let activeTab = window.sessionStorage.getItem('activeTab');
    if (!activeTab || (activeTab != 'tab1' && activeTab != 'tab2' && activeTab != 'tab3')) {
        activeTab = 'tab1';
        window.sessionStorage.setItem('activeTab', activeTab);
    }
    return activeTab;
};

/*
    utils.getDomainPortion(host, baseDomain)
    
    For the given host, returns a portion of the domain name.
    If baseDomain is empty, returns the root domain.
    If baseDomain is populated, returns the baseDomain plus the next subdomain, if it exists.
    
    Examples:  
        utils.getDomainPortion('www.blog.example.com') returns 'example.com'
        utils.getDomainPortion('www.blog.example.com', 'example.com') returns 'blog.example.com'
        utils.getDomainPortion('www.blog.example.com', 'blog.example.com') returns 'www.blog.example.com'
*/

utils.getDomainPortion = function(host, baseDomain) {
    let domain;
    host = host || '';
    baseDomain = baseDomain || '';
    
    if (baseDomain.length) {
        let regex = new RegExp('[^.]*\\.?' + utils.escapeDots(baseDomain) + '$');
        let matches = host.match(regex);
        domain = matches ? matches[0] : undefined;
    }
    else {
        domain = public_suffix.get_root_domain(host);
    }
    
    return domain;
};


/*
    utils.extractHost(url)
  
    Returns the hostname portion of the given url.
    Example:
        utils.extractHost('http://www.example.com/?x=1') returns 'www.example.com'
 */
utils.extractHost = function(url) {
    let matches = url.match(/^.+?:\/\/(?:[^:@]+:[^@]+@)?([^/?:]+)/);
    return matches ? matches[1] : undefined;
};

/*
 * utils.formatTitle(title)
 *
 * Replaces tabs and newlines/returns with a single space,
 * then removes consecutive whitespaces.
 *
 */

utils.formatTitle = function(title) {
    if (title == null) {
        return null;
    }

   title = title.replace(/[\t\r\n]/g, ' ');
   title = title.replace(/\s\s+/g, ' ');
    
   return title.trim();
};


utils.escapeDots = function(string) {
    return string.replace(/\./g, '\\.');
};


// Date obj to YYYY-MM-DD
utils.dateToString = function(date, separator) {
    if (separator == null) {
        separator = '-';
    }
    let year = date.getFullYear();
    let month = utils.padZero(date.getMonth() + 1);
    let day = utils.padZero(date.getDate());
    return year + separator + month + separator + day;
};

// Date obj to YYYY-MM-DD HH24:MI:SS.FFF
utils.dateToStringLong = function(date) {
    let year = date.getFullYear();
    let month = utils.padZero(date.getMonth() + 1);
    let day = utils.padZero(date.getDate());
    let hour = utils.padZero(date.getHours());
    let minute = utils.padZero(date.getMinutes());
    let second = utils.padZero(date.getSeconds());
    let millisecond = utils.padZero(date.getMilliseconds(), 3);
    return year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second + '.' + millisecond;
};

// Date obj to YYYYMMDDHH24MISS
utils.dateToTimestamp = function(date, dateTimeSeparator) {
    if (dateTimeSeparator == null) {
        dateTimeSeparator = "";
    }
    let year = date.getFullYear();
    let month = utils.padZero(date.getMonth() + 1);
    let day = utils.padZero(date.getDate());
    let hour = utils.padZero(date.getHours());
    let minute = utils.padZero(date.getMinutes());
    let second = utils.padZero(date.getSeconds());
    return year + month + day + dateTimeSeparator + hour + minute + second;
};

utils.padZero = function(number, length) {
    let numString = number.toString();
    let zero = '0';
    length = length || 2;

    while(numString.length < length) {
        numString = zero + numString;
    }

    return numString;
};

// YYYY-MM-DD to Date obj
utils.stringToDate = function(string) {
    let year = string.substr(0,4);
    let month = parseInt(string.substr(5,2)) - 1;
    let day = string.substr(8,2);
    return new Date(year, month, day);
};

/* Statistics utilities */

utils.calcMedian = function(values) {
    let median;

    if (!values.length) {
        return;
    }
    else if (values.length % 2 == 0) {
        let middle = values.length / 2;
        let lower_middle = values[ middle - 1 ];
        let upper_middle = values[ middle ];
        median = utils.calcMean([lower_middle, upper_middle]);
    }
    else {
        let middle = Math.floor( values.length / 2 );   // eslint-disable-line no-redeclare
        median = values[middle];
    }

    return median;
};


utils.calcMean = function(values) {
    if (!values.length) {
        return;
    }
    
    let sum = 0;
    for (let i = 0; i < values.length; i++) {
        sum += values[i];
    }
    return( Math.round(sum/values.length, 0) );
};


/* Time Conversion utilities */

utils.logError = function(msg) {
    console.log( utils.getLogMessage('ERROR', msg) );
};

utils.logWarning = function(msg) {
    console.log( utils.getLogMessage('WARNING', msg) );
};

utils.logInfo = function(msg) {
    console.log( utils.getLogMessage('INFO', msg) );
};

utils.getLogMessage = function(prefix, msg) {
    let date = new Date();
    let dateString = 
        date.getFullYear() + '-' + 
        utils.padZero(date.getMonth() + 1) + '-' +
        utils.padZero(date.getDate()) + ' ' +
        utils.padZero(date.getHours()) + ':' +
        utils.padZero(date.getMinutes()) + ':' +
        utils.padZero(date.getSeconds()) + '.' +
        utils.padZero(date.getMilliseconds(), 3)
    ;
    return(dateString + ": " + prefix + ": " + msg);
};


/* Import/Export Utilities */

// As of 2013-03-02, chrome's transition types were located here:
// https://src.chromium.org/viewvc/chrome/trunk/src/content/public/common/
// in the following files:
//  * page_transition_types_list.h
//  * page_transition_types.cc
utils.convertTransitionToText = function(transition) {
    if (/^-?\d+$/.test(transition)) {
        let types = [
            "link", 
            "typed", 
            "auto_bookmark", 
            "auto_subframe", 
            "manual_subframe", 
            "generated", 
            "auto_toplevel", 
            "form_submit", 
            "reload", 
            "keyword", 
            "keyword_generated" 
        ];
        let typeId = transition & 0xFF;
        if (typeId < types.length) {
            return types[typeId];
        }
        else {
            utils.logWarning("import: unrecognized transition id: " + typeId);
            return "unknown";
        }
    }

    return transition;
};

utils.convertTextToTransition = function(text) {
    let definitions = {
        "link": 0,
        "typed": 1, 
        "auto_bookmark": 2,
        "auto_subframe": 3,
        "manual_subframe": 4,
        "generated": 5,
        "auto_toplevel": 6,
        "form_submit": 7,
        "reload": 8,
        "keyword": 9,
        "keyword_generated": 10 
    };
    return definitions[text];
};

// Converts: milliseconds since 1601-01-01 00:00:00 UTC 
// to:       milliseconds since 1970-01-01 00:00:00 UTC
utils.convertToUnixEpoch = function(visitTime) {
    return( (visitTime - 11644473600000000) / 1000 );
};

// Converts:       milliseconds since 1970-01-01 00:00:00 UTC
// To:             milliseconds since 1601-01-01 00:00:00 UTC 
utils.convertToWindowsEpoch = function(visitTime) {
    return( (visitTime * 1000) + 11644473600000000 );
};


utils.limiterToVisitTime = function( limiter, now_ms ) {
    let offset_ms;
    let one_day_ms = 24 * 60 * 60 * 1000;

    if (limiter == "limiter_all") {
        offset_ms = now_ms;
    }
    else if (limiter == "limiter_365") {
        offset_ms = 365 * one_day_ms;
    }
    else if (limiter == "limiter_180") {
        offset_ms = 180 * one_day_ms;
    }
    else if (limiter == "limiter_90") {
        offset_ms = 90 * one_day_ms;
    }
    else if (limiter == "limiter_30") {
        offset_ms = 30 * one_day_ms;
    }
    else if (limiter == "limiter_7") {
        offset_ms = 7 * one_day_ms;
    }

    return now_ms - offset_ms;
};


/* Search utils */

utils.highlightMatches = function(title, keywords) {
    let newKeywords = keywords.replace('*','');
    let escapedKeywords = utils.escapeRegExp( newKeywords );
    let regex = new RegExp('(^|\\W)(' + escapedKeywords + ')', 'gi');
    return title.replace(regex, '$1<b>$2</b>');
};

utils.htmlEscape = function(str) {
    return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
};

utils.parseYears = function( years ) {
    return utils.integerRangeToArray( years, /^\d{4}$/ );
};

utils.parseMonthDays = function( monthdays ) {
    return utils.integerRangeToArray( monthdays, /^\d\d?$/, 1, 31 );
};

utils.parseHours = function( hours ) {
    return utils.integerRangeToArray( hours, /^\d\d?$/, 0, 23 );
};

utils.integerRangeToArray = function(text, regex, minAllowedValue, maxAllowedValue) {
    if ( text == undefined ) {
        return;
    }
    let values = text.split( /\s*,\s*/ );
    let range = [];
    for (let i = 0; i < values.length; i++) {
        let value = values[i].trim();
        let minmax = value.split( /\s*-\s*/, 2 );
        if ( minmax.length == 1 ) {
            // Got a single value
            let single_value = minmax[0];
            if ( !single_value.match( regex ) ) {
                continue;
            }
            single_value = Number.parseInt(single_value);
            if ( Number.isNaN( single_value ) ) {
                continue;
            }
            if ( minAllowedValue != undefined && single_value < minAllowedValue ) {
                continue;
            }
            if ( maxAllowedValue != undefined && single_value > maxAllowedValue ) {
                continue;
            }
            range.push( single_value );
        }
        else {
            // Got a range of values.
            let min = minmax[0];
            let max = minmax[1];
            if ( !min.match(regex) || !max.match(regex) ) {
                continue;
            }
            min = Number.parseInt(min);
            max = Number.parseInt(max);
            if ( Number.isNaN(min) || Number.isNaN(max) ) {
                continue;
            }
            if ( min > max ) {
                continue;
            }
            if ( minAllowedValue != undefined && (min < minAllowedValue || max < minAllowedValue) ) {
                continue;
            }
            if ( maxAllowedValue != undefined && (min > maxAllowedValue || max > maxAllowedValue) ) {
                continue;
            }
            for (let j = min; j <= max; j++) {
                range.push( j );
            }
        }
    }

    if (!range.length) {
        return;
    }

    return range;
};

utils.textToArray = function( text ) {
    if ( text == undefined ) {
        return;
    }
    let values = text.split( /\s*,\s*/ );
    let array = [];
    for (let i = 0; i < values.length; i++) {
        let value = values[i].trim();
        if ( value.match( /[a-z0-9]/i ) ) {
            array.push( value );
        }
    }

    if (!array.length) {
        return;
    }

    return array;
};

utils.getPaginationText = function( type, pageNumber, visitCount ) {
    let desc = 'Page ' + pageNumber + ' of ';

    if ( type == 'all' ) {
        desc += 'all history';
    }
    else {
        desc += visitCount + ' visit' + (visitCount != 1 ? 's' : '');
    }

    return desc;
};


// Extract 'date:YYYY-MM-DD' from the keywords for basic searches
utils.extractDateFromKeywords = function(keywords) {
    let criteria = {};
    let date_regex = /\bdate:\s*(\d{4}-\d\d-\d\d)\b/i;

    if ( date_regex.test(keywords) ) {
        let matches = date_regex.exec(keywords);
        let date = matches[1];
        let remaining_keywords = keywords.replace( date_regex, '' ).trim();
        criteria = { date: date, keywords: remaining_keywords };
    }
    else {
        criteria = { keywords: keywords };
    }

    return criteria;
};


utils.arrayToBindString = function(values) {
    if ( !Array.isArray(values) ) {
        return "";
    }
    return values.map(function() { return "?"; }).join(', ');
};

// Stolen from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions#Escaping
utils.escapeRegExp = function(string) {
    if ( string == undefined ) {
        return;
    }
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
};

/* Backup utils */

utils.backupIsNeeded = function(prefs, today) {
    if ( !prefs.autoBackup() ) {
        return false;
    }

    let lastBackupDate = prefs.lastAutoBackupDate();
    let backupInterval = prefs.autoBackupInterval();

    if ( lastBackupDate == undefined ) {
        return true;
    }

    return utils.daysBetweenDates(lastBackupDate, today) >= backupInterval;
};

utils.daysBetweenDates = function(a, b) {
    let msPerDay = 60*60*24*1000;
    // Remove the time portion of each date.
    let a_time = Date.UTC( a.getFullYear(), a.getMonth(), a.getDate() );
    let b_time = Date.UTC( b.getFullYear(), b.getMonth(), b.getDate() );
    return Math.floor( Math.abs(b_time - a_time) / msPerDay );
};

utils.lastBackedUpText = function( backupDate ) {
    if ( !backupDate ) {
        return '';
    }

    let daysBetweenDates = utils.daysBetweenDates( backupDate, new Date() );
    if ( daysBetweenDates == 0 ) {
        return 'Today';
    }
    else if ( daysBetweenDates == 1 ) {
        return 'Yesterday';
    }
    else {
        return daysBetweenDates + ' days ago';
    }
};


utils.databaseName = function() {
    return 'htu.db';
};

utils.keywordsToFTS5Query = function(keywords) {
    if (keywords == undefined || keywords == '') {
        return '';
    }
    else if (keywords.startsWith('-')) {
        throw new Error('Queries cannot begin with the exclusion character (dash)');
    }

    let parts = [];

    let tokens = keywords.trim().split(/\s+/);
    let within_phrase = false;
    let current_phrase = [];

    for (let i = 0; i < tokens.length; i++) {
        let token = tokens[i];
        let isLast = i == tokens.length - 1;

        if (within_phrase) {
            if (token.endsWith('"') && (isLast || token[token.length-2] != '"')) {
                current_phrase.push(token.substring(0, token.length-1));
                let phrase = current_phrase.join(' ');
                phrase.replaceAll( '"', '""' );
                parts.push(`"${phrase}"`);
                within_phrase = false;
                current_phrase = [];
            }
            else {
                current_phrase.push(token);
            }
        }
        else if (token.startsWith('"') && token.endsWith('"')) {
            parts.push(token);
        }
        else if (token.startsWith('"')) {
            within_phrase = true;
            current_phrase.push(token.substring(1));
        }
        else if (token.startsWith('-')) {
            parts.push('NOT');
            let newToken = token.substring(1);
            if (newToken.startsWith('"') && newToken.endsWith('"')) {
                parts.push(newToken);
            }
            else {
                parts.push(`"${newToken}"`);
            }
        }
        else if (token.endsWith('*')) {
            let newToken = token.substring(0, token.length-1);
            if (newToken.startsWith('"') && newToken.endsWith('"')) {
                parts.push(`${newToken}*`);
            }
            else {
                parts.push(`"${newToken}"*`);
            }
        }
        else if (token == 'AND' || token == 'OR') {
            parts.push(token);
        }
        else {
            parts.push('"' + token + '"');
        }
    }

    if (within_phrase) {
        throw new Error(`Phrase not ended for search ${keywords}`);
    }

    // Fill in explicit ANDs where necessary.
    let query = [];
    for (let i = 0; i < parts.length; i++) {
        let part = parts[i];
        let isLast = i == parts.length - 1;

        if (part.startsWith('"')) {
            query.push(part);
            if (!isLast && parts[i+1].startsWith('"')) {
                query.push('AND');
            }
        }
        else {
            query.push(part);
        }
    }

    return query.join(' ');
};


utils.getExportFilename = function( baseFilename, fileCount, isLastFile ) {
    if ( isLastFile && fileCount == 1 ) {
        return `${baseFilename}.tsv`;
    }
    return `${baseFilename}_part${fileCount}.tsv`;
};


utils.humanReadableBytes = function( bytes ) {
    bytes = parseInt(bytes);
    if ( Number.isNaN(bytes) ) {
        return '';
    }

    if ( bytes < 1024 ) {
        return `${bytes} bytes`;
    }

    let kb = (bytes / 1024).toFixed(0);
    if ( kb < 1024 ) {
        return `${kb} KB`;
    }

    let mb = (kb / 1024).toFixed(0);
    if ( mb < 1024 ) {
        return `${mb} MB`;
    }

    let gb = (mb / 1024).toFixed(0);
    if ( gb < 1024 ) {
        return `${gb} GB`;
    }

    let tb = (gb / 1024).toFixed(0);
    return `${tb} TB`;
};


utils.textToTransitionAsCase = function(column) {
    return `CASE ${column}
    WHEN 'link'              THEN 0
    WHEN 'typed'             THEN 1
    WHEN 'auto_bookmark'     THEN 2
    WHEN 'auto_subframe'     THEN 3
    WHEN 'manual_subframe'   THEN 4
    WHEN 'generated'         THEN 5
    WHEN 'auto_toplevel'     THEN 6
    WHEN 'form_submit'       THEN 7
    WHEN 'reload'            THEN 8
    WHEN 'keyword'           THEN 9
    WHEN 'keyword_generated' THEN 10
END`;
};


utils.sqlitePath = function() {
    return '../external/sqlite-wasm-3460100';
};


utils.sqliteFile = function() {
    return `${utils.sqlitePath()}/sqlite3.js`;
};


utils.workerUrl = function(script) {
    let params = new URLSearchParams({
        'sqlite3.dir': utils.sqlitePath()
    });
    return `js/${script}?${params.toString()}`;
};


utils.faviconURL = function(pageURL) {
    const url = new URL(chrome.runtime.getURL("/_favicon/"));
    url.searchParams.set("pageUrl", pageURL);
    url.searchParams.set("size", "16");
    return url.toString();
};


