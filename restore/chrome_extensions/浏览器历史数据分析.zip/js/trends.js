// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals HistoryWorker, Preferences, Filters, utils, ui, charts */

const trends = {
    prefs: null,
    filters: null,
    worker: null
};


$(document).ready(async function(){
    trends.prefs = await Preferences.fetch();
    trends.worker = new HistoryWorker(trends.prefs);

    trends.filters = new Filters();

    // Set up dialog box for exporting results
    $( "#trends_export" ).dialog({
        autoOpen: false,
        width: 350,
        modal: true,
        buttons: [
            {
                id: 'trends_export_button',
                text: 'Export',
                click: function() {
                    $('#trends_export_button').before(
                        '<span id="export_spinner" class="spinner-image-dialog" style="padding-right: 10px; vertical-align: middle;" />'
                    );
                    trends.worker.run('exportTrends', {
                        workerArguments: {
                            baseFilename: 'htu_analyze_' + utils.dateToTimestamp(new Date(), '_'),
                            filterJSON: trends.filters.toJSON()
                        },
                        onComplete: function() {
                            $('#export_spinner').remove();
                            $('#trends_export').dialog( "close" );
                        },
                        onError: function(message) {
                            $('#export_spinner').remove();
                            $('#trends_export_button').before(
                                `<span id="export_error_text" class="error">An error occurred: ${message}</span>&nbsp;`
                            );
                        }
                    });
                }
            },
            {
                id: 'trends_export_cancel',
                text: 'Cancel',
                click: function() {
                    $(this).dialog('close');
                }
            }
        ]
    });
 
    $( "#show_trends_export" ).on(
        'click', 
        function() {
            $( "#export_error" ).hide();
            $( "#trends_export" ).dialog( "open" );
            return false;
        }
    );
    $( "#export_more_details" ).attr('href', chrome.runtime.getURL("export_details.html"));

    trends.worker.run('calcTrends', {
        syncHistory: true,
        workerArguments: {
            filterJSON: trends.filters.toJSON()
        },
        onComplete: function({ stats }) {
            utils.logInfo("Drawing UI started");
            // Several charts must be visible for them to render correctly
            document.getElementById('waiting_container').style.display = 'none';
            document.getElementById('trends_container').style.display = 'block';
            ui.createOverview( stats, 'overview' );
            charts.drawHourChart( stats.byHour, 'chart_hour' );
            charts.drawDayChart( stats.byDay, 'chart_day' );
            charts.drawDayOfMonthChart( stats.byDayOfMonth, 'chart_day_of_month' );
            charts.drawMonthChart( stats.byMonth, 'chart_month' );
            charts.drawYearChart( stats.byYear, 'chart_year' );
            charts.drawTransitionChart( stats.byTransition, 'chart_transition', 'transition_definition' );
            charts.drawDygraphChart( stats.byBusiestDay, 'chart_time' );
            utils.logInfo("Drawing UI ended");
        },
        onError: trends.onError,
        onStatusUpdate: function(message) {
            $('#waiting_progress').html( `${message}<span id="syncing_spinner" class="spinner-image" />` );
        }
    });
});


trends.onError = function(message) {
    $('#header').after(`<div id="error_message">${message}</div>`);
    $('#waiting_container').hide();
};


