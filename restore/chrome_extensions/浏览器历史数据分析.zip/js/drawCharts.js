// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals ui, trends, Dygraph, echarts */

let charts = {};

charts.drawDygraphChart = function(dailyStats, div) {
    let data = [];
    for (let dateString in dailyStats) {
        let aDate = new Date(dateString);
        data.push([aDate, dailyStats[dateString]]);
    }
    if ( !data.length ) {
        return;
    }
    // resort data array by ascending dates
    data.sort(function (a,b) { return a[0].valueOf() - b[0].valueOf(); });

    let chartTitle = trends.prefs.rollingAverage() ? "visits_per_day_rolling_avg" : "visits_per_day";

    let gOpts = {
        pointClickCallback: function (e, point) { 
            trends.filters.setDate(point.xval);
            ui.reload(); // js/buildInterface.js
        },
        fillGraph: true,
        fillAlpha: 0.5,
        colors: ['#4684EE'],
        showRangeSelector: true,
        height: 250,
        width: 800,
        title: chrome.i18n.getMessage( chartTitle ),
        titleHeight: 22,
        labels: [ 
            'Date',     // no i18n needed, this text is never displayed
            chrome.i18n.getMessage('number_of_visits')
        ],
        axisLineColor: charts.textColor(),
        axes: {
            x: {
                axisLabelFormatter: function(d, gran) {
                    if (gran < Dygraph.Granularity.MONTHLY) {
                        return trends.prefs.getChartDateString(d, "daily");
                    }
                    else if (gran < Dygraph.Granularity.ANNUAL) {
                        return trends.prefs.getChartDateString(d, "monthly");
                    }
                    else {
                        return trends.prefs.getChartDateString(d, "yearly");
                    }
                },
                valueFormatter: function(ms) {
                    return trends.prefs.getTrendsDateDisplay(ms);
                }
            },
            y: {
                axisLabelFormatter: function (number, gran) {   // eslint-disable-line no-unused-vars
                    return trends.prefs.getNumberDisplay(number);
                },
                valueFormatter: function(number) {
                    return trends.prefs.getNumberDisplay(number);
                }
            }
        }
    };

    if (trends.prefs.rollingAverage()) {
        gOpts.showRoller = true;
        gOpts.rollPeriod = trends.prefs.rollingAveragePeriod();
    }

    let g = new Dygraph(document.getElementById(div), data, gOpts); // eslint-disable-line no-unused-vars
};

charts.drawHourChart = function(hourStats, id) {
    let sourceData = [];
    for (let i = 0; i < hourStats.length; i++) {
        sourceData.push( [ i.toString(), hourStats[i] ] );
    }

    charts.createBarChart(
        id,
        sourceData,
        chrome.i18n.getMessage('time_of_day'),
        // xFormatter
        function(value) {
            return trends.prefs.getHourDisplay(value);
        },
        // yFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setHour(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );
};

charts.drawDayChart = function(dayStats, id) {
    let sourceData = [];
    for (let i = 0; i < dayStats.length; i++) {
        sourceData.push( [ i.toString(), dayStats[i] ] );
    }
    
    charts.createBarChart(
        id,
        sourceData,
        chrome.i18n.getMessage('day_of_week'),
        // xFormatter
        function(value) {
            return trends.prefs.getWeekdayDisplay(value);
        },
        // yFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setWeekday(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );
};


charts.drawDayOfMonthChart = function(dayOfMonthStats, id) {
    let sourceData = [];
    for (let i = 1; i < dayOfMonthStats.length; i++) {
        sourceData.push( [ i.toString(), dayOfMonthStats[i] ] );
    }
    
    charts.createBarChart(
        id,
        sourceData,
        chrome.i18n.getMessage('day_of_month'),
        // xFormatter
        function(value) {
            return value;
        },
        // yFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setMonthday(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );
};

charts.drawMonthChart = function(monthStats, id) {
    let sourceData = [];
    for (let i = 0; i < monthStats.length; i++) {
        sourceData.push( [ i.toString(), monthStats[i] ] );
    }
    
    charts.createBarChart(
        id,
        sourceData,
        chrome.i18n.getMessage('month'),
        // xFormatter
        function(value) {
            return trends.prefs.getMonthDisplay(value);
        },
        // yFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setMonth(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );
};


charts.drawYearChart = function(yearStats, id) {
    let sourceData = [];
    for (let year in yearStats) {
        sourceData.push( [ year, yearStats[year] ] );
    }
    
    charts.createBarChart(
        id,
        sourceData,
        chrome.i18n.getMessage('year'),
        // xFormatter
        function(value) {
            return value;
        },
        // yFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setYear(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );
};


charts.drawTransitionChart = function(transitionStats, id, definition_id) {
    let sourceData = [];
    for (let key in transitionStats) {
        sourceData.push( [ key, transitionStats[key] ] );
    }
    
    charts.createPieChart(
        id,
        sourceData,
        chrome.i18n.getMessage('transition_type'),
        // numFormatter
        function(value) {
            return trends.prefs.getNumberDisplay(value);
        },
        // onClick
        function(params) {
            trends.filters.setTransition(params.value[0]);
            ui.reload(); // js/buildInterface.js
        }
    );

    // Add a link to the definition of transition types
    let definition_div = document.getElementById(definition_id);
    let anchor = document.createElement('a');
    anchor.setAttribute('href', 'https://developer.chrome.com/docs/extensions/reference/history/#transition-types');
    anchor.appendChild(document.createTextNode(chrome.i18n.getMessage('define_transitions')));
    definition_div.appendChild(anchor);
};


charts.textColor = function() {
    if ( charts._textColor == undefined ) {
        charts._textColor = charts.getComputedStyle('--major-text-color') || 'black';   // Provide default for legacy versions of Chrome.
    }
    return charts._textColor;
};


charts.bgColor = function() {
    if ( charts._bgColor == undefined ) {
        charts._bgColor = charts.getComputedStyle('--chart-background-color') || 'white';   // Provide default for legacy versions of Chrome.
    }
    return charts._bgColor;
};


charts.getComputedStyle = function( name ) {
    return getComputedStyle(document.body).getPropertyValue( name ).trim();
};


charts.createBarChart = function( id, sourceData, title, xFormatter, yFormatter, onClick ) {
    let echart = echarts.init(document.getElementById(id), null, {renderer: 'svg'});
    echart.setOption({
        dataset: { source: sourceData },
        title: {
            text: title,
            textStyle: {
                fontSize: 15,
                color: charts.textColor()
            },
            left: 90,
            top: 10
        },
        legend: {
            selectedMode: false,
            top: 10,
            textStyle: {
                color: charts.textColor()
            }
        },
        xAxis: {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            axisLabel: {
                formatter: xFormatter
            },
            axisLine: {
                lineStyle: {
                    color: charts.textColor()
                }
            }
        },
        yAxis: {
            axisLabel: {
                formatter: yFormatter
            },
            axisLine: {
                lineStyle: {
                    color: charts.textColor()
                }
            }
        },
        series: [
            {
                type: 'bar',
                name: chrome.i18n.getMessage('num_visits'),
                itemStyle: {
                    color: '#3366CC'
                },
                emphasis: {
                    focus: 'none',
                    itemStyle: {
                        color: '#2851A3'
                    }
                },
                label: {
                    color: charts.textColor()
                }
            }
        ],
        tooltip: {
            position: 'top',
            textStyle: { color: charts.textColor() },
            backgroundColor: charts.bgColor(),
            formatter: function(params) {
                return '<b>' + xFormatter(params.data[0]) + '</b><br />' +
                    params.seriesName + ': <b>' + yFormatter(params.data[1]) + '</b>'
                ;
            }
        }
    });
    echart.on('click', onClick);
    return echart;
};


charts.createPieChart = function( id, sourceData, title, numFormatter, onClick ) {
    let echart = echarts.init(document.getElementById(id), null, {renderer: 'svg'});
    echart.setOption({
        dataset: { source: sourceData },
        title: {
            text: title,
            textStyle: {
                fontSize: 15,
                color: charts.textColor()
            },
            left: 90,
            top: 10
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 20,
            top: 'center',
            textStyle: {
                color: charts.textColor()
            }
        },
        series: [
            {
                type: 'pie',
                name: chrome.i18n.getMessage('num_visits'),
                label: {
                    color: charts.textColor()
                }
            }
        ],
        tooltip: {
            position: 'top',
            textStyle: { color: charts.textColor() },
            backgroundColor: charts.bgColor(),
            formatter: function(params) {
                return params.data[0] + '<br />' +
                    '<b>' + numFormatter(params.data[1]) + ' (' + numFormatter(params.percent) + '%)</b>'
                ;
            }
        }
    });
    echart.on('click', onClick);
    return echart;
};
