// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals Preferences, importer, Mustache, utils, HistoryWorker */

const options = {
    prefs: null,
    worker: null
};

$(document).ready(async function(){
    options.prefs = await Preferences.fetch();
    options.worker = new HistoryWorker(options.prefs);

    options.setup();
});


options.setup = function() {
    // Chart Options: "Visits per Day" rolling average checkbox
    $('#enable_rolling_average')
        .prop('checked', options.prefs.rollingAverage())
        .on('change', options.enableRollingAverageHandler)
    ;

    // Chart Options: "Visits per Day" rolling average period
    $('#rolling_average_period')
        .val( options.prefs.rollingAveragePeriod() )
        .prop( 'disabled', !options.prefs.rollingAverage() )
        .on( 'keyup', function(e) {
            options.prefs.setRollingAveragePeriod( e.target.value );
            options.prefs.persist();
        } )
    ;

    // Start Page
    $('#start_page').val( options.prefs.startPage() );
    $('#start_page').on( 'change', function(e) {
        options.prefs.setStartPage( e.target.value );        
        options.prefs.persist();
    });

    // Time Display
    $('#time_display').val( options.prefs.getHourFormat() );
    $('#time_display').on( 'change', function(e) {
        options.prefs.setHourFormat( e.target.value );
        options.prefs.persist();
    });

    // Ignore Visits Duration
    $('#ignore_visits_duration')
        .val( options.prefs.ignoreVisitsDurationInSeconds() )
        .on( 'keyup', function(e) {
            options.prefs.setIgnoreVisitsDurationInSeconds( e.target.value );
            options.prefs.persist();
        } )
    ;

    // Transfer History: import file
    $('#import_file').on( 'change', function(e) {
        importer.importHandler(e, options.prefs);
    });

    // Transfer History: export history
    $('#export_history').on('click', function() {
        $('#export_history').after(
            Mustache.render( $('#template-spinner').html(), { id: 'export_spinner' } )
        );
        options.worker.run('exportHistory', {
            syncHistory: true,
            workerArguments: {},
            onComplete: function() {
                $('#export_spinner').remove();
            },
            onError: function(message) {
                $('#export_spinner').remove();
                $('#export_history').after(
                    Mustache.render( $('#template-error').html(), { id: 'export_error_text', error: message } )
                );
            }
        });
    });
    $( "#export_details" ).attr('href', chrome.runtime.getURL("export_details.html"));

    // Auto Backup: Enable checkbox
    $('#enable_autobackup')
        .prop('checked', options.prefs.autoBackup())
        .on( 'change', options.toggleAutoBackupHandler )
    ;

    // Auto Backup: Backup Type
    $('#autobackup_type')
        .val( options.prefs.autoBackupType() )
        .prop('disabled', !options.prefs.autoBackup() )
        .on('change', options.autoBackupTypeChanged )
    ;
    $('#autobackup_type_desc').text( options.getBackupTypeDesc( options.prefs.autoBackupType() ) );

    // Auto Backup: Backup interval
    $('#autobackup_interval')
        .val( options.prefs.autoBackupInterval() )
        .prop('disabled', !options.prefs.autoBackup() )
        .on('keyup', function(e) {
            options.prefs.setAutoBackupInterval( e.target.value );
            options.prefs.persist();
        } )
    ;

    // Auto Backup: Compression checkbox
    $('#autobackup_compression')
        .prop('checked', options.prefs.autoBackupCompression())
        .prop( 'disabled', !options.prefs.autoBackup() )
        .on( 'change', function(e) {
            options.prefs.setAutoBackupCompression( e.target.checked );
            options.prefs.persist();
        })
    ;

    options.displayLastBackedUp( options.prefs.autoBackup(), options.prefs.lastAutoBackupDate() );

    // Must initialize the database before checking the storage quota, otherwise an error will be
    // thrown when the Options page is the first page opened after install.
    options.worker.run('storageStats', {
        workerArguments: {},
        onComplete: function(stats) {
            $('#db_size').html( stats.databaseSize );
            $('#storage_quota').html( stats.storageQuota );
            $('#storage_used').html( options.prefs.getPercentDisplay( stats.percentUsed ) );
        },
        onError: function(message) {
            console.error(message);
        }
    });
};


options.enableRollingAverageHandler = function(e) {
    let checked = e.target.checked;
    options.prefs.setRollingAverage(checked);
    options.prefs.setRollingAveragePeriod( $('#rolling_average_period').val() );
    options.prefs.persist(function() {
        $('#rolling_average_period').prop('disabled', !checked);
    });
};

options.toggleAutoBackupHandler = function(e) {
    let checked = e.target.checked;
    options.prefs.setAutoBackup(checked);
    options.prefs.setAutoBackupType( $('#autobackup_type').val() );
    options.prefs.setAutoBackupInterval( $('#autobackup_interval').val() );
    options.prefs.setAutoBackupCompression( $('#autobackup_compression').prop('checked') );
    options.prefs.persist(function() {
        $('#autobackup_type').prop('disabled', !checked);
        $('#autobackup_interval').prop('disabled', !checked);
        $('#autobackup_compression').prop('disabled', !checked);

        options.displayLastBackedUp( options.prefs.autoBackup(), options.prefs.lastAutoBackupDate() );
    });
};

options.autoBackupTypeChanged = function( e ) {
    let oldValue = options.prefs.autoBackupType();
    let newValue = e.target.value;

    options.prefs.setAutoBackupType( newValue );
    options.prefs.persist(function() {
        $('#autobackup_type_desc').text( options.getBackupTypeDesc( newValue ) );

        if ( oldValue != newValue ) {
            options.clearLastAutoBackupDate();
        }
    });
};

options.clearLastAutoBackupDate = function() {
    options.prefs.setLastAutoBackupDate( undefined );
    options.prefs.persist(function() {
        options.displayLastBackedUp( options.prefs.autoBackup(), options.prefs.lastAutoBackupDate() );
    });
};

options.displayLastBackedUp = function( autoBackupEnabled, lastBackupDate ) {
    if ( autoBackupEnabled ) {
        if ( lastBackupDate ) {
            $('#last_backup_date').html(
                Mustache.render(
                    $('#template-backup-date').html(),
                    {
                        backupText: utils.lastBackedUpText( lastBackupDate ),
                        backupDate: utils.dateToString( lastBackupDate )
                    }
                )
            );
        }
        else {
            $('#last_backup_date').html( Mustache.render( $('#template-na').html() ) );
        }
        $('#backup_now').html( Mustache.render( $('#template-backup-now').html() ) );
        $('#backup_now_link').on( 'click', options.backupNowHandler );
    }
    else {
        $('#last_backup_date').html( Mustache.render( $('#template-na').html() ) );
        $('#backup_now').empty();
    }

    return;
};


options.getBackupTypeDesc = function(value) {
    return value == "full"
        ? "(Exports entire history each time)"
        : "(First backup has everything; subsequent backups have history since last backup)"
    ;
};


options.backupNowHandler = function( e ) {
    e.preventDefault();

    // Add spinner
    $('#backup_now_link').replaceWith(
        Mustache.render( $('#template-spinner').html(), { id: 'backup_now_spinner' } )
    );

    options.worker.run('autoBackupNow', {
        syncHistory: true,
        workerArguments: {},
        onComplete: function({ lastAutoBackupDate }) {
            utils.logInfo(`Setting last autoBackup date: ${lastAutoBackupDate}`);
            options.prefs.setLastAutoBackupDate( lastAutoBackupDate );
            options.prefs.persist(function() {
                options.displayLastBackedUp(options.prefs.autoBackup(), options.prefs.lastAutoBackupDate() );
                $('#backup_now_spinner').remove();
            });
        },
        onError: function(message) {
            $('#backup_now_spinner').remove();
            $('#backup_now').after(
                Mustache.render( $('#template-error').html(), { id: 'backup_now_error_text', error: message } )
            );
        }
    });
};


