// Copyright 2013-2024 Randy Lauen. All Rights Reserved.

"use strict";

/* globals utils */

importScripts(
    'utils.js',
    'public_suffix.js'
);
importScripts( utils.sqliteFile() );

let iworker = {
    db: null
};

self.onmessage = async function(ev) {
    let file = ev.data.file;

    let sqlite3 = await self.sqlite3InitModule();
    try {
        utils.logInfo("import: opening db");
        iworker.db = new sqlite3.oo1.DB({
            filename: utils.databaseName(),
            vfs: 'opfs'
        });
    }
    catch (e) {
        console.error(e);
        self.postMessage({ type: 'error', value: e });
    }

    let reader = new FileReader();

    let chunkSize = 1 * 1024 * 1024;  // 1 MB per chunk
    let start = 0;
    let stop = chunkSize;
    let numChunks = Math.ceil(file.size / chunkSize);
    let chunkIndex = 0;

    let importState = { 
        lastIncompleteLine: null,
        numParsed: 0,
        numErrors: 0,
        urlsInserted: 0,
        visitsInserted: 0,
        visitsIgnored: 0,
        fileType: null
    };

    let blob;

    let onImportDone = function() {
        try {
            iworker.db.exec('commit');
            iworker.db.close();
        }
        catch (e) {
            iworker.db.close();
            console.error(e);
            self.postMessage({ type: 'error', value: e });
            throw e;
        }
        self.postMessage({ type: 'complete', value: importState });
    };

    reader.onload = function(e) {
        ++chunkIndex;    

        let onProcessedCallback = onImportDone;
        if (stop < file.size) {
            onProcessedCallback = function() {
                let percent = Math.round( (chunkIndex / numChunks) * 100 );
                self.postMessage({ type: 'update', value: percent });
                utils.logInfo( "import: " + percent.toString() + "%" );

                start = stop;
                stop = stop + chunkSize;

                blob = file.slice(start, stop);
                reader.readAsText(blob, "UTF-8");
            };
        }

        let results = iworker.parseChunk(e.target.result, importState);
        if (results.urlCount) {
            iworker.saveChunk(results, importState, onProcessedCallback);
        }
        else {
            onProcessedCallback(importState);
        }
    };

    iworker.db.exec('begin');
    blob = file.slice(start, stop);
    reader.readAsText(blob, "UTF-8");
};


iworker.splitChunkRegex = function() {
    return new RegExp('^.*(?:[\r\n]+|$)', 'gm');    // eslint-disable-line no-control-regex
};


iworker.parseChunk = function(text, importState) {
    let lines = text.match( iworker.splitChunkRegex() );
    let lineCount = lines.length;

    if (lines[lineCount - 1] == "") {
        --lineCount;    // ignore last line of file, which is empty string
    }

    let results = {
        urls: {},   // maps urls to their visits and title
        urlCount: 0
    };

    for (let i = 0; i < lineCount; i++) {
        let rawLine = lines[i];
        let isFirstLine = (i == 0);
        let isLastLine = (i == lineCount - 1);

        // If a CR/LF line is split between the two, we can safely ignore the line containing solely a LF
        if (!importState.lastIncompleteLine && rawLine.length == 1 && rawLine == "\n") {
            continue;
        }

        if (isFirstLine && importState.lastIncompleteLine) {
            // prepend the last incomplete line before parsing
            rawLine = importState.lastIncompleteLine + rawLine;
            importState.lastIncompleteLine = null;
        }
        
        let parsedLine = iworker.parseLine(rawLine);

        if (!importState.fileType) {
            importState.fileType = parsedLine.fileType;
        }

        if (parsedLine.error) {
            if (isLastLine && parsedLine.error == "MISSING_LINEBREAK") {
                importState.lastIncompleteLine = rawLine;
            }
            else {
                utils.logError("import: " + parsedLine.errorMsg);
                ++importState.numErrors;
            }
        }
        else {
            if (importState.lastIncompleteLine) {
                utils.logWarning("import: unexpected lastIncompleteLine: " + importState.lastIncompleteLine + ", numParsed = " + importState.numParsed);
            }

            ++importState.numParsed;

            if (!results.urls[ parsedLine.url ]) {
                results.urls[ parsedLine.url ] = {
                    "visits": [],
                    "title": null
                };
                ++results.urlCount;
            }

            let result = results.urls[ parsedLine.url ];
            result.visits.push({ visitTime: parsedLine.visitTime, transition: parsedLine.transition });

            if (result.title == null && parsedLine.title != null) {
                result.title = parsedLine.title;
            }
        }
    }

    return results;
};


iworker.saveChunk = function(results, importState, onProcessedCallback) {
    let urlIdsFound = 0;
    let seenHostnames = {};     // maps hostnames to root domains

    for (let url in results.urls) {
        let host = utils.extractHost(url);
        let root_domain;
        if (seenHostnames[ host ]) {
            root_domain = seenHostnames[ host ];
        }
        else {
            root_domain = utils.getDomainPortion(host);
            seenHostnames[ host ] = root_domain;
        }

        let title = results.urls[url].title;
        if (title == "") {
            title = null;
        }

        try {
            let insertId = iworker.db.selectValue(
                "INSERT OR IGNORE INTO urls (url, host, root_domain, title) VALUES (?, ?, ?, ?) RETURNING urlid",
                [url, (host === undefined ? null : host), (root_domain === undefined ? null : root_domain), title]
            );
            if (insertId) {
                ++importState.urlsInserted;
                iworker.db.exec({
                    sql: "INSERT OR IGNORE INTO search_urls (rowid, url, title) VALUES (?, ?, ?)", 
                    bind: [insertId, url, title]
                });
            }
            let urlId = iworker.db.selectValue( "SELECT urlid FROM urls WHERE url=?", [url] );
            if ( urlId ) {
                ++urlIdsFound;
                results.urls[url].urlid = urlId;
                if (urlIdsFound == results.urlCount) {
                    iworker.insertVisits(results, importState, onProcessedCallback);
                }
            }
        }
        catch(e) {
            iworker.db.close();
            console.error(e);
            self.postMessage({ type: 'error', value: e });
            throw e;
        }
    }
};


iworker.parseLine = function(lineInput) {
    let result = {
        url: null,
        visitTime: null,
        transition: null,
        error: null,
        errorMsg: null,
        title: null,
        fileType: null
    };

    if (!/[\r\n]+$/.test(lineInput)) {
        result.error = "MISSING_LINEBREAK";
        result.errorMsg = "no linebreaks for line: '" + lineInput + "'";
        return result;
    }

    let line = lineInput.replace(/[\r\n]+$/, '');
    let columns = line.split("\t");

    if (columns.length != 3 && columns.length != 4 && columns.length != 8) {
        result.error = "WRONG_COLUMN_COUNT";
        result.errorMsg = "wrong number of columns (" + columns.length + ") for line: '" + line + "'";
        return result;
    }

    let url;
    let visitTime;
    let transition;
    let title;

    if (columns.length == 3 || columns.length == 4) {
        // 3 cols == "Archived History" format before page title was supported.
        // 4 cols == "Export History" format which includes page title.
        url = columns[0];
        visitTime = columns[1];
        transition = columns[2];
        title = columns.length == 4 ? columns[3] : null;
    }
    else if (columns.length == 8) {
        // 8 cols == "Export These Results" format so users can do their own analysis.
        url = columns[0];
        visitTime = columns[3];
        transition = columns[6];
        title = columns[7];
    }

    let errors = [];

    if (!iworker.isValidUrl(url)) {
        errors.push("url");
    }

    if (!iworker.isValidVisitTime(visitTime)) {
        errors.push("visitTime");
    }

    if (!iworker.isValidTransition(transition)) {
        errors.push("transition");
    }

    if (!iworker.isValidTitle(title)) {
        errors.push("title");
    }

    if (errors.length) {
        result.error = "INVALID_FIELD";
        result.errorMsg = "Invalid " + errors.join(", ") + " for line '" + line + "'";
        return result;
    }

    let fileType = columns.length + 'col';

    // For cols=8 format, time is already in unix time and transition is already text.
    if (columns.length != 8) {
        // If visitTime begins with a "U", it's already in unix epoch time.
        if ( visitTime.match(/^U/) ) {
            fileType = fileType + '_unix';
            visitTime = parseFloat( visitTime.replace("U","") );
        }
        // Otherwise, it's in windows epoch time.
        else {
            fileType = fileType + '_win';
            visitTime = utils.convertToUnixEpoch(visitTime);
        }
        transition = utils.convertTransitionToText(transition);
    }
    else {
        visitTime = parseFloat(visitTime);
    }

    result.url = url;
    result.visitTime = visitTime;
    result.transition = transition;
    result.title = title;
    result.fileType = fileType;

    return result;
};


iworker.isValidUrl = function(url) {
    if (typeof(url) == "string") {
        return url.length > 0;
    }
    return;
};


iworker.isValidVisitTime = function(time) {
    if (typeof(time) == "string") {
        return /^U?\d+\.?\d*$/.test(time);
    }
    return;
};


iworker.isValidTransition = function(transition) {
    if (typeof(transition) == "string") {
        return /^(?:-?\d+|[a-z_]+)$/i.test(transition);
    }
    return;
};


// Accept anything for title.
iworker.isValidTitle = function(title) {   // eslint-disable-line no-unused-vars
    return true;
};


iworker.insertVisits = function(results, importState, onProcessedCallback) {
    utils.logInfo("import: insertVisits called for " + results.urlCount + " url(s)");

    let insertSql = 
        "INSERT OR IGNORE INTO visits (" +
            "urlid, visit_time, visit_date, year, month, month_day, week_day, hour, transition_type" +
        ") VALUES (" +
            "    ?,          ?,          ?,    ?,     ?,         ?,        ?,    ?,               ?" +
        ")"
    ;

    let urlCount = 0;

    for (let url in results.urls) {
        ++urlCount;
        let urlInfo = results.urls[url];
        let isLastUrl = (urlCount == results.urlCount);

        for (let i = 0; i < urlInfo.visits.length; i++) {
            let visitInfo = urlInfo.visits[i];
            let visitDate = new Date(visitInfo.visitTime);
            let dateString = utils.dateToString(visitDate);
            let isLastVisit = (i == urlInfo.visits.length - 1);

            let insertCount;
            try {
                iworker.db.exec({
                    sql: insertSql,
                    bind:
                    [
                        urlInfo.urlid, visitInfo.visitTime.toString(), dateString, visitDate.getFullYear(), visitDate.getMonth(),
                        visitDate.getDate(), visitDate.getDay(), visitDate.getHours(), visitInfo.transition
                    ]
                });
                insertCount = iworker.db.changes();
            }
            catch(e) {
                iworker.db.close();
                console.error(e);
                self.postMessage({ type: 'error', value: e });
                throw e;
            }

            if (insertCount) {
                ++importState.visitsInserted;
            }
            else {
                ++importState.visitsIgnored;
            }

            if (isLastUrl && isLastVisit) {
                onProcessedCallback(importState);
            }
        }
    }
};

