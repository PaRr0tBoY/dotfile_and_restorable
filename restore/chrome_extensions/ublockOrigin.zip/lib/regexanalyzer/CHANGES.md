# Regex Analyzer

Imported from: <https://github.com/foo123/RegexAnalyzer>
Author: Nikos M.

## Changes to the imported library

#### Date

2023-01-01

Imported version 1.2.0 of the library from
https://github.com/foo123/RegexAnalyzer/blob/1.2.0/src/js/Regex.js

Minimally modified the code to make it ECMAscript `export`-/`import`-friendly.
