"use strict";
var browser = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve2, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve: resolve2,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve2();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve2();
                  } else {
                    target[name](...args, makeCallback({
                      resolve: resolve2,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty2 = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty2(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty2(wrappers, prop) || hasOwnProperty2(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty2(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve2) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve2(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve: resolve2
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve2();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve2(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve2, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve: resolve2,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/browser.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var browser2 = import_webextension_polyfill.default;

  // src/config.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var getLogseqCopliotConfig = async () => {
    const {
      version = "",
      logseqHost = "http://localhost:12315",
      logseqHostName = "localhost",
      logseqPort = 12315,
      logseqAuthToken = "",
      enableClipNoteFloatButton = false,
      clipNoteLocation = "journal",
      clipNoteCustomPage = "",
      clipNoteTemplate = `#[[Clip]] [{{title}}]({{url}})
{{content}}`
    } = await import_webextension_polyfill2.default.storage.local.get();
    return {
      version,
      logseqHost,
      logseqHostName,
      logseqPort,
      logseqAuthToken,
      enableClipNoteFloatButton,
      clipNoteLocation,
      clipNoteCustomPage,
      clipNoteTemplate
    };
  };
  var saveLogseqCopliotConfig = async (updates) => {
    console.log("saveLogseqCopliotConfig", updates);
    await import_webextension_polyfill2.default.storage.local.set(updates);
  };

  // node_modules/@babel/runtime/helpers/esm/typeof.js
  function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof(o);
  }

  // node_modules/date-fns/esm/_lib/toInteger/index.js
  function toInteger(dirtyNumber) {
    if (dirtyNumber === null || dirtyNumber === true || dirtyNumber === false) {
      return NaN;
    }
    var number = Number(dirtyNumber);
    if (isNaN(number)) {
      return number;
    }
    return number < 0 ? Math.ceil(number) : Math.floor(number);
  }

  // node_modules/date-fns/esm/_lib/requiredArgs/index.js
  function requiredArgs(required, args) {
    if (args.length < required) {
      throw new TypeError(required + " argument" + (required > 1 ? "s" : "") + " required, but only " + args.length + " present");
    }
  }

  // node_modules/date-fns/esm/toDate/index.js
  function toDate(argument) {
    requiredArgs(1, arguments);
    var argStr = Object.prototype.toString.call(argument);
    if (argument instanceof Date || _typeof(argument) === "object" && argStr === "[object Date]") {
      return new Date(argument.getTime());
    } else if (typeof argument === "number" || argStr === "[object Number]") {
      return new Date(argument);
    } else {
      if ((typeof argument === "string" || argStr === "[object String]") && typeof console !== "undefined") {
        console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments");
        console.warn(new Error().stack);
      }
      return /* @__PURE__ */ new Date(NaN);
    }
  }

  // node_modules/date-fns/esm/addMilliseconds/index.js
  function addMilliseconds(dirtyDate, dirtyAmount) {
    requiredArgs(2, arguments);
    var timestamp = toDate(dirtyDate).getTime();
    var amount = toInteger(dirtyAmount);
    return new Date(timestamp + amount);
  }

  // node_modules/date-fns/esm/_lib/defaultOptions/index.js
  var defaultOptions = {};
  function getDefaultOptions() {
    return defaultOptions;
  }

  // node_modules/date-fns/esm/_lib/getTimezoneOffsetInMilliseconds/index.js
  function getTimezoneOffsetInMilliseconds(date2) {
    var utcDate = new Date(Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate(), date2.getHours(), date2.getMinutes(), date2.getSeconds(), date2.getMilliseconds()));
    utcDate.setUTCFullYear(date2.getFullYear());
    return date2.getTime() - utcDate.getTime();
  }

  // node_modules/date-fns/esm/isDate/index.js
  function isDate(value) {
    requiredArgs(1, arguments);
    return value instanceof Date || _typeof(value) === "object" && Object.prototype.toString.call(value) === "[object Date]";
  }

  // node_modules/date-fns/esm/isValid/index.js
  function isValid(dirtyDate) {
    requiredArgs(1, arguments);
    if (!isDate(dirtyDate) && typeof dirtyDate !== "number") {
      return false;
    }
    var date2 = toDate(dirtyDate);
    return !isNaN(Number(date2));
  }

  // node_modules/date-fns/esm/subMilliseconds/index.js
  function subMilliseconds(dirtyDate, dirtyAmount) {
    requiredArgs(2, arguments);
    var amount = toInteger(dirtyAmount);
    return addMilliseconds(dirtyDate, -amount);
  }

  // node_modules/date-fns/esm/_lib/getUTCDayOfYear/index.js
  var MILLISECONDS_IN_DAY = 864e5;
  function getUTCDayOfYear(dirtyDate) {
    requiredArgs(1, arguments);
    var date2 = toDate(dirtyDate);
    var timestamp = date2.getTime();
    date2.setUTCMonth(0, 1);
    date2.setUTCHours(0, 0, 0, 0);
    var startOfYearTimestamp = date2.getTime();
    var difference = timestamp - startOfYearTimestamp;
    return Math.floor(difference / MILLISECONDS_IN_DAY) + 1;
  }

  // node_modules/date-fns/esm/_lib/startOfUTCISOWeek/index.js
  function startOfUTCISOWeek(dirtyDate) {
    requiredArgs(1, arguments);
    var weekStartsOn = 1;
    var date2 = toDate(dirtyDate);
    var day = date2.getUTCDay();
    var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
    date2.setUTCDate(date2.getUTCDate() - diff);
    date2.setUTCHours(0, 0, 0, 0);
    return date2;
  }

  // node_modules/date-fns/esm/_lib/getUTCISOWeekYear/index.js
  function getUTCISOWeekYear(dirtyDate) {
    requiredArgs(1, arguments);
    var date2 = toDate(dirtyDate);
    var year = date2.getUTCFullYear();
    var fourthOfJanuaryOfNextYear = /* @__PURE__ */ new Date(0);
    fourthOfJanuaryOfNextYear.setUTCFullYear(year + 1, 0, 4);
    fourthOfJanuaryOfNextYear.setUTCHours(0, 0, 0, 0);
    var startOfNextYear = startOfUTCISOWeek(fourthOfJanuaryOfNextYear);
    var fourthOfJanuaryOfThisYear = /* @__PURE__ */ new Date(0);
    fourthOfJanuaryOfThisYear.setUTCFullYear(year, 0, 4);
    fourthOfJanuaryOfThisYear.setUTCHours(0, 0, 0, 0);
    var startOfThisYear = startOfUTCISOWeek(fourthOfJanuaryOfThisYear);
    if (date2.getTime() >= startOfNextYear.getTime()) {
      return year + 1;
    } else if (date2.getTime() >= startOfThisYear.getTime()) {
      return year;
    } else {
      return year - 1;
    }
  }

  // node_modules/date-fns/esm/_lib/startOfUTCISOWeekYear/index.js
  function startOfUTCISOWeekYear(dirtyDate) {
    requiredArgs(1, arguments);
    var year = getUTCISOWeekYear(dirtyDate);
    var fourthOfJanuary = /* @__PURE__ */ new Date(0);
    fourthOfJanuary.setUTCFullYear(year, 0, 4);
    fourthOfJanuary.setUTCHours(0, 0, 0, 0);
    var date2 = startOfUTCISOWeek(fourthOfJanuary);
    return date2;
  }

  // node_modules/date-fns/esm/_lib/getUTCISOWeek/index.js
  var MILLISECONDS_IN_WEEK = 6048e5;
  function getUTCISOWeek(dirtyDate) {
    requiredArgs(1, arguments);
    var date2 = toDate(dirtyDate);
    var diff = startOfUTCISOWeek(date2).getTime() - startOfUTCISOWeekYear(date2).getTime();
    return Math.round(diff / MILLISECONDS_IN_WEEK) + 1;
  }

  // node_modules/date-fns/esm/_lib/startOfUTCWeek/index.js
  function startOfUTCWeek(dirtyDate, options2) {
    var _ref, _ref2, _ref3, _options$weekStartsOn, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
    requiredArgs(1, arguments);
    var defaultOptions3 = getDefaultOptions();
    var weekStartsOn = toInteger((_ref = (_ref2 = (_ref3 = (_options$weekStartsOn = options2 === null || options2 === void 0 ? void 0 : options2.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options2 === null || options2 === void 0 ? void 0 : (_options$locale = options2.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.weekStartsOn) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions3.weekStartsOn) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions3.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.weekStartsOn) !== null && _ref !== void 0 ? _ref : 0);
    if (!(weekStartsOn >= 0 && weekStartsOn <= 6)) {
      throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
    }
    var date2 = toDate(dirtyDate);
    var day = date2.getUTCDay();
    var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
    date2.setUTCDate(date2.getUTCDate() - diff);
    date2.setUTCHours(0, 0, 0, 0);
    return date2;
  }

  // node_modules/date-fns/esm/_lib/getUTCWeekYear/index.js
  function getUTCWeekYear(dirtyDate, options2) {
    var _ref, _ref2, _ref3, _options$firstWeekCon, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
    requiredArgs(1, arguments);
    var date2 = toDate(dirtyDate);
    var year = date2.getUTCFullYear();
    var defaultOptions3 = getDefaultOptions();
    var firstWeekContainsDate = toInteger((_ref = (_ref2 = (_ref3 = (_options$firstWeekCon = options2 === null || options2 === void 0 ? void 0 : options2.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options2 === null || options2 === void 0 ? void 0 : (_options$locale = options2.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions3.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions3.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref !== void 0 ? _ref : 1);
    if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
      throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
    }
    var firstWeekOfNextYear = /* @__PURE__ */ new Date(0);
    firstWeekOfNextYear.setUTCFullYear(year + 1, 0, firstWeekContainsDate);
    firstWeekOfNextYear.setUTCHours(0, 0, 0, 0);
    var startOfNextYear = startOfUTCWeek(firstWeekOfNextYear, options2);
    var firstWeekOfThisYear = /* @__PURE__ */ new Date(0);
    firstWeekOfThisYear.setUTCFullYear(year, 0, firstWeekContainsDate);
    firstWeekOfThisYear.setUTCHours(0, 0, 0, 0);
    var startOfThisYear = startOfUTCWeek(firstWeekOfThisYear, options2);
    if (date2.getTime() >= startOfNextYear.getTime()) {
      return year + 1;
    } else if (date2.getTime() >= startOfThisYear.getTime()) {
      return year;
    } else {
      return year - 1;
    }
  }

  // node_modules/date-fns/esm/_lib/startOfUTCWeekYear/index.js
  function startOfUTCWeekYear(dirtyDate, options2) {
    var _ref, _ref2, _ref3, _options$firstWeekCon, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
    requiredArgs(1, arguments);
    var defaultOptions3 = getDefaultOptions();
    var firstWeekContainsDate = toInteger((_ref = (_ref2 = (_ref3 = (_options$firstWeekCon = options2 === null || options2 === void 0 ? void 0 : options2.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options2 === null || options2 === void 0 ? void 0 : (_options$locale = options2.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions3.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions3.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref !== void 0 ? _ref : 1);
    var year = getUTCWeekYear(dirtyDate, options2);
    var firstWeek = /* @__PURE__ */ new Date(0);
    firstWeek.setUTCFullYear(year, 0, firstWeekContainsDate);
    firstWeek.setUTCHours(0, 0, 0, 0);
    var date2 = startOfUTCWeek(firstWeek, options2);
    return date2;
  }

  // node_modules/date-fns/esm/_lib/getUTCWeek/index.js
  var MILLISECONDS_IN_WEEK2 = 6048e5;
  function getUTCWeek(dirtyDate, options2) {
    requiredArgs(1, arguments);
    var date2 = toDate(dirtyDate);
    var diff = startOfUTCWeek(date2, options2).getTime() - startOfUTCWeekYear(date2, options2).getTime();
    return Math.round(diff / MILLISECONDS_IN_WEEK2) + 1;
  }

  // node_modules/date-fns/esm/_lib/addLeadingZeros/index.js
  function addLeadingZeros(number, targetLength) {
    var sign = number < 0 ? "-" : "";
    var output = Math.abs(number).toString();
    while (output.length < targetLength) {
      output = "0" + output;
    }
    return sign + output;
  }

  // node_modules/date-fns/esm/_lib/format/lightFormatters/index.js
  var formatters = {
    // Year
    y: function y(date2, token) {
      var signedYear = date2.getUTCFullYear();
      var year = signedYear > 0 ? signedYear : 1 - signedYear;
      return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
    },
    // Month
    M: function M(date2, token) {
      var month = date2.getUTCMonth();
      return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
    },
    // Day of the month
    d: function d(date2, token) {
      return addLeadingZeros(date2.getUTCDate(), token.length);
    },
    // AM or PM
    a: function a(date2, token) {
      var dayPeriodEnumValue = date2.getUTCHours() / 12 >= 1 ? "pm" : "am";
      switch (token) {
        case "a":
        case "aa":
          return dayPeriodEnumValue.toUpperCase();
        case "aaa":
          return dayPeriodEnumValue;
        case "aaaaa":
          return dayPeriodEnumValue[0];
        case "aaaa":
        default:
          return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
      }
    },
    // Hour [1-12]
    h: function h(date2, token) {
      return addLeadingZeros(date2.getUTCHours() % 12 || 12, token.length);
    },
    // Hour [0-23]
    H: function H(date2, token) {
      return addLeadingZeros(date2.getUTCHours(), token.length);
    },
    // Minute
    m: function m(date2, token) {
      return addLeadingZeros(date2.getUTCMinutes(), token.length);
    },
    // Second
    s: function s(date2, token) {
      return addLeadingZeros(date2.getUTCSeconds(), token.length);
    },
    // Fraction of second
    S: function S(date2, token) {
      var numberOfDigits = token.length;
      var milliseconds = date2.getUTCMilliseconds();
      var fractionalSeconds = Math.floor(milliseconds * Math.pow(10, numberOfDigits - 3));
      return addLeadingZeros(fractionalSeconds, token.length);
    }
  };
  var lightFormatters_default = formatters;

  // node_modules/date-fns/esm/_lib/format/formatters/index.js
  var dayPeriodEnum = {
    am: "am",
    pm: "pm",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  };
  var formatters2 = {
    // Era
    G: function G(date2, token, localize2) {
      var era = date2.getUTCFullYear() > 0 ? 1 : 0;
      switch (token) {
        case "G":
        case "GG":
        case "GGG":
          return localize2.era(era, {
            width: "abbreviated"
          });
        case "GGGGG":
          return localize2.era(era, {
            width: "narrow"
          });
        case "GGGG":
        default:
          return localize2.era(era, {
            width: "wide"
          });
      }
    },
    // Year
    y: function y2(date2, token, localize2) {
      if (token === "yo") {
        var signedYear = date2.getUTCFullYear();
        var year = signedYear > 0 ? signedYear : 1 - signedYear;
        return localize2.ordinalNumber(year, {
          unit: "year"
        });
      }
      return lightFormatters_default.y(date2, token);
    },
    // Local week-numbering year
    Y: function Y(date2, token, localize2, options2) {
      var signedWeekYear = getUTCWeekYear(date2, options2);
      var weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;
      if (token === "YY") {
        var twoDigitYear = weekYear % 100;
        return addLeadingZeros(twoDigitYear, 2);
      }
      if (token === "Yo") {
        return localize2.ordinalNumber(weekYear, {
          unit: "year"
        });
      }
      return addLeadingZeros(weekYear, token.length);
    },
    // ISO week-numbering year
    R: function R(date2, token) {
      var isoWeekYear = getUTCISOWeekYear(date2);
      return addLeadingZeros(isoWeekYear, token.length);
    },
    // Extended year. This is a single number designating the year of this calendar system.
    // The main difference between `y` and `u` localizers are B.C. years:
    // | Year | `y` | `u` |
    // |------|-----|-----|
    // | AC 1 |   1 |   1 |
    // | BC 1 |   1 |   0 |
    // | BC 2 |   2 |  -1 |
    // Also `yy` always returns the last two digits of a year,
    // while `uu` pads single digit years to 2 characters and returns other years unchanged.
    u: function u(date2, token) {
      var year = date2.getUTCFullYear();
      return addLeadingZeros(year, token.length);
    },
    // Quarter
    Q: function Q(date2, token, localize2) {
      var quarter = Math.ceil((date2.getUTCMonth() + 1) / 3);
      switch (token) {
        case "Q":
          return String(quarter);
        case "QQ":
          return addLeadingZeros(quarter, 2);
        case "Qo":
          return localize2.ordinalNumber(quarter, {
            unit: "quarter"
          });
        case "QQQ":
          return localize2.quarter(quarter, {
            width: "abbreviated",
            context: "formatting"
          });
        case "QQQQQ":
          return localize2.quarter(quarter, {
            width: "narrow",
            context: "formatting"
          });
        case "QQQQ":
        default:
          return localize2.quarter(quarter, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // Stand-alone quarter
    q: function q(date2, token, localize2) {
      var quarter = Math.ceil((date2.getUTCMonth() + 1) / 3);
      switch (token) {
        case "q":
          return String(quarter);
        case "qq":
          return addLeadingZeros(quarter, 2);
        case "qo":
          return localize2.ordinalNumber(quarter, {
            unit: "quarter"
          });
        case "qqq":
          return localize2.quarter(quarter, {
            width: "abbreviated",
            context: "standalone"
          });
        case "qqqqq":
          return localize2.quarter(quarter, {
            width: "narrow",
            context: "standalone"
          });
        case "qqqq":
        default:
          return localize2.quarter(quarter, {
            width: "wide",
            context: "standalone"
          });
      }
    },
    // Month
    M: function M2(date2, token, localize2) {
      var month = date2.getUTCMonth();
      switch (token) {
        case "M":
        case "MM":
          return lightFormatters_default.M(date2, token);
        case "Mo":
          return localize2.ordinalNumber(month + 1, {
            unit: "month"
          });
        case "MMM":
          return localize2.month(month, {
            width: "abbreviated",
            context: "formatting"
          });
        case "MMMMM":
          return localize2.month(month, {
            width: "narrow",
            context: "formatting"
          });
        case "MMMM":
        default:
          return localize2.month(month, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // Stand-alone month
    L: function L(date2, token, localize2) {
      var month = date2.getUTCMonth();
      switch (token) {
        case "L":
          return String(month + 1);
        case "LL":
          return addLeadingZeros(month + 1, 2);
        case "Lo":
          return localize2.ordinalNumber(month + 1, {
            unit: "month"
          });
        case "LLL":
          return localize2.month(month, {
            width: "abbreviated",
            context: "standalone"
          });
        case "LLLLL":
          return localize2.month(month, {
            width: "narrow",
            context: "standalone"
          });
        case "LLLL":
        default:
          return localize2.month(month, {
            width: "wide",
            context: "standalone"
          });
      }
    },
    // Local week of year
    w: function w(date2, token, localize2, options2) {
      var week = getUTCWeek(date2, options2);
      if (token === "wo") {
        return localize2.ordinalNumber(week, {
          unit: "week"
        });
      }
      return addLeadingZeros(week, token.length);
    },
    // ISO week of year
    I: function I(date2, token, localize2) {
      var isoWeek = getUTCISOWeek(date2);
      if (token === "Io") {
        return localize2.ordinalNumber(isoWeek, {
          unit: "week"
        });
      }
      return addLeadingZeros(isoWeek, token.length);
    },
    // Day of the month
    d: function d2(date2, token, localize2) {
      if (token === "do") {
        return localize2.ordinalNumber(date2.getUTCDate(), {
          unit: "date"
        });
      }
      return lightFormatters_default.d(date2, token);
    },
    // Day of year
    D: function D(date2, token, localize2) {
      var dayOfYear = getUTCDayOfYear(date2);
      if (token === "Do") {
        return localize2.ordinalNumber(dayOfYear, {
          unit: "dayOfYear"
        });
      }
      return addLeadingZeros(dayOfYear, token.length);
    },
    // Day of week
    E: function E(date2, token, localize2) {
      var dayOfWeek = date2.getUTCDay();
      switch (token) {
        case "E":
        case "EE":
        case "EEE":
          return localize2.day(dayOfWeek, {
            width: "abbreviated",
            context: "formatting"
          });
        case "EEEEE":
          return localize2.day(dayOfWeek, {
            width: "narrow",
            context: "formatting"
          });
        case "EEEEEE":
          return localize2.day(dayOfWeek, {
            width: "short",
            context: "formatting"
          });
        case "EEEE":
        default:
          return localize2.day(dayOfWeek, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // Local day of week
    e: function e(date2, token, localize2, options2) {
      var dayOfWeek = date2.getUTCDay();
      var localDayOfWeek = (dayOfWeek - options2.weekStartsOn + 8) % 7 || 7;
      switch (token) {
        case "e":
          return String(localDayOfWeek);
        case "ee":
          return addLeadingZeros(localDayOfWeek, 2);
        case "eo":
          return localize2.ordinalNumber(localDayOfWeek, {
            unit: "day"
          });
        case "eee":
          return localize2.day(dayOfWeek, {
            width: "abbreviated",
            context: "formatting"
          });
        case "eeeee":
          return localize2.day(dayOfWeek, {
            width: "narrow",
            context: "formatting"
          });
        case "eeeeee":
          return localize2.day(dayOfWeek, {
            width: "short",
            context: "formatting"
          });
        case "eeee":
        default:
          return localize2.day(dayOfWeek, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // Stand-alone local day of week
    c: function c(date2, token, localize2, options2) {
      var dayOfWeek = date2.getUTCDay();
      var localDayOfWeek = (dayOfWeek - options2.weekStartsOn + 8) % 7 || 7;
      switch (token) {
        case "c":
          return String(localDayOfWeek);
        case "cc":
          return addLeadingZeros(localDayOfWeek, token.length);
        case "co":
          return localize2.ordinalNumber(localDayOfWeek, {
            unit: "day"
          });
        case "ccc":
          return localize2.day(dayOfWeek, {
            width: "abbreviated",
            context: "standalone"
          });
        case "ccccc":
          return localize2.day(dayOfWeek, {
            width: "narrow",
            context: "standalone"
          });
        case "cccccc":
          return localize2.day(dayOfWeek, {
            width: "short",
            context: "standalone"
          });
        case "cccc":
        default:
          return localize2.day(dayOfWeek, {
            width: "wide",
            context: "standalone"
          });
      }
    },
    // ISO day of week
    i: function i(date2, token, localize2) {
      var dayOfWeek = date2.getUTCDay();
      var isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
      switch (token) {
        case "i":
          return String(isoDayOfWeek);
        case "ii":
          return addLeadingZeros(isoDayOfWeek, token.length);
        case "io":
          return localize2.ordinalNumber(isoDayOfWeek, {
            unit: "day"
          });
        case "iii":
          return localize2.day(dayOfWeek, {
            width: "abbreviated",
            context: "formatting"
          });
        case "iiiii":
          return localize2.day(dayOfWeek, {
            width: "narrow",
            context: "formatting"
          });
        case "iiiiii":
          return localize2.day(dayOfWeek, {
            width: "short",
            context: "formatting"
          });
        case "iiii":
        default:
          return localize2.day(dayOfWeek, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // AM or PM
    a: function a2(date2, token, localize2) {
      var hours = date2.getUTCHours();
      var dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
      switch (token) {
        case "a":
        case "aa":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting"
          });
        case "aaa":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting"
          }).toLowerCase();
        case "aaaaa":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "narrow",
            context: "formatting"
          });
        case "aaaa":
        default:
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // AM, PM, midnight, noon
    b: function b(date2, token, localize2) {
      var hours = date2.getUTCHours();
      var dayPeriodEnumValue;
      if (hours === 12) {
        dayPeriodEnumValue = dayPeriodEnum.noon;
      } else if (hours === 0) {
        dayPeriodEnumValue = dayPeriodEnum.midnight;
      } else {
        dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
      }
      switch (token) {
        case "b":
        case "bb":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting"
          });
        case "bbb":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting"
          }).toLowerCase();
        case "bbbbb":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "narrow",
            context: "formatting"
          });
        case "bbbb":
        default:
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // in the morning, in the afternoon, in the evening, at night
    B: function B(date2, token, localize2) {
      var hours = date2.getUTCHours();
      var dayPeriodEnumValue;
      if (hours >= 17) {
        dayPeriodEnumValue = dayPeriodEnum.evening;
      } else if (hours >= 12) {
        dayPeriodEnumValue = dayPeriodEnum.afternoon;
      } else if (hours >= 4) {
        dayPeriodEnumValue = dayPeriodEnum.morning;
      } else {
        dayPeriodEnumValue = dayPeriodEnum.night;
      }
      switch (token) {
        case "B":
        case "BB":
        case "BBB":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting"
          });
        case "BBBBB":
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "narrow",
            context: "formatting"
          });
        case "BBBB":
        default:
          return localize2.dayPeriod(dayPeriodEnumValue, {
            width: "wide",
            context: "formatting"
          });
      }
    },
    // Hour [1-12]
    h: function h2(date2, token, localize2) {
      if (token === "ho") {
        var hours = date2.getUTCHours() % 12;
        if (hours === 0)
          hours = 12;
        return localize2.ordinalNumber(hours, {
          unit: "hour"
        });
      }
      return lightFormatters_default.h(date2, token);
    },
    // Hour [0-23]
    H: function H2(date2, token, localize2) {
      if (token === "Ho") {
        return localize2.ordinalNumber(date2.getUTCHours(), {
          unit: "hour"
        });
      }
      return lightFormatters_default.H(date2, token);
    },
    // Hour [0-11]
    K: function K(date2, token, localize2) {
      var hours = date2.getUTCHours() % 12;
      if (token === "Ko") {
        return localize2.ordinalNumber(hours, {
          unit: "hour"
        });
      }
      return addLeadingZeros(hours, token.length);
    },
    // Hour [1-24]
    k: function k(date2, token, localize2) {
      var hours = date2.getUTCHours();
      if (hours === 0)
        hours = 24;
      if (token === "ko") {
        return localize2.ordinalNumber(hours, {
          unit: "hour"
        });
      }
      return addLeadingZeros(hours, token.length);
    },
    // Minute
    m: function m2(date2, token, localize2) {
      if (token === "mo") {
        return localize2.ordinalNumber(date2.getUTCMinutes(), {
          unit: "minute"
        });
      }
      return lightFormatters_default.m(date2, token);
    },
    // Second
    s: function s2(date2, token, localize2) {
      if (token === "so") {
        return localize2.ordinalNumber(date2.getUTCSeconds(), {
          unit: "second"
        });
      }
      return lightFormatters_default.s(date2, token);
    },
    // Fraction of second
    S: function S2(date2, token) {
      return lightFormatters_default.S(date2, token);
    },
    // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
    X: function X(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timezoneOffset = originalDate.getTimezoneOffset();
      if (timezoneOffset === 0) {
        return "Z";
      }
      switch (token) {
        case "X":
          return formatTimezoneWithOptionalMinutes(timezoneOffset);
        case "XXXX":
        case "XX":
          return formatTimezone(timezoneOffset);
        case "XXXXX":
        case "XXX":
        default:
          return formatTimezone(timezoneOffset, ":");
      }
    },
    // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
    x: function x(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timezoneOffset = originalDate.getTimezoneOffset();
      switch (token) {
        case "x":
          return formatTimezoneWithOptionalMinutes(timezoneOffset);
        case "xxxx":
        case "xx":
          return formatTimezone(timezoneOffset);
        case "xxxxx":
        case "xxx":
        default:
          return formatTimezone(timezoneOffset, ":");
      }
    },
    // Timezone (GMT)
    O: function O(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timezoneOffset = originalDate.getTimezoneOffset();
      switch (token) {
        case "O":
        case "OO":
        case "OOO":
          return "GMT" + formatTimezoneShort(timezoneOffset, ":");
        case "OOOO":
        default:
          return "GMT" + formatTimezone(timezoneOffset, ":");
      }
    },
    // Timezone (specific non-location)
    z: function z(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timezoneOffset = originalDate.getTimezoneOffset();
      switch (token) {
        case "z":
        case "zz":
        case "zzz":
          return "GMT" + formatTimezoneShort(timezoneOffset, ":");
        case "zzzz":
        default:
          return "GMT" + formatTimezone(timezoneOffset, ":");
      }
    },
    // Seconds timestamp
    t: function t(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timestamp = Math.floor(originalDate.getTime() / 1e3);
      return addLeadingZeros(timestamp, token.length);
    },
    // Milliseconds timestamp
    T: function T(date2, token, _localize, options2) {
      var originalDate = options2._originalDate || date2;
      var timestamp = originalDate.getTime();
      return addLeadingZeros(timestamp, token.length);
    }
  };
  function formatTimezoneShort(offset2, dirtyDelimiter) {
    var sign = offset2 > 0 ? "-" : "+";
    var absOffset = Math.abs(offset2);
    var hours = Math.floor(absOffset / 60);
    var minutes = absOffset % 60;
    if (minutes === 0) {
      return sign + String(hours);
    }
    var delimiter = dirtyDelimiter || "";
    return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
  }
  function formatTimezoneWithOptionalMinutes(offset2, dirtyDelimiter) {
    if (offset2 % 60 === 0) {
      var sign = offset2 > 0 ? "-" : "+";
      return sign + addLeadingZeros(Math.abs(offset2) / 60, 2);
    }
    return formatTimezone(offset2, dirtyDelimiter);
  }
  function formatTimezone(offset2, dirtyDelimiter) {
    var delimiter = dirtyDelimiter || "";
    var sign = offset2 > 0 ? "-" : "+";
    var absOffset = Math.abs(offset2);
    var hours = addLeadingZeros(Math.floor(absOffset / 60), 2);
    var minutes = addLeadingZeros(absOffset % 60, 2);
    return sign + hours + delimiter + minutes;
  }
  var formatters_default = formatters2;

  // node_modules/date-fns/esm/_lib/format/longFormatters/index.js
  var dateLongFormatter = function dateLongFormatter2(pattern, formatLong2) {
    switch (pattern) {
      case "P":
        return formatLong2.date({
          width: "short"
        });
      case "PP":
        return formatLong2.date({
          width: "medium"
        });
      case "PPP":
        return formatLong2.date({
          width: "long"
        });
      case "PPPP":
      default:
        return formatLong2.date({
          width: "full"
        });
    }
  };
  var timeLongFormatter = function timeLongFormatter2(pattern, formatLong2) {
    switch (pattern) {
      case "p":
        return formatLong2.time({
          width: "short"
        });
      case "pp":
        return formatLong2.time({
          width: "medium"
        });
      case "ppp":
        return formatLong2.time({
          width: "long"
        });
      case "pppp":
      default:
        return formatLong2.time({
          width: "full"
        });
    }
  };
  var dateTimeLongFormatter = function dateTimeLongFormatter2(pattern, formatLong2) {
    var matchResult = pattern.match(/(P+)(p+)?/) || [];
    var datePattern = matchResult[1];
    var timePattern = matchResult[2];
    if (!timePattern) {
      return dateLongFormatter(pattern, formatLong2);
    }
    var dateTimeFormat;
    switch (datePattern) {
      case "P":
        dateTimeFormat = formatLong2.dateTime({
          width: "short"
        });
        break;
      case "PP":
        dateTimeFormat = formatLong2.dateTime({
          width: "medium"
        });
        break;
      case "PPP":
        dateTimeFormat = formatLong2.dateTime({
          width: "long"
        });
        break;
      case "PPPP":
      default:
        dateTimeFormat = formatLong2.dateTime({
          width: "full"
        });
        break;
    }
    return dateTimeFormat.replace("{{date}}", dateLongFormatter(datePattern, formatLong2)).replace("{{time}}", timeLongFormatter(timePattern, formatLong2));
  };
  var longFormatters = {
    p: timeLongFormatter,
    P: dateTimeLongFormatter
  };
  var longFormatters_default = longFormatters;

  // node_modules/date-fns/esm/_lib/protectedTokens/index.js
  var protectedDayOfYearTokens = ["D", "DD"];
  var protectedWeekYearTokens = ["YY", "YYYY"];
  function isProtectedDayOfYearToken(token) {
    return protectedDayOfYearTokens.indexOf(token) !== -1;
  }
  function isProtectedWeekYearToken(token) {
    return protectedWeekYearTokens.indexOf(token) !== -1;
  }
  function throwProtectedError(token, format3, input) {
    if (token === "YYYY") {
      throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(format3, "`) for formatting years to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
    } else if (token === "YY") {
      throw new RangeError("Use `yy` instead of `YY` (in `".concat(format3, "`) for formatting years to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
    } else if (token === "D") {
      throw new RangeError("Use `d` instead of `D` (in `".concat(format3, "`) for formatting days of the month to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
    } else if (token === "DD") {
      throw new RangeError("Use `dd` instead of `DD` (in `".concat(format3, "`) for formatting days of the month to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
    }
  }

  // node_modules/date-fns/esm/locale/en-US/_lib/formatDistance/index.js
  var formatDistanceLocale = {
    lessThanXSeconds: {
      one: "less than a second",
      other: "less than {{count}} seconds"
    },
    xSeconds: {
      one: "1 second",
      other: "{{count}} seconds"
    },
    halfAMinute: "half a minute",
    lessThanXMinutes: {
      one: "less than a minute",
      other: "less than {{count}} minutes"
    },
    xMinutes: {
      one: "1 minute",
      other: "{{count}} minutes"
    },
    aboutXHours: {
      one: "about 1 hour",
      other: "about {{count}} hours"
    },
    xHours: {
      one: "1 hour",
      other: "{{count}} hours"
    },
    xDays: {
      one: "1 day",
      other: "{{count}} days"
    },
    aboutXWeeks: {
      one: "about 1 week",
      other: "about {{count}} weeks"
    },
    xWeeks: {
      one: "1 week",
      other: "{{count}} weeks"
    },
    aboutXMonths: {
      one: "about 1 month",
      other: "about {{count}} months"
    },
    xMonths: {
      one: "1 month",
      other: "{{count}} months"
    },
    aboutXYears: {
      one: "about 1 year",
      other: "about {{count}} years"
    },
    xYears: {
      one: "1 year",
      other: "{{count}} years"
    },
    overXYears: {
      one: "over 1 year",
      other: "over {{count}} years"
    },
    almostXYears: {
      one: "almost 1 year",
      other: "almost {{count}} years"
    }
  };
  var formatDistance = function formatDistance2(token, count, options2) {
    var result;
    var tokenValue = formatDistanceLocale[token];
    if (typeof tokenValue === "string") {
      result = tokenValue;
    } else if (count === 1) {
      result = tokenValue.one;
    } else {
      result = tokenValue.other.replace("{{count}}", count.toString());
    }
    if (options2 !== null && options2 !== void 0 && options2.addSuffix) {
      if (options2.comparison && options2.comparison > 0) {
        return "in " + result;
      } else {
        return result + " ago";
      }
    }
    return result;
  };
  var formatDistance_default = formatDistance;

  // node_modules/date-fns/esm/locale/_lib/buildFormatLongFn/index.js
  function buildFormatLongFn(args) {
    return function() {
      var options2 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var width = options2.width ? String(options2.width) : args.defaultWidth;
      var format3 = args.formats[width] || args.formats[args.defaultWidth];
      return format3;
    };
  }

  // node_modules/date-fns/esm/locale/en-US/_lib/formatLong/index.js
  var dateFormats = {
    full: "EEEE, MMMM do, y",
    long: "MMMM do, y",
    medium: "MMM d, y",
    short: "MM/dd/yyyy"
  };
  var timeFormats = {
    full: "h:mm:ss a zzzz",
    long: "h:mm:ss a z",
    medium: "h:mm:ss a",
    short: "h:mm a"
  };
  var dateTimeFormats = {
    full: "{{date}} 'at' {{time}}",
    long: "{{date}} 'at' {{time}}",
    medium: "{{date}}, {{time}}",
    short: "{{date}}, {{time}}"
  };
  var formatLong = {
    date: buildFormatLongFn({
      formats: dateFormats,
      defaultWidth: "full"
    }),
    time: buildFormatLongFn({
      formats: timeFormats,
      defaultWidth: "full"
    }),
    dateTime: buildFormatLongFn({
      formats: dateTimeFormats,
      defaultWidth: "full"
    })
  };
  var formatLong_default = formatLong;

  // node_modules/date-fns/esm/locale/en-US/_lib/formatRelative/index.js
  var formatRelativeLocale = {
    lastWeek: "'last' eeee 'at' p",
    yesterday: "'yesterday at' p",
    today: "'today at' p",
    tomorrow: "'tomorrow at' p",
    nextWeek: "eeee 'at' p",
    other: "P"
  };
  var formatRelative = function formatRelative2(token, _date, _baseDate, _options) {
    return formatRelativeLocale[token];
  };
  var formatRelative_default = formatRelative;

  // node_modules/date-fns/esm/locale/_lib/buildLocalizeFn/index.js
  function buildLocalizeFn(args) {
    return function(dirtyIndex, options2) {
      var context = options2 !== null && options2 !== void 0 && options2.context ? String(options2.context) : "standalone";
      var valuesArray;
      if (context === "formatting" && args.formattingValues) {
        var defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
        var width = options2 !== null && options2 !== void 0 && options2.width ? String(options2.width) : defaultWidth;
        valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
      } else {
        var _defaultWidth = args.defaultWidth;
        var _width = options2 !== null && options2 !== void 0 && options2.width ? String(options2.width) : args.defaultWidth;
        valuesArray = args.values[_width] || args.values[_defaultWidth];
      }
      var index = args.argumentCallback ? args.argumentCallback(dirtyIndex) : dirtyIndex;
      return valuesArray[index];
    };
  }

  // node_modules/date-fns/esm/locale/en-US/_lib/localize/index.js
  var eraValues = {
    narrow: ["B", "A"],
    abbreviated: ["BC", "AD"],
    wide: ["Before Christ", "Anno Domini"]
  };
  var quarterValues = {
    narrow: ["1", "2", "3", "4"],
    abbreviated: ["Q1", "Q2", "Q3", "Q4"],
    wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
  };
  var monthValues = {
    narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
    abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
  };
  var dayValues = {
    narrow: ["S", "M", "T", "W", "T", "F", "S"],
    short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
    abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  };
  var dayPeriodValues = {
    narrow: {
      am: "a",
      pm: "p",
      midnight: "mi",
      noon: "n",
      morning: "morning",
      afternoon: "afternoon",
      evening: "evening",
      night: "night"
    },
    abbreviated: {
      am: "AM",
      pm: "PM",
      midnight: "midnight",
      noon: "noon",
      morning: "morning",
      afternoon: "afternoon",
      evening: "evening",
      night: "night"
    },
    wide: {
      am: "a.m.",
      pm: "p.m.",
      midnight: "midnight",
      noon: "noon",
      morning: "morning",
      afternoon: "afternoon",
      evening: "evening",
      night: "night"
    }
  };
  var formattingDayPeriodValues = {
    narrow: {
      am: "a",
      pm: "p",
      midnight: "mi",
      noon: "n",
      morning: "in the morning",
      afternoon: "in the afternoon",
      evening: "in the evening",
      night: "at night"
    },
    abbreviated: {
      am: "AM",
      pm: "PM",
      midnight: "midnight",
      noon: "noon",
      morning: "in the morning",
      afternoon: "in the afternoon",
      evening: "in the evening",
      night: "at night"
    },
    wide: {
      am: "a.m.",
      pm: "p.m.",
      midnight: "midnight",
      noon: "noon",
      morning: "in the morning",
      afternoon: "in the afternoon",
      evening: "in the evening",
      night: "at night"
    }
  };
  var ordinalNumber = function ordinalNumber2(dirtyNumber, _options) {
    var number = Number(dirtyNumber);
    var rem100 = number % 100;
    if (rem100 > 20 || rem100 < 10) {
      switch (rem100 % 10) {
        case 1:
          return number + "st";
        case 2:
          return number + "nd";
        case 3:
          return number + "rd";
      }
    }
    return number + "th";
  };
  var localize = {
    ordinalNumber,
    era: buildLocalizeFn({
      values: eraValues,
      defaultWidth: "wide"
    }),
    quarter: buildLocalizeFn({
      values: quarterValues,
      defaultWidth: "wide",
      argumentCallback: function argumentCallback(quarter) {
        return quarter - 1;
      }
    }),
    month: buildLocalizeFn({
      values: monthValues,
      defaultWidth: "wide"
    }),
    day: buildLocalizeFn({
      values: dayValues,
      defaultWidth: "wide"
    }),
    dayPeriod: buildLocalizeFn({
      values: dayPeriodValues,
      defaultWidth: "wide",
      formattingValues: formattingDayPeriodValues,
      defaultFormattingWidth: "wide"
    })
  };
  var localize_default = localize;

  // node_modules/date-fns/esm/locale/_lib/buildMatchFn/index.js
  function buildMatchFn(args) {
    return function(string) {
      var options2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var width = options2.width;
      var matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
      var matchResult = string.match(matchPattern);
      if (!matchResult) {
        return null;
      }
      var matchedString = matchResult[0];
      var parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
      var key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, function(pattern) {
        return pattern.test(matchedString);
      }) : findKey(parsePatterns, function(pattern) {
        return pattern.test(matchedString);
      });
      var value;
      value = args.valueCallback ? args.valueCallback(key) : key;
      value = options2.valueCallback ? options2.valueCallback(value) : value;
      var rest = string.slice(matchedString.length);
      return {
        value,
        rest
      };
    };
  }
  function findKey(object, predicate) {
    for (var key in object) {
      if (object.hasOwnProperty(key) && predicate(object[key])) {
        return key;
      }
    }
    return void 0;
  }
  function findIndex(array, predicate) {
    for (var key = 0; key < array.length; key++) {
      if (predicate(array[key])) {
        return key;
      }
    }
    return void 0;
  }

  // node_modules/date-fns/esm/locale/_lib/buildMatchPatternFn/index.js
  function buildMatchPatternFn(args) {
    return function(string) {
      var options2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var matchResult = string.match(args.matchPattern);
      if (!matchResult)
        return null;
      var matchedString = matchResult[0];
      var parseResult = string.match(args.parsePattern);
      if (!parseResult)
        return null;
      var value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
      value = options2.valueCallback ? options2.valueCallback(value) : value;
      var rest = string.slice(matchedString.length);
      return {
        value,
        rest
      };
    };
  }

  // node_modules/date-fns/esm/locale/en-US/_lib/match/index.js
  var matchOrdinalNumberPattern = /^(\d+)(th|st|nd|rd)?/i;
  var parseOrdinalNumberPattern = /\d+/i;
  var matchEraPatterns = {
    narrow: /^(b|a)/i,
    abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
    wide: /^(before christ|before common era|anno domini|common era)/i
  };
  var parseEraPatterns = {
    any: [/^b/i, /^(a|c)/i]
  };
  var matchQuarterPatterns = {
    narrow: /^[1234]/i,
    abbreviated: /^q[1234]/i,
    wide: /^[1234](th|st|nd|rd)? quarter/i
  };
  var parseQuarterPatterns = {
    any: [/1/i, /2/i, /3/i, /4/i]
  };
  var matchMonthPatterns = {
    narrow: /^[jfmasond]/i,
    abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
    wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
  };
  var parseMonthPatterns = {
    narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
    any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
  };
  var matchDayPatterns = {
    narrow: /^[smtwf]/i,
    short: /^(su|mo|tu|we|th|fr|sa)/i,
    abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
    wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
  };
  var parseDayPatterns = {
    narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
    any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
  };
  var matchDayPeriodPatterns = {
    narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
    any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
  };
  var parseDayPeriodPatterns = {
    any: {
      am: /^a/i,
      pm: /^p/i,
      midnight: /^mi/i,
      noon: /^no/i,
      morning: /morning/i,
      afternoon: /afternoon/i,
      evening: /evening/i,
      night: /night/i
    }
  };
  var match = {
    ordinalNumber: buildMatchPatternFn({
      matchPattern: matchOrdinalNumberPattern,
      parsePattern: parseOrdinalNumberPattern,
      valueCallback: function valueCallback(value) {
        return parseInt(value, 10);
      }
    }),
    era: buildMatchFn({
      matchPatterns: matchEraPatterns,
      defaultMatchWidth: "wide",
      parsePatterns: parseEraPatterns,
      defaultParseWidth: "any"
    }),
    quarter: buildMatchFn({
      matchPatterns: matchQuarterPatterns,
      defaultMatchWidth: "wide",
      parsePatterns: parseQuarterPatterns,
      defaultParseWidth: "any",
      valueCallback: function valueCallback2(index) {
        return index + 1;
      }
    }),
    month: buildMatchFn({
      matchPatterns: matchMonthPatterns,
      defaultMatchWidth: "wide",
      parsePatterns: parseMonthPatterns,
      defaultParseWidth: "any"
    }),
    day: buildMatchFn({
      matchPatterns: matchDayPatterns,
      defaultMatchWidth: "wide",
      parsePatterns: parseDayPatterns,
      defaultParseWidth: "any"
    }),
    dayPeriod: buildMatchFn({
      matchPatterns: matchDayPeriodPatterns,
      defaultMatchWidth: "any",
      parsePatterns: parseDayPeriodPatterns,
      defaultParseWidth: "any"
    })
  };
  var match_default = match;

  // node_modules/date-fns/esm/locale/en-US/index.js
  var locale = {
    code: "en-US",
    formatDistance: formatDistance_default,
    formatLong: formatLong_default,
    formatRelative: formatRelative_default,
    localize: localize_default,
    match: match_default,
    options: {
      weekStartsOn: 0,
      firstWeekContainsDate: 1
    }
  };
  var en_US_default = locale;

  // node_modules/date-fns/esm/_lib/defaultLocale/index.js
  var defaultLocale_default = en_US_default;

  // node_modules/date-fns/esm/format/index.js
  var formattingTokensRegExp = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
  var longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
  var escapedStringRegExp = /^'([^]*?)'?$/;
  var doubleQuoteRegExp = /''/g;
  var unescapedLatinCharacterRegExp = /[a-zA-Z]/;
  function format(dirtyDate, dirtyFormatStr, options2) {
    var _ref, _options$locale, _ref2, _ref3, _ref4, _options$firstWeekCon, _options$locale2, _options$locale2$opti, _defaultOptions$local, _defaultOptions$local2, _ref5, _ref6, _ref7, _options$weekStartsOn, _options$locale3, _options$locale3$opti, _defaultOptions$local3, _defaultOptions$local4;
    requiredArgs(2, arguments);
    var formatStr = String(dirtyFormatStr);
    var defaultOptions3 = getDefaultOptions();
    var locale2 = (_ref = (_options$locale = options2 === null || options2 === void 0 ? void 0 : options2.locale) !== null && _options$locale !== void 0 ? _options$locale : defaultOptions3.locale) !== null && _ref !== void 0 ? _ref : defaultLocale_default;
    var firstWeekContainsDate = toInteger((_ref2 = (_ref3 = (_ref4 = (_options$firstWeekCon = options2 === null || options2 === void 0 ? void 0 : options2.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options2 === null || options2 === void 0 ? void 0 : (_options$locale2 = options2.locale) === null || _options$locale2 === void 0 ? void 0 : (_options$locale2$opti = _options$locale2.options) === null || _options$locale2$opti === void 0 ? void 0 : _options$locale2$opti.firstWeekContainsDate) !== null && _ref4 !== void 0 ? _ref4 : defaultOptions3.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : (_defaultOptions$local = defaultOptions3.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : 1);
    if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
      throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
    }
    var weekStartsOn = toInteger((_ref5 = (_ref6 = (_ref7 = (_options$weekStartsOn = options2 === null || options2 === void 0 ? void 0 : options2.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options2 === null || options2 === void 0 ? void 0 : (_options$locale3 = options2.locale) === null || _options$locale3 === void 0 ? void 0 : (_options$locale3$opti = _options$locale3.options) === null || _options$locale3$opti === void 0 ? void 0 : _options$locale3$opti.weekStartsOn) !== null && _ref7 !== void 0 ? _ref7 : defaultOptions3.weekStartsOn) !== null && _ref6 !== void 0 ? _ref6 : (_defaultOptions$local3 = defaultOptions3.locale) === null || _defaultOptions$local3 === void 0 ? void 0 : (_defaultOptions$local4 = _defaultOptions$local3.options) === null || _defaultOptions$local4 === void 0 ? void 0 : _defaultOptions$local4.weekStartsOn) !== null && _ref5 !== void 0 ? _ref5 : 0);
    if (!(weekStartsOn >= 0 && weekStartsOn <= 6)) {
      throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
    }
    if (!locale2.localize) {
      throw new RangeError("locale must contain localize property");
    }
    if (!locale2.formatLong) {
      throw new RangeError("locale must contain formatLong property");
    }
    var originalDate = toDate(dirtyDate);
    if (!isValid(originalDate)) {
      throw new RangeError("Invalid time value");
    }
    var timezoneOffset = getTimezoneOffsetInMilliseconds(originalDate);
    var utcDate = subMilliseconds(originalDate, timezoneOffset);
    var formatterOptions = {
      firstWeekContainsDate,
      weekStartsOn,
      locale: locale2,
      _originalDate: originalDate
    };
    var result = formatStr.match(longFormattingTokensRegExp).map(function(substring) {
      var firstCharacter = substring[0];
      if (firstCharacter === "p" || firstCharacter === "P") {
        var longFormatter = longFormatters_default[firstCharacter];
        return longFormatter(substring, locale2.formatLong);
      }
      return substring;
    }).join("").match(formattingTokensRegExp).map(function(substring) {
      if (substring === "''") {
        return "'";
      }
      var firstCharacter = substring[0];
      if (firstCharacter === "'") {
        return cleanEscapedString(substring);
      }
      var formatter = formatters_default[firstCharacter];
      if (formatter) {
        if (!(options2 !== null && options2 !== void 0 && options2.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(substring)) {
          throwProtectedError(substring, dirtyFormatStr, String(dirtyDate));
        }
        if (!(options2 !== null && options2 !== void 0 && options2.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(substring)) {
          throwProtectedError(substring, dirtyFormatStr, String(dirtyDate));
        }
        return formatter(utcDate, substring, locale2.localize, formatterOptions);
      }
      if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
        throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
      }
      return substring;
    }).join("");
    return result;
  }
  function cleanEscapedString(input) {
    var matched = input.match(escapedStringRegExp);
    if (!matched) {
      return input;
    }
    return matched[1].replace(doubleQuoteRegExp, "'");
  }

  // node_modules/liquidjs/dist/liquid.browser.esm.js
  var Token = class {
    constructor(kind, input, begin, end, file) {
      this.kind = kind;
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
    }
    getText() {
      return this.input.slice(this.begin, this.end);
    }
    getPosition() {
      let [row, col] = [1, 1];
      for (let i2 = 0; i2 < this.begin; i2++) {
        if (this.input[i2] === "\n") {
          row++;
          col = 1;
        } else
          col++;
      }
      return [row, col];
    }
    size() {
      return this.end - this.begin;
    }
  };
  var Drop = class {
    liquidMethodMissing(key) {
      return void 0;
    }
  };
  var toString$1 = Object.prototype.toString;
  var toLowerCase = String.prototype.toLowerCase;
  var hasOwnProperty = Object.hasOwnProperty;
  function isString(value) {
    return typeof value === "string";
  }
  function isFunction(value) {
    return typeof value === "function";
  }
  function isPromise(val) {
    return val && isFunction(val.then);
  }
  function isIterator(val) {
    return val && isFunction(val.next) && isFunction(val.throw) && isFunction(val.return);
  }
  function escapeRegex(str) {
    return str.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
  }
  function stringify(value) {
    value = toValue(value);
    if (isString(value))
      return value;
    if (isNil(value))
      return "";
    if (isArray(value))
      return value.map((x2) => stringify(x2)).join("");
    return String(value);
  }
  function toValue(value) {
    return value instanceof Drop && isFunction(value.valueOf) ? value.valueOf() : value;
  }
  function isNumber(value) {
    return typeof value === "number";
  }
  function toLiquid(value) {
    if (value && isFunction(value.toLiquid))
      return toLiquid(value.toLiquid());
    return value;
  }
  function isNil(value) {
    return value == null;
  }
  function isUndefined(value) {
    return value === void 0;
  }
  function isArray(value) {
    return toString$1.call(value) === "[object Array]";
  }
  function isIterable(value) {
    return isObject(value) && Symbol.iterator in value;
  }
  function forOwn(obj, iteratee) {
    obj = obj || {};
    for (const k2 in obj) {
      if (hasOwnProperty.call(obj, k2)) {
        if (iteratee(obj[k2], k2, obj) === false)
          break;
      }
    }
    return obj;
  }
  function last(arr) {
    return arr[arr.length - 1];
  }
  function isObject(value) {
    const type = typeof value;
    return value !== null && (type === "object" || type === "function");
  }
  function range(start, stop, step = 1) {
    const arr = [];
    for (let i2 = start; i2 < stop; i2 += step) {
      arr.push(i2);
    }
    return arr;
  }
  function padStart(str, length, ch = " ") {
    return pad(str, length, ch, (str2, ch2) => ch2 + str2);
  }
  function padEnd(str, length, ch = " ") {
    return pad(str, length, ch, (str2, ch2) => str2 + ch2);
  }
  function pad(str, length, ch, add) {
    str = String(str);
    let n = length - str.length;
    while (n-- > 0)
      str = add(str, ch);
    return str;
  }
  function identify(val) {
    return val;
  }
  function changeCase(str) {
    const hasLowerCase = [...str].some((ch) => ch >= "a" && ch <= "z");
    return hasLowerCase ? str.toUpperCase() : str.toLowerCase();
  }
  function ellipsis(str, N) {
    return str.length > N ? str.slice(0, N - 3) + "..." : str;
  }
  function caseInsensitiveCompare(a3, b2) {
    if (a3 == null && b2 == null)
      return 0;
    if (a3 == null)
      return 1;
    if (b2 == null)
      return -1;
    a3 = toLowerCase.call(a3);
    b2 = toLowerCase.call(b2);
    if (a3 < b2)
      return -1;
    if (a3 > b2)
      return 1;
    return 0;
  }
  function argumentsToValue(fn) {
    return (...args) => fn(...args.map(toValue));
  }
  function escapeRegExp(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
  }
  var TRAIT = "__liquidClass__";
  var LiquidError = class extends Error {
    constructor(err, token) {
      super(typeof err === "string" ? err : err.message);
      this.context = "";
      if (typeof err !== "string")
        Object.defineProperty(this, "originalError", { value: err, enumerable: false });
      Object.defineProperty(this, "token", { value: token, enumerable: false });
      Object.defineProperty(this, TRAIT, { value: "LiquidError", enumerable: false });
    }
    update() {
      Object.defineProperty(this, "context", { value: mkContext(this.token), enumerable: false });
      this.message = mkMessage(this.message, this.token);
      this.stack = this.message + "\n" + this.context + "\n" + this.stack;
      if (this.originalError)
        this.stack += "\nFrom " + this.originalError.stack;
    }
    static is(obj) {
      return (obj === null || obj === void 0 ? void 0 : obj[TRAIT]) === "LiquidError";
    }
  };
  var TokenizationError = class extends LiquidError {
    constructor(message, token) {
      super(message, token);
      this.name = "TokenizationError";
      super.update();
    }
  };
  var ParseError = class extends LiquidError {
    constructor(err, token) {
      super(err, token);
      this.name = "ParseError";
      this.message = err.message;
      super.update();
    }
  };
  var RenderError = class extends LiquidError {
    constructor(err, tpl) {
      super(err, tpl.token);
      this.name = "RenderError";
      this.message = err.message;
      super.update();
    }
    static is(obj) {
      return obj.name === "RenderError";
    }
  };
  var UndefinedVariableError = class extends LiquidError {
    constructor(err, token) {
      super(err, token);
      this.name = "UndefinedVariableError";
      this.message = err.message;
      super.update();
    }
  };
  var InternalUndefinedVariableError = class extends Error {
    constructor(variableName) {
      super(`undefined variable: ${variableName}`);
      this.name = "InternalUndefinedVariableError";
      this.variableName = variableName;
    }
  };
  var AssertionError = class extends Error {
    constructor(message) {
      super(message);
      this.name = "AssertionError";
      this.message = message + "";
    }
  };
  function mkContext(token) {
    const [line, col] = token.getPosition();
    const lines = token.input.split("\n");
    const begin = Math.max(line - 2, 1);
    const end = Math.min(line + 3, lines.length);
    const context = range(begin, end + 1).map((lineNumber) => {
      const rowIndicator = lineNumber === line ? ">> " : "   ";
      const num = padStart(String(lineNumber), String(end).length);
      let text = `${rowIndicator}${num}| `;
      const colIndicator = lineNumber === line ? "\n" + padStart("^", col + text.length) : "";
      text += lines[lineNumber - 1];
      text += colIndicator;
      return text;
    }).join("\n");
    return context;
  }
  function mkMessage(msg, token) {
    if (token.file)
      msg += `, file:${token.file}`;
    const [line, col] = token.getPosition();
    msg += `, line:${line}, col:${col}`;
    return msg;
  }
  var TYPES = [0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 4, 4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 2, 8, 0, 0, 0, 0, 8, 0, 0, 0, 64, 0, 65, 0, 0, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 0, 0, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0];
  var WORD = 1;
  var BLANK = 4;
  var QUOTE = 8;
  var INLINE_BLANK = 16;
  var NUMBER = 32;
  var SIGN = 64;
  var PUNCTUATION = 128;
  function isWord(char) {
    const code = char.charCodeAt(0);
    return code >= 128 ? !TYPES[code] : !!(TYPES[code] & WORD);
  }
  TYPES[160] = TYPES[5760] = TYPES[6158] = TYPES[8192] = TYPES[8193] = TYPES[8194] = TYPES[8195] = TYPES[8196] = TYPES[8197] = TYPES[8198] = TYPES[8199] = TYPES[8200] = TYPES[8201] = TYPES[8202] = TYPES[8232] = TYPES[8233] = TYPES[8239] = TYPES[8287] = TYPES[12288] = BLANK;
  TYPES[8220] = TYPES[8221] = PUNCTUATION;
  function assert(predicate, message) {
    if (!predicate) {
      const msg = typeof message === "function" ? message() : message || `expect ${predicate} to be true`;
      throw new AssertionError(msg);
    }
  }
  var NullDrop = class extends Drop {
    equals(value) {
      return isNil(toValue(value));
    }
    gt() {
      return false;
    }
    geq() {
      return false;
    }
    lt() {
      return false;
    }
    leq() {
      return false;
    }
    valueOf() {
      return null;
    }
  };
  var EmptyDrop = class extends Drop {
    equals(value) {
      if (value instanceof EmptyDrop)
        return false;
      value = toValue(value);
      if (isString(value) || isArray(value))
        return value.length === 0;
      if (isObject(value))
        return Object.keys(value).length === 0;
      return false;
    }
    gt() {
      return false;
    }
    geq() {
      return false;
    }
    lt() {
      return false;
    }
    leq() {
      return false;
    }
    valueOf() {
      return "";
    }
  };
  var BlankDrop = class extends EmptyDrop {
    equals(value) {
      if (value === false)
        return true;
      if (isNil(toValue(value)))
        return true;
      if (isString(value))
        return /^\s*$/.test(value);
      return super.equals(value);
    }
  };
  var ForloopDrop = class extends Drop {
    constructor(length, collection, variable) {
      super();
      this.i = 0;
      this.length = length;
      this.name = `${variable}-${collection}`;
    }
    next() {
      this.i++;
    }
    index0() {
      return this.i;
    }
    index() {
      return this.i + 1;
    }
    first() {
      return this.i === 0;
    }
    last() {
      return this.i === this.length - 1;
    }
    rindex() {
      return this.length - this.i;
    }
    rindex0() {
      return this.length - this.i - 1;
    }
    valueOf() {
      return JSON.stringify(this);
    }
  };
  var BlockDrop = class extends Drop {
    constructor(superBlockRender = () => "") {
      super();
      this.superBlockRender = superBlockRender;
    }
    /**
     * Provide parent access in child block by
     * {{ block.super }}
     */
    super() {
      return this.superBlockRender();
    }
  };
  function isComparable(arg) {
    return arg && isFunction(arg.equals);
  }
  var nil = new NullDrop();
  var literalValues = {
    "true": true,
    "false": false,
    "nil": nil,
    "null": nil,
    "empty": new EmptyDrop(),
    "blank": new BlankDrop()
  };
  function createTrie(input) {
    const trie = {};
    for (const [name, data] of Object.entries(input)) {
      let node = trie;
      for (let i2 = 0; i2 < name.length; i2++) {
        const c2 = name[i2];
        node[c2] = node[c2] || {};
        if (i2 === name.length - 1 && isWord(name[i2])) {
          node[c2].needBoundary = true;
        }
        node = node[c2];
      }
      node.data = data;
      node.end = true;
    }
    return trie;
  }
  var __assign = function() {
    __assign = Object.assign || function __assign2(t2) {
      for (var s3, i2 = 1, n = arguments.length; i2 < n; i2++) {
        s3 = arguments[i2];
        for (var p in s3)
          if (Object.prototype.hasOwnProperty.call(s3, p))
            t2[p] = s3[p];
      }
      return t2;
    };
    return __assign.apply(this, arguments);
  };
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve2) {
        resolve2(value);
      });
    }
    return new (P || (P = Promise))(function(resolve2, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  function toPromise(val) {
    return __awaiter(this, void 0, void 0, function* () {
      if (!isIterator(val))
        return val;
      let value;
      let done = false;
      let next = "next";
      do {
        const state = val[next](value);
        done = state.done;
        value = state.value;
        next = "next";
        try {
          if (isIterator(value))
            value = toPromise(value);
          if (isPromise(value))
            value = yield value;
        } catch (err) {
          next = "throw";
          value = err;
        }
      } while (!done);
      return value;
    });
  }
  function toValueSync(val) {
    if (!isIterator(val))
      return val;
    let value;
    let done = false;
    let next = "next";
    do {
      const state = val[next](value);
      done = state.done;
      value = state.value;
      next = "next";
      if (isIterator(value)) {
        try {
          value = toValueSync(value);
        } catch (err) {
          next = "throw";
          value = err;
        }
      }
    } while (!done);
    return value;
  }
  function toEnumerable(val) {
    val = toValue(val);
    if (isArray(val))
      return val;
    if (isString(val) && val.length > 0)
      return [val];
    if (isIterable(val))
      return Array.from(val);
    if (isObject(val))
      return Object.keys(val).map((key) => [key, val[key]]);
    return [];
  }
  function toArray(val) {
    if (isNil(val))
      return [];
    if (isArray(val))
      return val;
    return [val];
  }
  var rFormat = /%([-_0^#:]+)?(\d+)?([EO])?(.)/;
  var monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  var dayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  var monthNamesShort = monthNames.map(abbr);
  var dayNamesShort = dayNames.map(abbr);
  function abbr(str) {
    return str.slice(0, 3);
  }
  function daysInMonth(d3) {
    const feb = isLeapYear(d3) ? 29 : 28;
    return [31, feb, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  }
  function getDayOfYear(d3) {
    let num = 0;
    for (let i2 = 0; i2 < d3.getMonth(); ++i2) {
      num += daysInMonth(d3)[i2];
    }
    return num + d3.getDate();
  }
  function getWeekOfYear(d3, startDay) {
    const now = getDayOfYear(d3) + (startDay - d3.getDay());
    const jan1 = new Date(d3.getFullYear(), 0, 1);
    const then = 7 - jan1.getDay() + startDay;
    return String(Math.floor((now - then) / 7) + 1);
  }
  function isLeapYear(d3) {
    const year = d3.getFullYear();
    return !!((year & 3) === 0 && (year % 100 || year % 400 === 0 && year));
  }
  function getSuffix(d3) {
    const date2 = d3.getDate();
    let suffix = "th";
    switch (date2) {
      case 11:
      case 12:
      case 13:
        break;
      default:
        switch (date2 % 10) {
          case 1:
            suffix = "st";
            break;
          case 2:
            suffix = "nd";
            break;
          case 3:
            suffix = "rd";
            break;
        }
    }
    return suffix;
  }
  function century(d3) {
    return parseInt(d3.getFullYear().toString().substring(0, 2), 10);
  }
  var padWidths = {
    d: 2,
    e: 2,
    H: 2,
    I: 2,
    j: 3,
    k: 2,
    l: 2,
    L: 3,
    m: 2,
    M: 2,
    S: 2,
    U: 2,
    W: 2
  };
  var padChars = {
    a: " ",
    A: " ",
    b: " ",
    B: " ",
    c: " ",
    e: " ",
    k: " ",
    l: " ",
    p: " ",
    P: " "
  };
  var formatCodes = {
    a: (d3) => dayNamesShort[d3.getDay()],
    A: (d3) => dayNames[d3.getDay()],
    b: (d3) => monthNamesShort[d3.getMonth()],
    B: (d3) => monthNames[d3.getMonth()],
    c: (d3) => d3.toLocaleString(),
    C: (d3) => century(d3),
    d: (d3) => d3.getDate(),
    e: (d3) => d3.getDate(),
    H: (d3) => d3.getHours(),
    I: (d3) => String(d3.getHours() % 12 || 12),
    j: (d3) => getDayOfYear(d3),
    k: (d3) => d3.getHours(),
    l: (d3) => String(d3.getHours() % 12 || 12),
    L: (d3) => d3.getMilliseconds(),
    m: (d3) => d3.getMonth() + 1,
    M: (d3) => d3.getMinutes(),
    N: (d3, opts) => {
      const width = Number(opts.width) || 9;
      const str = String(d3.getMilliseconds()).slice(0, width);
      return padEnd(str, width, "0");
    },
    p: (d3) => d3.getHours() < 12 ? "AM" : "PM",
    P: (d3) => d3.getHours() < 12 ? "am" : "pm",
    q: (d3) => getSuffix(d3),
    s: (d3) => Math.round(d3.getTime() / 1e3),
    S: (d3) => d3.getSeconds(),
    u: (d3) => d3.getDay() || 7,
    U: (d3) => getWeekOfYear(d3, 0),
    w: (d3) => d3.getDay(),
    W: (d3) => getWeekOfYear(d3, 1),
    x: (d3) => d3.toLocaleDateString(),
    X: (d3) => d3.toLocaleTimeString(),
    y: (d3) => d3.getFullYear().toString().slice(2, 4),
    Y: (d3) => d3.getFullYear(),
    z: (d3, opts) => {
      const nOffset = Math.abs(d3.getTimezoneOffset());
      const h3 = Math.floor(nOffset / 60);
      const m3 = nOffset % 60;
      return (d3.getTimezoneOffset() > 0 ? "-" : "+") + padStart(h3, 2, "0") + (opts.flags[":"] ? ":" : "") + padStart(m3, 2, "0");
    },
    "t": () => "	",
    "n": () => "\n",
    "%": () => "%"
  };
  formatCodes.h = formatCodes.b;
  function strftime(d3, formatStr) {
    let output = "";
    let remaining = formatStr;
    let match2;
    while (match2 = rFormat.exec(remaining)) {
      output += remaining.slice(0, match2.index);
      remaining = remaining.slice(match2.index + match2[0].length);
      output += format2(d3, match2);
    }
    return output + remaining;
  }
  function format2(d3, match2) {
    const [input, flagStr = "", width, modifier, conversion] = match2;
    const convert = formatCodes[conversion];
    if (!convert)
      return input;
    const flags = {};
    for (const flag of flagStr)
      flags[flag] = true;
    let ret = String(convert(d3, { flags, width, modifier }));
    let padChar = padChars[conversion] || "0";
    let padWidth = width || padWidths[conversion] || 0;
    if (flags["^"])
      ret = ret.toUpperCase();
    else if (flags["#"])
      ret = changeCase(ret);
    if (flags["_"])
      padChar = " ";
    else if (flags["0"])
      padChar = "0";
    if (flags["-"])
      padWidth = 0;
    return padStart(ret, padWidth, padChar);
  }
  var OneMinute = 6e4;
  var ISO8601_TIMEZONE_PATTERN = /([zZ]|([+-])(\d{2}):(\d{2}))$/;
  var TimezoneDate = class {
    constructor(init, timezoneOffset) {
      this.date = init instanceof TimezoneDate ? init.date : new Date(init);
      this.timezoneOffset = timezoneOffset;
      const diff = (this.date.getTimezoneOffset() - this.timezoneOffset) * OneMinute;
      const time = this.date.getTime() + diff;
      this.displayDate = new Date(time);
    }
    getTime() {
      return this.displayDate.getTime();
    }
    getMilliseconds() {
      return this.displayDate.getMilliseconds();
    }
    getSeconds() {
      return this.displayDate.getSeconds();
    }
    getMinutes() {
      return this.displayDate.getMinutes();
    }
    getHours() {
      return this.displayDate.getHours();
    }
    getDay() {
      return this.displayDate.getDay();
    }
    getDate() {
      return this.displayDate.getDate();
    }
    getMonth() {
      return this.displayDate.getMonth();
    }
    getFullYear() {
      return this.displayDate.getFullYear();
    }
    toLocaleString(locale2, init) {
      if (init === null || init === void 0 ? void 0 : init.timeZone) {
        return this.date.toLocaleString(locale2, init);
      }
      return this.displayDate.toLocaleString(locale2, init);
    }
    toLocaleTimeString(locale2) {
      return this.displayDate.toLocaleTimeString(locale2);
    }
    toLocaleDateString(locale2) {
      return this.displayDate.toLocaleDateString(locale2);
    }
    getTimezoneOffset() {
      return this.timezoneOffset;
    }
    /**
     * Create a Date object fixed to it's declared Timezone. Both
     * - 2021-08-06T02:29:00.000Z and
     * - 2021-08-06T02:29:00.000+08:00
     * will always be displayed as
     * - 2021-08-06 02:29:00
     * regardless timezoneOffset in JavaScript realm
     *
     * The implementation hack:
     * Instead of calling `.getMonth()`/`.getUTCMonth()` respect to `preserveTimezones`,
     * we create a different Date to trick strftime, it's both simpler and more performant.
     * Given that a template is expected to be parsed fewer times than rendered.
     */
    static createDateFixedToTimezone(dateString) {
      const m3 = dateString.match(ISO8601_TIMEZONE_PATTERN);
      if (m3 && m3[1] === "Z") {
        return new TimezoneDate(+new Date(dateString), 0);
      }
      if (m3 && m3[2] && m3[3] && m3[4]) {
        const [, , sign, hours, minutes] = m3;
        const offset2 = (sign === "+" ? -1 : 1) * (parseInt(hours, 10) * 60 + parseInt(minutes, 10));
        return new TimezoneDate(+new Date(dateString), offset2);
      }
      return new Date(dateString);
    }
  };
  var DelimitedToken = class extends Token {
    constructor(kind, [contentBegin, contentEnd], input, begin, end, trimLeft2, trimRight2, file) {
      super(kind, input, begin, end, file);
      this.trimLeft = false;
      this.trimRight = false;
      const tl = input[contentBegin] === "-";
      const tr = input[contentEnd - 1] === "-";
      let l = tl ? contentBegin + 1 : contentBegin;
      let r = tr ? contentEnd - 1 : contentEnd;
      while (l < r && TYPES[input.charCodeAt(l)] & BLANK)
        l++;
      while (r > l && TYPES[input.charCodeAt(r - 1)] & BLANK)
        r--;
      this.contentRange = [l, r];
      this.trimLeft = tl || trimLeft2;
      this.trimRight = tr || trimRight2;
    }
    get content() {
      return this.input.slice(this.contentRange[0], this.contentRange[1]);
    }
  };
  var TagToken = class extends DelimitedToken {
    constructor(input, begin, end, options2, file) {
      const { trimTagLeft, trimTagRight, tagDelimiterLeft, tagDelimiterRight } = options2;
      const [valueBegin, valueEnd] = [begin + tagDelimiterLeft.length, end - tagDelimiterRight.length];
      super(TokenKind.Tag, [valueBegin, valueEnd], input, begin, end, trimTagLeft, trimTagRight, file);
      this.tokenizer = new Tokenizer(input, options2.operators, file, this.contentRange);
      this.name = this.tokenizer.readTagName();
      this.tokenizer.assert(this.name, `illegal tag syntax, tag name expected`);
      this.tokenizer.skipBlank();
    }
    get args() {
      return this.tokenizer.input.slice(this.tokenizer.p, this.contentRange[1]);
    }
  };
  var OutputToken = class extends DelimitedToken {
    constructor(input, begin, end, options2, file) {
      const { trimOutputLeft, trimOutputRight, outputDelimiterLeft, outputDelimiterRight } = options2;
      const valueRange = [begin + outputDelimiterLeft.length, end - outputDelimiterRight.length];
      super(TokenKind.Output, valueRange, input, begin, end, trimOutputLeft, trimOutputRight, file);
    }
  };
  var HTMLToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.HTML, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.trimLeft = 0;
      this.trimRight = 0;
    }
    getContent() {
      return this.input.slice(this.begin + this.trimLeft, this.end - this.trimRight);
    }
  };
  var NumberToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.Number, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.content = Number(this.getText());
    }
  };
  var IdentifierToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.Word, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.content = this.getText();
    }
    isNumber(allowSign = false) {
      const begin = allowSign && TYPES[this.input.charCodeAt(this.begin)] & SIGN ? this.begin + 1 : this.begin;
      for (let i2 = begin; i2 < this.end; i2++) {
        if (!(TYPES[this.input.charCodeAt(i2)] & NUMBER))
          return false;
      }
      return true;
    }
  };
  var LiteralToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.Literal, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.literal = this.getText();
      this.content = literalValues[this.literal];
    }
  };
  var operatorPrecedences = {
    "==": 2,
    "!=": 2,
    ">": 2,
    "<": 2,
    ">=": 2,
    "<=": 2,
    "contains": 2,
    "not": 1,
    "and": 0,
    "or": 0
  };
  var operatorTypes = {
    "==": 0,
    "!=": 0,
    ">": 0,
    "<": 0,
    ">=": 0,
    "<=": 0,
    "contains": 0,
    "not": 1,
    "and": 0,
    "or": 0
    /* OperatorType.Binary */
  };
  var OperatorToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.Operator, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.operator = this.getText();
    }
    getPrecedence() {
      const key = this.getText();
      return key in operatorPrecedences ? operatorPrecedences[key] : 1;
    }
  };
  var PropertyAccessToken = class extends Token {
    constructor(variable, props, input, begin, end, file) {
      super(TokenKind.PropertyAccess, input, begin, end, file);
      this.variable = variable;
      this.props = props;
    }
  };
  var FilterToken = class extends Token {
    constructor(name, args, input, begin, end, file) {
      super(TokenKind.Filter, input, begin, end, file);
      this.name = name;
      this.args = args;
    }
  };
  var HashToken = class extends Token {
    constructor(input, begin, end, name, value, file) {
      super(TokenKind.Hash, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.name = name;
      this.value = value;
      this.file = file;
    }
  };
  var rHex = /[\da-fA-F]/;
  var rOct = /[0-7]/;
  var escapeChar = {
    b: "\b",
    f: "\f",
    n: "\n",
    r: "\r",
    t: "	",
    v: "\v"
  };
  function hexVal(c2) {
    const code = c2.charCodeAt(0);
    if (code >= 97)
      return code - 87;
    if (code >= 65)
      return code - 55;
    return code - 48;
  }
  function parseStringLiteral(str) {
    let ret = "";
    for (let i2 = 1; i2 < str.length - 1; i2++) {
      if (str[i2] !== "\\") {
        ret += str[i2];
        continue;
      }
      if (escapeChar[str[i2 + 1]] !== void 0) {
        ret += escapeChar[str[++i2]];
      } else if (str[i2 + 1] === "u") {
        let val = 0;
        let j = i2 + 2;
        while (j <= i2 + 5 && rHex.test(str[j])) {
          val = val * 16 + hexVal(str[j++]);
        }
        i2 = j - 1;
        ret += String.fromCharCode(val);
      } else if (!rOct.test(str[i2 + 1])) {
        ret += str[++i2];
      } else {
        let j = i2 + 1;
        let val = 0;
        while (j <= i2 + 3 && rOct.test(str[j])) {
          val = val * 8 + hexVal(str[j++]);
        }
        i2 = j - 1;
        ret += String.fromCharCode(val);
      }
    }
    return ret;
  }
  var QuotedToken = class extends Token {
    constructor(input, begin, end, file) {
      super(TokenKind.Quoted, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
      this.content = parseStringLiteral(this.getText());
    }
  };
  var RangeToken = class extends Token {
    constructor(input, begin, end, lhs, rhs, file) {
      super(TokenKind.Range, input, begin, end, file);
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.lhs = lhs;
      this.rhs = rhs;
      this.file = file;
    }
  };
  var LiquidTagToken = class extends DelimitedToken {
    constructor(input, begin, end, options2, file) {
      super(TokenKind.Tag, [begin, end], input, begin, end, false, false, file);
      this.tokenizer = new Tokenizer(input, options2.operators, file, this.contentRange);
      this.name = this.tokenizer.readTagName();
      this.tokenizer.assert(this.name, "illegal liquid tag syntax");
      this.tokenizer.skipBlank();
      this.args = this.tokenizer.remaining();
    }
  };
  var FilteredValueToken = class extends Token {
    constructor(initial, filters2, input, begin, end, file) {
      super(TokenKind.FilteredValue, input, begin, end, file);
      this.initial = initial;
      this.filters = filters2;
      this.input = input;
      this.begin = begin;
      this.end = end;
      this.file = file;
    }
  };
  var SimpleEmitter = class {
    constructor() {
      this.buffer = "";
    }
    write(html) {
      this.buffer += stringify(html);
    }
  };
  var StreamedEmitter = class {
    constructor() {
      this.buffer = "";
      this.stream = null;
      throw new Error("streaming not supported in browser");
    }
  };
  var KeepingTypeEmitter = class {
    constructor() {
      this.buffer = "";
    }
    write(html) {
      html = toValue(html);
      if (typeof html !== "string" && this.buffer === "") {
        this.buffer = html;
      } else {
        this.buffer = stringify(this.buffer) + stringify(html);
      }
    }
  };
  var Render = class {
    renderTemplatesToNodeStream(templates, ctx) {
      const emitter = new StreamedEmitter();
      Promise.resolve().then(() => toPromise(this.renderTemplates(templates, ctx, emitter))).then(() => emitter.end(), (err) => emitter.error(err));
      return emitter.stream;
    }
    *renderTemplates(templates, ctx, emitter) {
      if (!emitter) {
        emitter = ctx.opts.keepOutputType ? new KeepingTypeEmitter() : new SimpleEmitter();
      }
      for (const tpl of templates) {
        try {
          const html = yield tpl.render(ctx, emitter);
          html && emitter.write(html);
          if (emitter["break"] || emitter["continue"])
            break;
        } catch (e2) {
          const err = RenderError.is(e2) ? e2 : new RenderError(e2, tpl);
          throw err;
        }
      }
      return emitter.buffer;
    }
  };
  var Expression = class {
    constructor(tokens) {
      this.postfix = [...toPostfix(tokens)];
    }
    *evaluate(ctx, lenient) {
      assert(ctx, "unable to evaluate: context not defined");
      const operands = [];
      for (const token of this.postfix) {
        if (isOperatorToken(token)) {
          const r = operands.pop();
          let result;
          if (operatorTypes[token.operator] === 1) {
            result = yield ctx.opts.operators[token.operator](r, ctx);
          } else {
            const l = operands.pop();
            result = yield ctx.opts.operators[token.operator](l, r, ctx);
          }
          operands.push(result);
        } else {
          operands.push(yield evalToken(token, ctx, lenient && this.postfix.length === 1));
        }
      }
      return operands[0];
    }
    valid() {
      return !!this.postfix.length;
    }
  };
  function* evalToken(token, ctx, lenient = false) {
    if (!token)
      return;
    if ("content" in token)
      return token.content;
    if (isPropertyAccessToken(token))
      return yield evalPropertyAccessToken(token, ctx, lenient);
    if (isRangeToken(token))
      return yield evalRangeToken(token, ctx);
  }
  function* evalPropertyAccessToken(token, ctx, lenient) {
    const props = [];
    const variable = yield evalToken(token.variable, ctx, lenient);
    for (const prop of token.props) {
      props.push(yield evalToken(prop, ctx, false));
    }
    try {
      if (token.variable) {
        return yield ctx._getFromScope(variable, props);
      } else {
        return yield ctx._get(props);
      }
    } catch (e2) {
      if (lenient && e2.name === "InternalUndefinedVariableError")
        return null;
      throw new UndefinedVariableError(e2, token);
    }
  }
  function evalQuotedToken(token) {
    return token.content;
  }
  function* evalRangeToken(token, ctx) {
    const low = yield evalToken(token.lhs, ctx);
    const high = yield evalToken(token.rhs, ctx);
    return range(+low, +high + 1);
  }
  function* toPostfix(tokens) {
    const ops = [];
    for (const token of tokens) {
      if (isOperatorToken(token)) {
        while (ops.length && ops[ops.length - 1].getPrecedence() > token.getPrecedence()) {
          yield ops.pop();
        }
        ops.push(token);
      } else
        yield token;
    }
    while (ops.length) {
      yield ops.pop();
    }
  }
  function isTruthy(val, ctx) {
    return !isFalsy(val, ctx);
  }
  function isFalsy(val, ctx) {
    if (ctx.opts.jsTruthy) {
      return !val;
    } else {
      return val === false || void 0 === val || val === null;
    }
  }
  var defaultOperators = {
    "==": equal,
    "!=": (l, r) => !equal(l, r),
    ">": (l, r) => {
      if (isComparable(l))
        return l.gt(r);
      if (isComparable(r))
        return r.lt(l);
      return toValue(l) > toValue(r);
    },
    "<": (l, r) => {
      if (isComparable(l))
        return l.lt(r);
      if (isComparable(r))
        return r.gt(l);
      return toValue(l) < toValue(r);
    },
    ">=": (l, r) => {
      if (isComparable(l))
        return l.geq(r);
      if (isComparable(r))
        return r.leq(l);
      return toValue(l) >= toValue(r);
    },
    "<=": (l, r) => {
      if (isComparable(l))
        return l.leq(r);
      if (isComparable(r))
        return r.geq(l);
      return toValue(l) <= toValue(r);
    },
    "contains": (l, r) => {
      l = toValue(l);
      if (isArray(l))
        return l.some((i2) => equal(i2, r));
      if (isFunction(l === null || l === void 0 ? void 0 : l.indexOf))
        return l.indexOf(toValue(r)) > -1;
      return false;
    },
    "not": (v, ctx) => isFalsy(toValue(v), ctx),
    "and": (l, r, ctx) => isTruthy(toValue(l), ctx) && isTruthy(toValue(r), ctx),
    "or": (l, r, ctx) => isTruthy(toValue(l), ctx) || isTruthy(toValue(r), ctx)
  };
  function equal(lhs, rhs) {
    if (isComparable(lhs))
      return lhs.equals(rhs);
    if (isComparable(rhs))
      return rhs.equals(lhs);
    lhs = toValue(lhs);
    rhs = toValue(rhs);
    if (isArray(lhs)) {
      return isArray(rhs) && arrayEqual(lhs, rhs);
    }
    return lhs === rhs;
  }
  function arrayEqual(lhs, rhs) {
    if (lhs.length !== rhs.length)
      return false;
    return !lhs.some((value, i2) => !equal(value, rhs[i2]));
  }
  var Node = class {
    constructor(key, value, next, prev) {
      this.key = key;
      this.value = value;
      this.next = next;
      this.prev = prev;
    }
  };
  var LRU = class {
    constructor(limit2, size2 = 0) {
      this.limit = limit2;
      this.size = size2;
      this.cache = {};
      this.head = new Node("HEAD", null, null, null);
      this.tail = new Node("TAIL", null, null, null);
      this.head.next = this.tail;
      this.tail.prev = this.head;
    }
    write(key, value) {
      if (this.cache[key]) {
        this.cache[key].value = value;
      } else {
        const node = new Node(key, value, this.head.next, this.head);
        this.head.next.prev = node;
        this.head.next = node;
        this.cache[key] = node;
        this.size++;
        this.ensureLimit();
      }
    }
    read(key) {
      if (!this.cache[key])
        return;
      const { value } = this.cache[key];
      this.remove(key);
      this.write(key, value);
      return value;
    }
    remove(key) {
      const node = this.cache[key];
      node.prev.next = node.next;
      node.next.prev = node.prev;
      delete this.cache[key];
      this.size--;
    }
    clear() {
      this.head.next = this.tail;
      this.tail.prev = this.head;
      this.size = 0;
      this.cache = {};
    }
    ensureLimit() {
      if (this.size > this.limit)
        this.remove(this.tail.prev.key);
    }
  };
  function domResolve(root, path) {
    const base = document.createElement("base");
    base.href = root;
    const head = document.getElementsByTagName("head")[0];
    head.insertBefore(base, head.firstChild);
    const a3 = document.createElement("a");
    a3.href = path;
    const resolved = a3.href;
    head.removeChild(base);
    return resolved;
  }
  function resolve(root, filepath, ext) {
    if (root.length && last(root) !== "/")
      root += "/";
    const url = domResolve(root, filepath);
    return url.replace(/^(\w+:\/\/[^/]+)(\/[^?]+)/, (str, origin, path) => {
      const last2 = path.split("/").pop();
      if (/\.\w+$/.test(last2))
        return str;
      return origin + path + ext;
    });
  }
  function readFile(url) {
    return __awaiter(this, void 0, void 0, function* () {
      return new Promise((resolve2, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve2(xhr.responseText);
          } else {
            reject(new Error(xhr.statusText));
          }
        };
        xhr.onerror = () => {
          reject(new Error("An error occurred whilst receiving the response."));
        };
        xhr.open("GET", url);
        xhr.send();
      });
    });
  }
  function readFileSync(url) {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url, false);
    xhr.send();
    if (xhr.status < 200 || xhr.status >= 300) {
      throw new Error(xhr.statusText);
    }
    return xhr.responseText;
  }
  function exists(filepath) {
    return __awaiter(this, void 0, void 0, function* () {
      return true;
    });
  }
  function existsSync(filepath) {
    return true;
  }
  function dirname(filepath) {
    return domResolve(filepath, ".");
  }
  var sep = "/";
  var fs = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    resolve,
    readFile,
    readFileSync,
    exists,
    existsSync,
    dirname,
    sep
  });
  function Default(value, defaultValue, ...args) {
    value = toValue(value);
    if (isArray(value) || isString(value))
      return value.length ? value : defaultValue;
    if (value === false && new Map(args).get("allow_false"))
      return false;
    return isFalsy(value, this.context) ? defaultValue : value;
  }
  function json(value, space = 0) {
    return JSON.stringify(value, null, space);
  }
  var raw = {
    raw: true,
    handler: identify
  };
  var escapeMap = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&#34;",
    "'": "&#39;"
  };
  var unescapeMap = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&#34;": '"',
    "&#39;": "'"
  };
  function escape(str) {
    return stringify(str).replace(/&|<|>|"|'/g, (m3) => escapeMap[m3]);
  }
  function unescape(str) {
    return stringify(str).replace(/&(amp|lt|gt|#34|#39);/g, (m3) => unescapeMap[m3]);
  }
  function escape_once(str) {
    return escape(unescape(stringify(str)));
  }
  function newline_to_br(v) {
    return stringify(v).replace(/\r?\n/gm, "<br />\n");
  }
  function strip_html(v) {
    return stringify(v).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<.*?>|<!--[\s\S]*?-->/g, "");
  }
  var htmlFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    escape,
    escape_once,
    newline_to_br,
    strip_html
  });
  var defaultOptions2 = {
    root: ["."],
    layouts: ["."],
    partials: ["."],
    relativeReference: true,
    jekyllInclude: false,
    cache: void 0,
    extname: "",
    fs,
    dynamicPartials: true,
    jsTruthy: false,
    dateFormat: "%A, %B %-e, %Y at %-l:%M %P %z",
    trimTagRight: false,
    trimTagLeft: false,
    trimOutputRight: false,
    trimOutputLeft: false,
    greedy: true,
    tagDelimiterLeft: "{%",
    tagDelimiterRight: "%}",
    outputDelimiterLeft: "{{",
    outputDelimiterRight: "}}",
    preserveTimezones: false,
    strictFilters: false,
    strictVariables: false,
    ownPropertyOnly: true,
    lenientIf: false,
    globals: {},
    keepOutputType: false,
    operators: defaultOperators
  };
  function normalize(options2) {
    if (options2.hasOwnProperty("root")) {
      if (!options2.hasOwnProperty("partials"))
        options2.partials = options2.root;
      if (!options2.hasOwnProperty("layouts"))
        options2.layouts = options2.root;
    }
    if (options2.hasOwnProperty("cache")) {
      let cache;
      if (typeof options2.cache === "number")
        cache = options2.cache > 0 ? new LRU(options2.cache) : void 0;
      else if (typeof options2.cache === "object")
        cache = options2.cache;
      else
        cache = options2.cache ? new LRU(1024) : void 0;
      options2.cache = cache;
    }
    options2 = Object.assign(Object.assign(Object.assign({}, defaultOptions2), options2.jekyllInclude ? { dynamicPartials: false } : {}), options2);
    if ((!options2.fs.dirname || !options2.fs.sep) && options2.relativeReference) {
      console.warn("[LiquidJS] `fs.dirname` and `fs.sep` are required for relativeReference, set relativeReference to `false` to suppress this warning");
      options2.relativeReference = false;
    }
    options2.root = normalizeDirectoryList(options2.root);
    options2.partials = normalizeDirectoryList(options2.partials);
    options2.layouts = normalizeDirectoryList(options2.layouts);
    options2.outputEscape = options2.outputEscape && getOutputEscapeFunction(options2.outputEscape);
    return options2;
  }
  function getOutputEscapeFunction(nameOrFunction) {
    if (nameOrFunction === "escape")
      return escape;
    if (nameOrFunction === "json")
      return json;
    assert(isFunction(nameOrFunction), "`outputEscape` need to be of type string or function");
    return nameOrFunction;
  }
  function normalizeDirectoryList(value) {
    let list = [];
    if (isArray(value))
      list = value;
    if (isString(value))
      list = [value];
    return list;
  }
  function whiteSpaceCtrl(tokens, options2) {
    let inRaw = false;
    for (let i2 = 0; i2 < tokens.length; i2++) {
      const token = tokens[i2];
      if (!isDelimitedToken(token))
        continue;
      if (!inRaw && token.trimLeft) {
        trimLeft(tokens[i2 - 1], options2.greedy);
      }
      if (isTagToken(token)) {
        if (token.name === "raw")
          inRaw = true;
        else if (token.name === "endraw")
          inRaw = false;
      }
      if (!inRaw && token.trimRight) {
        trimRight(tokens[i2 + 1], options2.greedy);
      }
    }
  }
  function trimLeft(token, greedy) {
    if (!token || !isHTMLToken(token))
      return;
    const mask = greedy ? BLANK : INLINE_BLANK;
    while (TYPES[token.input.charCodeAt(token.end - 1 - token.trimRight)] & mask)
      token.trimRight++;
  }
  function trimRight(token, greedy) {
    if (!token || !isHTMLToken(token))
      return;
    const mask = greedy ? BLANK : INLINE_BLANK;
    while (TYPES[token.input.charCodeAt(token.begin + token.trimLeft)] & mask)
      token.trimLeft++;
    if (token.input.charAt(token.begin + token.trimLeft) === "\n")
      token.trimLeft++;
  }
  var Tokenizer = class {
    constructor(input, operators = defaultOptions2.operators, file, range2) {
      this.input = input;
      this.file = file;
      this.range = range2;
      this.rawBeginAt = -1;
      this.p = range2 ? range2[0] : 0;
      this.N = range2 ? range2[1] : input.length;
      this.opTrie = createTrie(operators);
      this.literalTrie = createTrie(literalValues);
    }
    readExpression() {
      return new Expression(this.readExpressionTokens());
    }
    *readExpressionTokens() {
      while (this.p < this.N) {
        const operator = this.readOperator();
        if (operator) {
          yield operator;
          continue;
        }
        const operand = this.readValue();
        if (operand) {
          yield operand;
          continue;
        }
        return;
      }
    }
    readOperator() {
      this.skipBlank();
      const end = this.matchTrie(this.opTrie);
      if (end === -1)
        return;
      return new OperatorToken(this.input, this.p, this.p = end, this.file);
    }
    matchTrie(trie) {
      let node = trie;
      let i2 = this.p;
      let info;
      while (node[this.input[i2]] && i2 < this.N) {
        node = node[this.input[i2++]];
        if (node["end"])
          info = node;
      }
      if (!info)
        return -1;
      if (info["needBoundary"] && isWord(this.peek(i2 - this.p)))
        return -1;
      return i2;
    }
    readFilteredValue() {
      const begin = this.p;
      const initial = this.readExpression();
      this.assert(initial.valid(), `invalid value expression: ${this.snapshot()}`);
      const filters2 = this.readFilters();
      return new FilteredValueToken(initial, filters2, this.input, begin, this.p, this.file);
    }
    readFilters() {
      const filters2 = [];
      while (true) {
        const filter = this.readFilter();
        if (!filter)
          return filters2;
        filters2.push(filter);
      }
    }
    readFilter() {
      this.skipBlank();
      if (this.end())
        return null;
      this.assert(this.peek() === "|", `expected "|" before filter`);
      this.p++;
      const begin = this.p;
      const name = this.readIdentifier();
      if (!name.size()) {
        this.assert(this.end(), `expected filter name`);
        return null;
      }
      const args = [];
      this.skipBlank();
      if (this.peek() === ":") {
        do {
          ++this.p;
          const arg = this.readFilterArg();
          arg && args.push(arg);
          this.skipBlank();
          this.assert(this.end() || this.peek() === "," || this.peek() === "|", () => `unexpected character ${this.snapshot()}`);
        } while (this.peek() === ",");
      } else if (this.peek() === "|" || this.end())
        ;
      else {
        throw this.error('expected ":" after filter name');
      }
      return new FilterToken(name.getText(), args, this.input, begin, this.p, this.file);
    }
    readFilterArg() {
      const key = this.readValue();
      if (!key)
        return;
      this.skipBlank();
      if (this.peek() !== ":")
        return key;
      ++this.p;
      const value = this.readValue();
      return [key.getText(), value];
    }
    readTopLevelTokens(options2 = defaultOptions2) {
      const tokens = [];
      while (this.p < this.N) {
        const token = this.readTopLevelToken(options2);
        tokens.push(token);
      }
      whiteSpaceCtrl(tokens, options2);
      return tokens;
    }
    readTopLevelToken(options2) {
      const { tagDelimiterLeft, outputDelimiterLeft } = options2;
      if (this.rawBeginAt > -1)
        return this.readEndrawOrRawContent(options2);
      if (this.match(tagDelimiterLeft))
        return this.readTagToken(options2);
      if (this.match(outputDelimiterLeft))
        return this.readOutputToken(options2);
      return this.readHTMLToken([tagDelimiterLeft, outputDelimiterLeft]);
    }
    readHTMLToken(stopStrings) {
      const begin = this.p;
      while (this.p < this.N) {
        if (stopStrings.some((str) => this.match(str)))
          break;
        ++this.p;
      }
      return new HTMLToken(this.input, begin, this.p, this.file);
    }
    readTagToken(options2 = defaultOptions2) {
      const { file, input } = this;
      const begin = this.p;
      if (this.readToDelimiter(options2.tagDelimiterRight) === -1) {
        throw this.error(`tag ${this.snapshot(begin)} not closed`, begin);
      }
      const token = new TagToken(input, begin, this.p, options2, file);
      if (token.name === "raw")
        this.rawBeginAt = begin;
      return token;
    }
    readToDelimiter(delimiter, respectQuoted = false) {
      this.skipBlank();
      while (this.p < this.N) {
        if (respectQuoted && this.peekType() & QUOTE) {
          this.readQuoted();
          continue;
        }
        ++this.p;
        if (this.rmatch(delimiter))
          return this.p;
      }
      return -1;
    }
    readOutputToken(options2 = defaultOptions2) {
      const { file, input } = this;
      const { outputDelimiterRight } = options2;
      const begin = this.p;
      if (this.readToDelimiter(outputDelimiterRight, true) === -1) {
        throw this.error(`output ${this.snapshot(begin)} not closed`, begin);
      }
      return new OutputToken(input, begin, this.p, options2, file);
    }
    readEndrawOrRawContent(options2) {
      const { tagDelimiterLeft, tagDelimiterRight } = options2;
      const begin = this.p;
      let leftPos = this.readTo(tagDelimiterLeft) - tagDelimiterLeft.length;
      while (this.p < this.N) {
        if (this.readIdentifier().getText() !== "endraw") {
          leftPos = this.readTo(tagDelimiterLeft) - tagDelimiterLeft.length;
          continue;
        }
        while (this.p <= this.N) {
          if (this.rmatch(tagDelimiterRight)) {
            const end = this.p;
            if (begin === leftPos) {
              this.rawBeginAt = -1;
              return new TagToken(this.input, begin, end, options2, this.file);
            } else {
              this.p = leftPos;
              return new HTMLToken(this.input, begin, leftPos, this.file);
            }
          }
          if (this.rmatch(tagDelimiterLeft))
            break;
          this.p++;
        }
      }
      throw this.error(`raw ${this.snapshot(this.rawBeginAt)} not closed`, begin);
    }
    readLiquidTagTokens(options2 = defaultOptions2) {
      const tokens = [];
      while (this.p < this.N) {
        const token = this.readLiquidTagToken(options2);
        token && tokens.push(token);
      }
      return tokens;
    }
    readLiquidTagToken(options2) {
      this.skipBlank();
      if (this.end())
        return;
      const begin = this.p;
      this.readToDelimiter("\n");
      const end = this.p;
      return new LiquidTagToken(this.input, begin, end, options2, this.file);
    }
    error(msg, pos = this.p) {
      return new TokenizationError(msg, new IdentifierToken(this.input, pos, this.N, this.file));
    }
    assert(pred, msg, pos) {
      if (!pred)
        throw this.error(typeof msg === "function" ? msg() : msg, pos);
    }
    snapshot(begin = this.p) {
      return JSON.stringify(ellipsis(this.input.slice(begin, this.N), 32));
    }
    /**
     * @deprecated use #readIdentifier instead
     */
    readWord() {
      return this.readIdentifier();
    }
    readIdentifier() {
      this.skipBlank();
      const begin = this.p;
      while (!this.end() && isWord(this.peek()))
        ++this.p;
      return new IdentifierToken(this.input, begin, this.p, this.file);
    }
    readTagName() {
      this.skipBlank();
      if (this.input[this.p] === "#")
        return this.input.slice(this.p, ++this.p);
      return this.readIdentifier().getText();
    }
    readHashes(jekyllStyle) {
      const hashes = [];
      while (true) {
        const hash = this.readHash(jekyllStyle);
        if (!hash)
          return hashes;
        hashes.push(hash);
      }
    }
    readHash(jekyllStyle) {
      this.skipBlank();
      if (this.peek() === ",")
        ++this.p;
      const begin = this.p;
      const name = this.readIdentifier();
      if (!name.size())
        return;
      let value;
      this.skipBlank();
      const sep2 = jekyllStyle ? "=" : ":";
      if (this.peek() === sep2) {
        ++this.p;
        value = this.readValue();
      }
      return new HashToken(this.input, begin, this.p, name, value, this.file);
    }
    remaining() {
      return this.input.slice(this.p, this.N);
    }
    advance(step = 1) {
      this.p += step;
    }
    end() {
      return this.p >= this.N;
    }
    readTo(end) {
      while (this.p < this.N) {
        ++this.p;
        if (this.rmatch(end))
          return this.p;
      }
      return -1;
    }
    readValue() {
      this.skipBlank();
      const begin = this.p;
      const variable = this.readLiteral() || this.readQuoted() || this.readRange() || this.readNumber();
      const props = [];
      while (true) {
        if (this.peek() === "[") {
          this.p++;
          const prop = this.readValue() || new IdentifierToken(this.input, this.p, this.p, this.file);
          this.assert(this.readTo("]") !== -1, "[ not closed");
          props.push(prop);
          continue;
        }
        if (!variable && !props.length) {
          const prop = this.readIdentifier();
          if (prop.size()) {
            props.push(prop);
            continue;
          }
        }
        if (this.peek() === "." && this.peek(1) !== ".") {
          this.p++;
          const prop = this.readIdentifier();
          if (!prop.size())
            break;
          props.push(prop);
          continue;
        }
        break;
      }
      if (!props.length)
        return variable;
      return new PropertyAccessToken(variable, props, this.input, begin, this.p);
    }
    readNumber() {
      this.skipBlank();
      let decimalFound = false;
      let digitFound = false;
      let n = 0;
      if (this.peekType() & SIGN)
        n++;
      while (this.p + n <= this.N) {
        if (this.peekType(n) & NUMBER) {
          digitFound = true;
          n++;
        } else if (this.peek(n) === "." && this.peek(n + 1) !== ".") {
          if (decimalFound || !digitFound)
            return;
          decimalFound = true;
          n++;
        } else
          break;
      }
      if (digitFound && !isWord(this.peek(n))) {
        const num = new NumberToken(this.input, this.p, this.p + n, this.file);
        this.advance(n);
        return num;
      }
    }
    readLiteral() {
      this.skipBlank();
      const end = this.matchTrie(this.literalTrie);
      if (end === -1)
        return;
      const literal = new LiteralToken(this.input, this.p, end, this.file);
      this.p = end;
      return literal;
    }
    readRange() {
      this.skipBlank();
      const begin = this.p;
      if (this.peek() !== "(")
        return;
      ++this.p;
      const lhs = this.readValueOrThrow();
      this.p += 2;
      const rhs = this.readValueOrThrow();
      ++this.p;
      return new RangeToken(this.input, begin, this.p, lhs, rhs, this.file);
    }
    readValueOrThrow() {
      const value = this.readValue();
      this.assert(value, () => `unexpected token ${this.snapshot()}, value expected`);
      return value;
    }
    readQuoted() {
      this.skipBlank();
      const begin = this.p;
      if (!(this.peekType() & QUOTE))
        return;
      ++this.p;
      let escaped = false;
      while (this.p < this.N) {
        ++this.p;
        if (this.input[this.p - 1] === this.input[begin] && !escaped)
          break;
        if (escaped)
          escaped = false;
        else if (this.input[this.p - 1] === "\\")
          escaped = true;
      }
      return new QuotedToken(this.input, begin, this.p, this.file);
    }
    *readFileNameTemplate(options2) {
      const { outputDelimiterLeft } = options2;
      const htmlStopStrings = [",", " ", outputDelimiterLeft];
      const htmlStopStringSet = new Set(htmlStopStrings);
      while (this.p < this.N && !htmlStopStringSet.has(this.peek())) {
        yield this.match(outputDelimiterLeft) ? this.readOutputToken(options2) : this.readHTMLToken(htmlStopStrings);
      }
    }
    match(word) {
      for (let i2 = 0; i2 < word.length; i2++) {
        if (word[i2] !== this.input[this.p + i2])
          return false;
      }
      return true;
    }
    rmatch(pattern) {
      for (let i2 = 0; i2 < pattern.length; i2++) {
        if (pattern[pattern.length - 1 - i2] !== this.input[this.p - 1 - i2])
          return false;
      }
      return true;
    }
    peekType(n = 0) {
      return this.p + n >= this.N ? 0 : TYPES[this.input.charCodeAt(this.p + n)];
    }
    peek(n = 0) {
      return this.p + n >= this.N ? "" : this.input[this.p + n];
    }
    skipBlank() {
      while (this.peekType() & BLANK)
        ++this.p;
    }
  };
  var ParseStream = class {
    constructor(tokens, parseToken) {
      this.handlers = {};
      this.stopRequested = false;
      this.tokens = tokens;
      this.parseToken = parseToken;
    }
    on(name, cb) {
      this.handlers[name] = cb;
      return this;
    }
    trigger(event, arg) {
      const h3 = this.handlers[event];
      return h3 ? (h3.call(this, arg), true) : false;
    }
    start() {
      this.trigger("start");
      let token;
      while (!this.stopRequested && (token = this.tokens.shift())) {
        if (this.trigger("token", token))
          continue;
        if (isTagToken(token) && this.trigger(`tag:${token.name}`, token)) {
          continue;
        }
        const template = this.parseToken(token, this.tokens);
        this.trigger("template", template);
      }
      if (!this.stopRequested)
        this.trigger("end");
      return this;
    }
    stop() {
      this.stopRequested = true;
      return this;
    }
  };
  var TemplateImpl = class {
    constructor(token) {
      this.token = token;
    }
  };
  var Tag = class extends TemplateImpl {
    constructor(token, remainTokens, liquid) {
      super(token);
      this.name = token.name;
      this.liquid = liquid;
      this.tokenizer = token.tokenizer;
    }
  };
  var Hash = class {
    constructor(markup, jekyllStyle) {
      this.hash = {};
      const tokenizer = new Tokenizer(markup, {});
      for (const hash of tokenizer.readHashes(jekyllStyle)) {
        this.hash[hash.name.content] = hash.value;
      }
    }
    *render(ctx) {
      const hash = {};
      for (const key of Object.keys(this.hash)) {
        hash[key] = this.hash[key] === void 0 ? true : yield evalToken(this.hash[key], ctx);
      }
      return hash;
    }
  };
  function createTagClass(options2) {
    return class extends Tag {
      constructor(token, tokens, liquid) {
        super(token, tokens, liquid);
        if (isFunction(options2.parse)) {
          options2.parse.call(this, token, tokens);
        }
      }
      *render(ctx, emitter) {
        const hash = yield new Hash(this.token.args).render(ctx);
        return yield options2.render.call(this, ctx, emitter, hash);
      }
    };
  }
  function isKeyValuePair(arr) {
    return isArray(arr);
  }
  var Filter = class {
    constructor(name, options2, args, liquid) {
      this.name = name;
      this.handler = isFunction(options2) ? options2 : isFunction(options2 === null || options2 === void 0 ? void 0 : options2.handler) ? options2.handler : identify;
      this.raw = !isFunction(options2) && !!(options2 === null || options2 === void 0 ? void 0 : options2.raw);
      this.args = args;
      this.liquid = liquid;
    }
    *render(value, context) {
      const argv = [];
      for (const arg of this.args) {
        if (isKeyValuePair(arg))
          argv.push([arg[0], yield evalToken(arg[1], context)]);
        else
          argv.push(yield evalToken(arg, context));
      }
      return yield this.handler.apply({ context, liquid: this.liquid }, [value, ...argv]);
    }
  };
  var Value = class {
    /**
     * @param str the value to be valuated, eg.: "foobar" | truncate: 3
     */
    constructor(input, liquid) {
      this.filters = [];
      const token = typeof input === "string" ? new Tokenizer(input, liquid.options.operators).readFilteredValue() : input;
      this.initial = token.initial;
      this.filters = token.filters.map(({ name, args }) => new Filter(name, this.getFilter(liquid, name), args, liquid));
    }
    *value(ctx, lenient) {
      lenient = lenient || ctx.opts.lenientIf && this.filters.length > 0 && this.filters[0].name === "default";
      let val = yield this.initial.evaluate(ctx, lenient);
      for (const filter of this.filters) {
        val = yield filter.render(val, ctx);
      }
      return val;
    }
    getFilter(liquid, name) {
      const impl = liquid.filters[name];
      assert(impl || !liquid.options.strictFilters, () => `undefined filter: ${name}`);
      return impl;
    }
  };
  var Output = class extends TemplateImpl {
    constructor(token, liquid) {
      var _a;
      super(token);
      const tokenizer = new Tokenizer(token.input, liquid.options.operators, token.file, token.contentRange);
      this.value = new Value(tokenizer.readFilteredValue(), liquid);
      const filters2 = this.value.filters;
      const outputEscape = liquid.options.outputEscape;
      if (!((_a = filters2[filters2.length - 1]) === null || _a === void 0 ? void 0 : _a.raw) && outputEscape) {
        filters2.push(new Filter(toString.call(outputEscape), outputEscape, [], liquid));
      }
    }
    *render(ctx, emitter) {
      const val = yield this.value.value(ctx, false);
      emitter.write(val);
    }
  };
  var HTML = class extends TemplateImpl {
    constructor(token) {
      super(token);
      this.str = token.getContent();
    }
    *render(ctx, emitter) {
      emitter.write(this.str);
    }
  };
  var LookupType;
  (function(LookupType2) {
    LookupType2["Partials"] = "partials";
    LookupType2["Layouts"] = "layouts";
    LookupType2["Root"] = "root";
  })(LookupType || (LookupType = {}));
  var Loader = class {
    constructor(options2) {
      this.options = options2;
      if (options2.relativeReference) {
        const sep2 = options2.fs.sep;
        assert(sep2, "`fs.sep` is required for relative reference");
        const rRelativePath = new RegExp(["." + sep2, ".." + sep2, "./", "../"].map((prefix) => escapeRegex(prefix)).join("|"));
        this.shouldLoadRelative = (referencedFile) => rRelativePath.test(referencedFile);
      } else {
        this.shouldLoadRelative = (referencedFile) => false;
      }
      this.contains = this.options.fs.contains || (() => true);
    }
    *lookup(file, type, sync, currentFile) {
      const { fs: fs2 } = this.options;
      const dirs = this.options[type];
      for (const filepath of this.candidates(file, dirs, currentFile, type !== LookupType.Root)) {
        if (sync ? fs2.existsSync(filepath) : yield fs2.exists(filepath))
          return filepath;
      }
      throw this.lookupError(file, dirs);
    }
    *candidates(file, dirs, currentFile, enforceRoot) {
      const { fs: fs2, extname } = this.options;
      if (this.shouldLoadRelative(file) && currentFile) {
        const referenced = fs2.resolve(this.dirname(currentFile), file, extname);
        for (const dir of dirs) {
          if (!enforceRoot || this.contains(dir, referenced)) {
            yield referenced;
            break;
          }
        }
      }
      for (const dir of dirs) {
        const referenced = fs2.resolve(dir, file, extname);
        if (!enforceRoot || this.contains(dir, referenced)) {
          yield referenced;
        }
      }
      if (fs2.fallback !== void 0) {
        const filepath = fs2.fallback(file);
        if (filepath !== void 0)
          yield filepath;
      }
    }
    dirname(path) {
      const fs2 = this.options.fs;
      assert(fs2.dirname, "`fs.dirname` is required for relative reference");
      return fs2.dirname(path);
    }
    lookupError(file, roots) {
      const err = new Error("ENOENT");
      err.message = `ENOENT: Failed to lookup "${file}" in "${roots}"`;
      err.code = "ENOENT";
      return err;
    }
  };
  var Parser = class {
    constructor(liquid) {
      this.liquid = liquid;
      this.cache = this.liquid.options.cache;
      this.fs = this.liquid.options.fs;
      this.parseFile = this.cache ? this._parseFileCached : this._parseFile;
      this.loader = new Loader(this.liquid.options);
    }
    parse(html, filepath) {
      const tokenizer = new Tokenizer(html, this.liquid.options.operators, filepath);
      const tokens = tokenizer.readTopLevelTokens(this.liquid.options);
      return this.parseTokens(tokens);
    }
    parseTokens(tokens) {
      let token;
      const templates = [];
      while (token = tokens.shift()) {
        templates.push(this.parseToken(token, tokens));
      }
      return templates;
    }
    parseToken(token, remainTokens) {
      try {
        if (isTagToken(token)) {
          const TagClass = this.liquid.tags[token.name];
          assert(TagClass, `tag "${token.name}" not found`);
          return new TagClass(token, remainTokens, this.liquid);
        }
        if (isOutputToken(token)) {
          return new Output(token, this.liquid);
        }
        return new HTML(token);
      } catch (e2) {
        if (LiquidError.is(e2))
          throw e2;
        throw new ParseError(e2, token);
      }
    }
    parseStream(tokens) {
      return new ParseStream(tokens, (token, tokens2) => this.parseToken(token, tokens2));
    }
    *_parseFileCached(file, sync, type = LookupType.Root, currentFile) {
      const cache = this.cache;
      const key = this.loader.shouldLoadRelative(file) ? currentFile + "," + file : type + ":" + file;
      const tpls = yield cache.read(key);
      if (tpls)
        return tpls;
      const task = this._parseFile(file, sync, type, currentFile);
      const taskOrTpl = sync ? yield task : toPromise(task);
      cache.write(key, taskOrTpl);
      try {
        return yield taskOrTpl;
      } catch (err) {
        cache.remove(key);
        throw err;
      }
    }
    *_parseFile(file, sync, type = LookupType.Root, currentFile) {
      const filepath = yield this.loader.lookup(file, type, sync, currentFile);
      return this.liquid.parse(sync ? this.fs.readFileSync(filepath) : yield this.fs.readFile(filepath), filepath);
    }
  };
  var TokenKind;
  (function(TokenKind2) {
    TokenKind2[TokenKind2["Number"] = 1] = "Number";
    TokenKind2[TokenKind2["Literal"] = 2] = "Literal";
    TokenKind2[TokenKind2["Tag"] = 4] = "Tag";
    TokenKind2[TokenKind2["Output"] = 8] = "Output";
    TokenKind2[TokenKind2["HTML"] = 16] = "HTML";
    TokenKind2[TokenKind2["Filter"] = 32] = "Filter";
    TokenKind2[TokenKind2["Hash"] = 64] = "Hash";
    TokenKind2[TokenKind2["PropertyAccess"] = 128] = "PropertyAccess";
    TokenKind2[TokenKind2["Word"] = 256] = "Word";
    TokenKind2[TokenKind2["Range"] = 512] = "Range";
    TokenKind2[TokenKind2["Quoted"] = 1024] = "Quoted";
    TokenKind2[TokenKind2["Operator"] = 2048] = "Operator";
    TokenKind2[TokenKind2["FilteredValue"] = 4096] = "FilteredValue";
    TokenKind2[TokenKind2["Delimited"] = 12] = "Delimited";
  })(TokenKind || (TokenKind = {}));
  function isDelimitedToken(val) {
    return !!(getKind(val) & TokenKind.Delimited);
  }
  function isOperatorToken(val) {
    return getKind(val) === TokenKind.Operator;
  }
  function isHTMLToken(val) {
    return getKind(val) === TokenKind.HTML;
  }
  function isOutputToken(val) {
    return getKind(val) === TokenKind.Output;
  }
  function isTagToken(val) {
    return getKind(val) === TokenKind.Tag;
  }
  function isQuotedToken(val) {
    return getKind(val) === TokenKind.Quoted;
  }
  function isPropertyAccessToken(val) {
    return getKind(val) === TokenKind.PropertyAccess;
  }
  function isRangeToken(val) {
    return getKind(val) === TokenKind.Range;
  }
  function getKind(val) {
    return val ? val.kind : -1;
  }
  var Context = class {
    constructor(env = {}, opts = defaultOptions2, renderOptions = {}) {
      var _a, _b, _c;
      this.scopes = [{}];
      this.registers = {};
      this.sync = !!renderOptions.sync;
      this.opts = opts;
      this.globals = (_a = renderOptions.globals) !== null && _a !== void 0 ? _a : opts.globals;
      this.environments = env;
      this.strictVariables = (_b = renderOptions.strictVariables) !== null && _b !== void 0 ? _b : this.opts.strictVariables;
      this.ownPropertyOnly = (_c = renderOptions.ownPropertyOnly) !== null && _c !== void 0 ? _c : opts.ownPropertyOnly;
    }
    getRegister(key) {
      return this.registers[key] = this.registers[key] || {};
    }
    setRegister(key, value) {
      return this.registers[key] = value;
    }
    saveRegister(...keys) {
      return keys.map((key) => [key, this.getRegister(key)]);
    }
    restoreRegister(keyValues) {
      return keyValues.forEach(([key, value]) => this.setRegister(key, value));
    }
    getAll() {
      return [this.globals, this.environments, ...this.scopes].reduce((ctx, val) => __assign(ctx, val), {});
    }
    /**
     * @deprecated use `_get()` or `getSync()` instead
     */
    get(paths) {
      return this.getSync(paths);
    }
    getSync(paths) {
      return toValueSync(this._get(paths));
    }
    *_get(paths) {
      const scope = this.findScope(paths[0]);
      return yield this._getFromScope(scope, paths);
    }
    /**
     * @deprecated use `_get()` instead
     */
    getFromScope(scope, paths) {
      return toValueSync(this._getFromScope(scope, paths));
    }
    *_getFromScope(scope, paths, strictVariables = this.strictVariables) {
      if (isString(paths))
        paths = paths.split(".");
      for (let i2 = 0; i2 < paths.length; i2++) {
        scope = yield readProperty(scope, paths[i2], this.ownPropertyOnly);
        if (strictVariables && isUndefined(scope)) {
          throw new InternalUndefinedVariableError(paths.slice(0, i2 + 1).join("."));
        }
      }
      return scope;
    }
    push(ctx) {
      return this.scopes.push(ctx);
    }
    pop() {
      return this.scopes.pop();
    }
    bottom() {
      return this.scopes[0];
    }
    findScope(key) {
      for (let i2 = this.scopes.length - 1; i2 >= 0; i2--) {
        const candidate = this.scopes[i2];
        if (key in candidate)
          return candidate;
      }
      if (key in this.environments)
        return this.environments;
      return this.globals;
    }
  };
  function readProperty(obj, key, ownPropertyOnly) {
    obj = toLiquid(obj);
    if (isNil(obj))
      return obj;
    if (isArray(obj) && key < 0)
      return obj[obj.length + +key];
    const value = readJSProperty(obj, key, ownPropertyOnly);
    if (value === void 0 && obj instanceof Drop)
      return obj.liquidMethodMissing(key);
    if (isFunction(value))
      return value.call(obj);
    if (key === "size")
      return readSize(obj);
    else if (key === "first")
      return readFirst(obj);
    else if (key === "last")
      return readLast(obj);
    return value;
  }
  function readJSProperty(obj, key, ownPropertyOnly) {
    if (ownPropertyOnly && !Object.hasOwnProperty.call(obj, key) && !(obj instanceof Drop))
      return void 0;
    return obj[key];
  }
  function readFirst(obj) {
    if (isArray(obj))
      return obj[0];
    return obj["first"];
  }
  function readLast(obj) {
    if (isArray(obj))
      return obj[obj.length - 1];
    return obj["last"];
  }
  function readSize(obj) {
    if (obj.hasOwnProperty("size") || obj["size"] !== void 0)
      return obj["size"];
    if (isArray(obj) || isString(obj))
      return obj.length;
    if (typeof obj === "object")
      return Object.keys(obj).length;
  }
  var BlockMode;
  (function(BlockMode2) {
    BlockMode2[BlockMode2["OUTPUT"] = 0] = "OUTPUT";
    BlockMode2[BlockMode2["STORE"] = 1] = "STORE";
  })(BlockMode || (BlockMode = {}));
  var abs = argumentsToValue(Math.abs);
  var at_least = argumentsToValue(Math.max);
  var at_most = argumentsToValue(Math.min);
  var ceil = argumentsToValue(Math.ceil);
  var divided_by = argumentsToValue((dividend, divisor, integerArithmetic = false) => integerArithmetic ? Math.floor(dividend / divisor) : dividend / divisor);
  var floor = argumentsToValue(Math.floor);
  var minus = argumentsToValue((v, arg) => v - arg);
  var modulo = argumentsToValue((v, arg) => v % arg);
  var times = argumentsToValue((v, arg) => v * arg);
  function round(v, arg = 0) {
    v = toValue(v);
    arg = toValue(arg);
    const amp = Math.pow(10, arg);
    return Math.round(v * amp) / amp;
  }
  function plus(v, arg) {
    v = toValue(v);
    arg = toValue(arg);
    return Number(v) + Number(arg);
  }
  var mathFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    abs,
    at_least,
    at_most,
    ceil,
    divided_by,
    floor,
    minus,
    modulo,
    times,
    round,
    plus
  });
  var url_decode = (x2) => stringify(x2).split("+").map(decodeURIComponent).join(" ");
  var url_encode = (x2) => stringify(x2).split(" ").map(encodeURIComponent).join("+");
  var urlFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    url_decode,
    url_encode
  });
  var join = argumentsToValue((v, arg) => toArray(v).join(arg === void 0 ? " " : arg));
  var last$1 = argumentsToValue((v) => isArray(v) ? last(v) : "");
  var first = argumentsToValue((v) => isArray(v) ? v[0] : "");
  var reverse = argumentsToValue((v) => [...toArray(v)].reverse());
  function* sort(arr, property) {
    const values = [];
    for (const item of toArray(toValue(arr))) {
      values.push([
        item,
        property ? yield this.context._getFromScope(item, stringify(property).split("."), false) : item
      ]);
    }
    return values.sort((lhs, rhs) => {
      const lvalue = lhs[1];
      const rvalue = rhs[1];
      return lvalue < rvalue ? -1 : lvalue > rvalue ? 1 : 0;
    }).map((tuple) => tuple[0]);
  }
  function sort_natural(input, property) {
    input = toValue(input);
    const propertyString = stringify(property);
    const compare = property === void 0 ? caseInsensitiveCompare : (lhs, rhs) => caseInsensitiveCompare(lhs[propertyString], rhs[propertyString]);
    return [...toArray(input)].sort(compare);
  }
  var size = (v) => v && v.length || 0;
  function* map(arr, property) {
    const results = [];
    for (const item of toArray(toValue(arr))) {
      results.push(yield this.context._getFromScope(item, stringify(property), false));
    }
    return results;
  }
  function* sum(arr, property) {
    let sum2 = 0;
    for (const item of toArray(toValue(arr))) {
      const data = Number(property ? yield this.context._getFromScope(item, stringify(property), false) : item);
      sum2 += Number.isNaN(data) ? 0 : data;
    }
    return sum2;
  }
  function compact(arr) {
    arr = toValue(arr);
    return toArray(arr).filter((x2) => !isNil(toValue(x2)));
  }
  function concat(v, arg = []) {
    v = toValue(v);
    arg = toArray(arg).map((v2) => toValue(v2));
    return toArray(v).concat(arg);
  }
  function push(v, arg) {
    return concat(v, [arg]);
  }
  function slice(v, begin, length = 1) {
    v = toValue(v);
    if (isNil(v))
      return [];
    if (!isArray(v))
      v = stringify(v);
    begin = begin < 0 ? v.length + begin : begin;
    return v.slice(begin, begin + length);
  }
  function* where(arr, property, expected) {
    const values = [];
    arr = toArray(toValue(arr));
    for (const item of arr) {
      values.push(yield this.context._getFromScope(item, stringify(property).split("."), false));
    }
    return arr.filter((_, i2) => {
      if (expected === void 0)
        return isTruthy(values[i2], this.context);
      if (isComparable(expected))
        return expected.equals(values[i2]);
      return values[i2] === expected;
    });
  }
  function uniq(arr) {
    arr = toValue(arr);
    const u2 = {};
    return (arr || []).filter((val) => {
      if (hasOwnProperty.call(u2, String(val)))
        return false;
      u2[String(val)] = true;
      return true;
    });
  }
  function sample(v, count = 1) {
    v = toValue(v);
    if (isNil(v))
      return [];
    if (!isArray(v))
      v = stringify(v);
    const shuffled = [...v].sort(() => Math.random() - 0.5);
    if (count === 1)
      return shuffled[0];
    return shuffled.slice(0, count);
  }
  var arrayFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    join,
    last: last$1,
    first,
    reverse,
    sort,
    sort_natural,
    size,
    map,
    sum,
    compact,
    concat,
    push,
    slice,
    where,
    uniq,
    sample
  });
  function date(v, format3, timezoneOffset) {
    const opts = this.context.opts;
    let date2;
    v = toValue(v);
    format3 = toValue(format3);
    if (isNil(format3))
      format3 = opts.dateFormat;
    else
      format3 = stringify(format3);
    if (v === "now" || v === "today") {
      date2 = /* @__PURE__ */ new Date();
    } else if (isNumber(v)) {
      date2 = new Date(v * 1e3);
    } else if (isString(v)) {
      if (/^\d+$/.test(v)) {
        date2 = new Date(+v * 1e3);
      } else if (opts.preserveTimezones) {
        date2 = TimezoneDate.createDateFixedToTimezone(v);
      } else {
        date2 = new Date(v);
      }
    } else {
      date2 = v;
    }
    if (!isValidDate(date2))
      return v;
    if (timezoneOffset !== void 0) {
      date2 = new TimezoneDate(date2, parseTimezoneOffset(date2, timezoneOffset));
    } else if (!(date2 instanceof TimezoneDate) && opts.timezoneOffset !== void 0) {
      date2 = new TimezoneDate(date2, parseTimezoneOffset(date2, opts.timezoneOffset));
    }
    return strftime(date2, format3);
  }
  function isValidDate(date2) {
    return (date2 instanceof Date || date2 instanceof TimezoneDate) && !isNaN(date2.getTime());
  }
  function parseTimezoneOffset(date2, timeZone) {
    if (isNumber(timeZone))
      return timeZone;
    const utcDate = new Date(date2.toLocaleString("en-US", { timeZone: "UTC" }));
    const tzDate = new Date(date2.toLocaleString("en-US", { timeZone }));
    return (utcDate.getTime() - tzDate.getTime()) / 6e4;
  }
  var dateFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    date
  });
  function append(v, arg) {
    assert(arguments.length === 2, "append expect 2 arguments");
    return stringify(v) + stringify(arg);
  }
  function prepend(v, arg) {
    assert(arguments.length === 2, "prepend expect 2 arguments");
    return stringify(arg) + stringify(v);
  }
  function lstrip(v, chars) {
    if (chars) {
      chars = escapeRegExp(stringify(chars));
      return stringify(v).replace(new RegExp(`^[${chars}]+`, "g"), "");
    }
    return stringify(v).replace(/^\s+/, "");
  }
  function downcase(v) {
    return stringify(v).toLowerCase();
  }
  function upcase(str) {
    return stringify(str).toUpperCase();
  }
  function remove(v, arg) {
    return stringify(v).split(String(arg)).join("");
  }
  function remove_first(v, l) {
    return stringify(v).replace(String(l), "");
  }
  function remove_last(v, l) {
    const str = stringify(v);
    const pattern = String(l);
    const index = str.lastIndexOf(pattern);
    if (index === -1)
      return str;
    return str.substring(0, index) + str.substring(index + pattern.length);
  }
  function rstrip(str, chars) {
    if (chars) {
      chars = escapeRegExp(stringify(chars));
      return stringify(str).replace(new RegExp(`[${chars}]+$`, "g"), "");
    }
    return stringify(str).replace(/\s+$/, "");
  }
  function split(v, arg) {
    const arr = stringify(v).split(String(arg));
    while (arr.length && arr[arr.length - 1] === "")
      arr.pop();
    return arr;
  }
  function strip(v, chars) {
    if (chars) {
      chars = escapeRegExp(stringify(chars));
      return stringify(v).replace(new RegExp(`^[${chars}]+`, "g"), "").replace(new RegExp(`[${chars}]+$`, "g"), "");
    }
    return stringify(v).trim();
  }
  function strip_newlines(v) {
    return stringify(v).replace(/\r?\n/gm, "");
  }
  function capitalize(str) {
    str = stringify(str);
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }
  function replace(v, pattern, replacement) {
    return stringify(v).split(String(pattern)).join(replacement);
  }
  function replace_first(v, arg1, arg2) {
    return stringify(v).replace(String(arg1), arg2);
  }
  function replace_last(v, arg1, arg2) {
    const str = stringify(v);
    const pattern = String(arg1);
    const index = str.lastIndexOf(pattern);
    if (index === -1)
      return str;
    const replacement = String(arg2);
    return str.substring(0, index) + replacement + str.substring(index + pattern.length);
  }
  function truncate(v, l = 50, o = "...") {
    v = stringify(v);
    if (v.length <= l)
      return v;
    return v.substring(0, l - o.length) + o;
  }
  function truncatewords(v, words = 15, o = "...") {
    const arr = stringify(v).split(/\s+/);
    if (words <= 0)
      words = 1;
    let ret = arr.slice(0, words).join(" ");
    if (arr.length >= words)
      ret += o;
    return ret;
  }
  var stringFilters = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    append,
    prepend,
    lstrip,
    downcase,
    upcase,
    remove,
    remove_first,
    remove_last,
    rstrip,
    split,
    strip,
    strip_newlines,
    capitalize,
    replace,
    replace_first,
    replace_last,
    truncate,
    truncatewords
  });
  var filters = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, htmlFilters), mathFilters), urlFilters), arrayFilters), dateFilters), stringFilters), {
    json,
    raw,
    default: Default
  });
  var AssignTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.key = this.tokenizer.readIdentifier().content;
      this.tokenizer.assert(this.key, "expected variable name");
      this.tokenizer.skipBlank();
      this.tokenizer.assert(this.tokenizer.peek() === "=", 'expected "="');
      this.tokenizer.advance();
      this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
    }
    *render(ctx) {
      ctx.bottom()[this.key] = yield this.value.value(ctx, this.liquid.options.lenientIf);
    }
  };
  var MODIFIERS = ["offset", "limit", "reversed"];
  var ForTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      const variable = this.tokenizer.readIdentifier();
      const inStr = this.tokenizer.readIdentifier();
      const collection = this.tokenizer.readValue();
      if (!variable.size() || inStr.content !== "in" || !collection) {
        throw new Error(`illegal tag: ${token.getText()}`);
      }
      this.variable = variable.content;
      this.collection = collection;
      this.hash = new Hash(this.tokenizer.remaining());
      this.templates = [];
      this.elseTemplates = [];
      let p;
      const stream = this.liquid.parser.parseStream(remainTokens).on("start", () => p = this.templates).on("tag:else", () => p = this.elseTemplates).on("tag:endfor", () => stream.stop()).on("template", (tpl) => p.push(tpl)).on("end", () => {
        throw new Error(`tag ${token.getText()} not closed`);
      });
      stream.start();
    }
    *render(ctx, emitter) {
      const r = this.liquid.renderer;
      let collection = toEnumerable(yield evalToken(this.collection, ctx));
      if (!collection.length) {
        yield r.renderTemplates(this.elseTemplates, ctx, emitter);
        return;
      }
      const continueKey = "continue-" + this.variable + "-" + this.collection.getText();
      ctx.push({ continue: ctx.getRegister(continueKey) });
      const hash = yield this.hash.render(ctx);
      ctx.pop();
      const modifiers = this.liquid.options.orderedFilterParameters ? Object.keys(hash).filter((x2) => MODIFIERS.includes(x2)) : MODIFIERS.filter((x2) => hash[x2] !== void 0);
      collection = modifiers.reduce((collection2, modifier) => {
        if (modifier === "offset")
          return offset(collection2, hash["offset"]);
        if (modifier === "limit")
          return limit(collection2, hash["limit"]);
        return reversed(collection2);
      }, collection);
      ctx.setRegister(continueKey, (hash["offset"] || 0) + collection.length);
      const scope = { forloop: new ForloopDrop(collection.length, this.collection.getText(), this.variable) };
      ctx.push(scope);
      for (const item of collection) {
        scope[this.variable] = item;
        yield r.renderTemplates(this.templates, ctx, emitter);
        if (emitter["break"]) {
          emitter["break"] = false;
          break;
        }
        emitter["continue"] = false;
        scope.forloop.next();
      }
      ctx.pop();
    }
  };
  function reversed(arr) {
    return [...arr].reverse();
  }
  function offset(arr, count) {
    return arr.slice(count);
  }
  function limit(arr, count) {
    return arr.slice(0, count);
  }
  var CaptureTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      this.templates = [];
      this.variable = this.readVariableName();
      while (remainTokens.length) {
        const token = remainTokens.shift();
        if (isTagToken(token) && token.name === "endcapture")
          return;
        this.templates.push(liquid.parser.parseToken(token, remainTokens));
      }
      throw new Error(`tag ${tagToken.getText()} not closed`);
    }
    *render(ctx) {
      const r = this.liquid.renderer;
      const html = yield r.renderTemplates(this.templates, ctx);
      ctx.bottom()[this.variable] = html;
    }
    readVariableName() {
      const word = this.tokenizer.readIdentifier().content;
      if (word)
        return word;
      const quoted = this.tokenizer.readQuoted();
      if (quoted)
        return evalQuotedToken(quoted);
      throw this.tokenizer.error("invalid capture name");
    }
  };
  var CaseTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      this.branches = [];
      this.elseTemplates = [];
      this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
      this.elseTemplates = [];
      let p = [];
      let elseCount = 0;
      const stream = this.liquid.parser.parseStream(remainTokens).on("tag:when", (token) => {
        if (elseCount > 0) {
          return;
        }
        p = [];
        const values = [];
        while (!token.tokenizer.end()) {
          values.push(token.tokenizer.readValueOrThrow());
          token.tokenizer.skipBlank();
          if (token.tokenizer.peek() === ",") {
            token.tokenizer.readTo(",");
          } else {
            token.tokenizer.readTo("or");
          }
        }
        this.branches.push({
          values,
          templates: p
        });
      }).on("tag:else", () => {
        elseCount++;
        p = this.elseTemplates;
      }).on("tag:endcase", () => stream.stop()).on("template", (tpl) => {
        if (p !== this.elseTemplates || elseCount === 1) {
          p.push(tpl);
        }
      }).on("end", () => {
        throw new Error(`tag ${tagToken.getText()} not closed`);
      });
      stream.start();
    }
    *render(ctx, emitter) {
      const r = this.liquid.renderer;
      const target = toValue(yield this.value.value(ctx, ctx.opts.lenientIf));
      let branchHit = false;
      for (const branch of this.branches) {
        for (const valueToken of branch.values) {
          const value = yield evalToken(valueToken, ctx, ctx.opts.lenientIf);
          if (target === value) {
            yield r.renderTemplates(branch.templates, ctx, emitter);
            branchHit = true;
            break;
          }
        }
      }
      if (!branchHit) {
        yield r.renderTemplates(this.elseTemplates, ctx, emitter);
      }
    }
  };
  var CommentTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      while (remainTokens.length) {
        const token = remainTokens.shift();
        if (isTagToken(token) && token.name === "endcomment")
          return;
      }
      throw new Error(`tag ${tagToken.getText()} not closed`);
    }
    render() {
    }
  };
  var RenderTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      const tokenizer = this.tokenizer;
      this.file = parseFilePath(tokenizer, this.liquid);
      this.currentFile = token.file;
      while (!tokenizer.end()) {
        tokenizer.skipBlank();
        const begin = tokenizer.p;
        const keyword = tokenizer.readIdentifier();
        if (keyword.content === "with" || keyword.content === "for") {
          tokenizer.skipBlank();
          if (tokenizer.peek() !== ":") {
            const value = tokenizer.readValue();
            if (value) {
              const beforeAs = tokenizer.p;
              const asStr = tokenizer.readIdentifier();
              let alias;
              if (asStr.content === "as")
                alias = tokenizer.readIdentifier();
              else
                tokenizer.p = beforeAs;
              this[keyword.content] = { value, alias: alias && alias.content };
              tokenizer.skipBlank();
              if (tokenizer.peek() === ",")
                tokenizer.advance();
              continue;
            }
          }
        }
        tokenizer.p = begin;
        break;
      }
      this.hash = new Hash(tokenizer.remaining());
    }
    *render(ctx, emitter) {
      const { liquid, hash } = this;
      const filepath = yield renderFilePath(this["file"], ctx, liquid);
      assert(filepath, () => `illegal file path "${filepath}"`);
      const childCtx = new Context({}, ctx.opts, { sync: ctx.sync, globals: ctx.globals, strictVariables: ctx.strictVariables });
      const scope = childCtx.bottom();
      __assign(scope, yield hash.render(ctx));
      if (this["with"]) {
        const { value, alias } = this["with"];
        scope[alias || filepath] = yield evalToken(value, ctx);
      }
      if (this["for"]) {
        const { value, alias } = this["for"];
        const collection = toEnumerable(yield evalToken(value, ctx));
        scope["forloop"] = new ForloopDrop(collection.length, value.getText(), alias);
        for (const item of collection) {
          scope[alias] = item;
          const templates = yield liquid._parsePartialFile(filepath, childCtx.sync, this["currentFile"]);
          yield liquid.renderer.renderTemplates(templates, childCtx, emitter);
          scope["forloop"].next();
        }
      } else {
        const templates = yield liquid._parsePartialFile(filepath, childCtx.sync, this["currentFile"]);
        yield liquid.renderer.renderTemplates(templates, childCtx, emitter);
      }
    }
  };
  function parseFilePath(tokenizer, liquid) {
    if (liquid.options.dynamicPartials) {
      const file = tokenizer.readValue();
      tokenizer.assert(file, "illegal file path");
      if (file.getText() === "none")
        return;
      if (isQuotedToken(file)) {
        const templates2 = liquid.parse(evalQuotedToken(file));
        return optimize(templates2);
      }
      return file;
    }
    const tokens = [...tokenizer.readFileNameTemplate(liquid.options)];
    const templates = optimize(liquid.parser.parseTokens(tokens));
    return templates === "none" ? void 0 : templates;
  }
  function optimize(templates) {
    if (templates.length === 1 && isHTMLToken(templates[0].token))
      return templates[0].token.getContent();
    return templates;
  }
  function* renderFilePath(file, ctx, liquid) {
    if (typeof file === "string")
      return file;
    if (Array.isArray(file))
      return liquid.renderer.renderTemplates(file, ctx);
    return yield evalToken(file, ctx);
  }
  var IncludeTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      const { tokenizer } = token;
      this["file"] = parseFilePath(tokenizer, this.liquid);
      this["currentFile"] = token.file;
      const begin = tokenizer.p;
      const withStr = tokenizer.readIdentifier();
      if (withStr.content === "with") {
        tokenizer.skipBlank();
        if (tokenizer.peek() !== ":") {
          this.withVar = tokenizer.readValue();
        } else
          tokenizer.p = begin;
      } else
        tokenizer.p = begin;
      this.hash = new Hash(tokenizer.remaining(), this.liquid.options.jekyllInclude);
    }
    *render(ctx, emitter) {
      const { liquid, hash, withVar } = this;
      const { renderer } = liquid;
      const filepath = yield renderFilePath(this["file"], ctx, liquid);
      assert(filepath, () => `illegal file path "${filepath}"`);
      const saved = ctx.saveRegister("blocks", "blockMode");
      ctx.setRegister("blocks", {});
      ctx.setRegister("blockMode", BlockMode.OUTPUT);
      const scope = yield hash.render(ctx);
      if (withVar)
        scope[filepath] = yield evalToken(withVar, ctx);
      const templates = yield liquid._parsePartialFile(filepath, ctx.sync, this["currentFile"]);
      ctx.push(ctx.opts.jekyllInclude ? { include: scope } : scope);
      yield renderer.renderTemplates(templates, ctx, emitter);
      ctx.pop();
      ctx.restoreRegister(saved);
    }
  };
  var DecrementTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.variable = this.tokenizer.readIdentifier().content;
    }
    render(context, emitter) {
      const scope = context.environments;
      if (!isNumber(scope[this.variable])) {
        scope[this.variable] = 0;
      }
      emitter.write(stringify(--scope[this.variable]));
    }
  };
  var CycleTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.candidates = [];
      const group = this.tokenizer.readValue();
      this.tokenizer.skipBlank();
      if (group) {
        if (this.tokenizer.peek() === ":") {
          this.group = group;
          this.tokenizer.advance();
        } else
          this.candidates.push(group);
      }
      while (!this.tokenizer.end()) {
        const value = this.tokenizer.readValue();
        if (value)
          this.candidates.push(value);
        this.tokenizer.readTo(",");
      }
      this.tokenizer.assert(this.candidates.length, () => `empty candidates: "${token.getText()}"`);
    }
    *render(ctx, emitter) {
      const group = yield evalToken(this.group, ctx);
      const fingerprint = `cycle:${group}:` + this.candidates.join(",");
      const groups = ctx.getRegister("cycle");
      let idx = groups[fingerprint];
      if (idx === void 0) {
        idx = groups[fingerprint] = 0;
      }
      const candidate = this.candidates[idx];
      idx = (idx + 1) % this.candidates.length;
      groups[fingerprint] = idx;
      return yield evalToken(candidate, ctx);
    }
  };
  var IfTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      this.branches = [];
      this.elseTemplates = [];
      let p = [];
      let elseCount = 0;
      liquid.parser.parseStream(remainTokens).on("start", () => this.branches.push({
        value: new Value(tagToken.args, this.liquid),
        templates: p = []
      })).on("tag:elsif", (token) => {
        if (elseCount > 0) {
          p = [];
          return;
        }
        this.branches.push({
          value: new Value(token.args, this.liquid),
          templates: p = []
        });
      }).on("tag:else", () => {
        elseCount++;
        p = this.elseTemplates;
      }).on("tag:endif", function() {
        this.stop();
      }).on("template", (tpl) => {
        if (p !== this.elseTemplates || elseCount === 1) {
          p.push(tpl);
        }
      }).on("end", () => {
        throw new Error(`tag ${tagToken.getText()} not closed`);
      }).start();
    }
    *render(ctx, emitter) {
      const r = this.liquid.renderer;
      for (const { value, templates } of this.branches) {
        const v = yield value.value(ctx, ctx.opts.lenientIf);
        if (isTruthy(v, ctx)) {
          yield r.renderTemplates(templates, ctx, emitter);
          return;
        }
      }
      yield r.renderTemplates(this.elseTemplates, ctx, emitter);
    }
  };
  var IncrementTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.variable = this.tokenizer.readIdentifier().content;
    }
    render(context, emitter) {
      const scope = context.environments;
      if (!isNumber(scope[this.variable])) {
        scope[this.variable] = 0;
      }
      const val = scope[this.variable];
      scope[this.variable]++;
      emitter.write(stringify(val));
    }
  };
  var LayoutTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.file = parseFilePath(this.tokenizer, this.liquid);
      this["currentFile"] = token.file;
      this.args = new Hash(this.tokenizer.remaining());
      this.templates = this.liquid.parser.parseTokens(remainTokens);
    }
    *render(ctx, emitter) {
      const { liquid, args, file } = this;
      const { renderer } = liquid;
      if (file === void 0) {
        ctx.setRegister("blockMode", BlockMode.OUTPUT);
        yield renderer.renderTemplates(this.templates, ctx, emitter);
        return;
      }
      const filepath = yield renderFilePath(this.file, ctx, liquid);
      assert(filepath, () => `illegal file path "${filepath}"`);
      const templates = yield liquid._parseLayoutFile(filepath, ctx.sync, this["currentFile"]);
      ctx.setRegister("blockMode", BlockMode.STORE);
      const html = yield renderer.renderTemplates(this.templates, ctx);
      const blocks = ctx.getRegister("blocks");
      if (blocks[""] === void 0)
        blocks[""] = (parent, emitter2) => emitter2.write(html);
      ctx.setRegister("blockMode", BlockMode.OUTPUT);
      ctx.push(yield args.render(ctx));
      yield renderer.renderTemplates(templates, ctx, emitter);
      ctx.pop();
    }
  };
  var BlockTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.templates = [];
      const match2 = /\w+/.exec(token.args);
      this.block = match2 ? match2[0] : "";
      while (remainTokens.length) {
        const token2 = remainTokens.shift();
        if (isTagToken(token2) && token2.name === "endblock")
          return;
        const template = liquid.parser.parseToken(token2, remainTokens);
        this.templates.push(template);
      }
      throw new Error(`tag ${token.getText()} not closed`);
    }
    *render(ctx, emitter) {
      const blockRender = this.getBlockRender(ctx);
      if (ctx.getRegister("blockMode") === BlockMode.STORE) {
        ctx.getRegister("blocks")[this.block] = blockRender;
      } else {
        yield blockRender(new BlockDrop(), emitter);
      }
    }
    getBlockRender(ctx) {
      const { liquid, templates } = this;
      const renderChild = ctx.getRegister("blocks")[this.block];
      const renderCurrent = function* (superBlock, emitter) {
        ctx.push({ block: superBlock });
        yield liquid.renderer.renderTemplates(templates, ctx, emitter);
        ctx.pop();
      };
      return renderChild ? (superBlock, emitter) => renderChild(new BlockDrop(() => renderCurrent(superBlock, emitter)), emitter) : renderCurrent;
    }
  };
  var RawTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      this.tokens = [];
      while (remainTokens.length) {
        const token = remainTokens.shift();
        if (isTagToken(token) && token.name === "endraw")
          return;
        this.tokens.push(token);
      }
      throw new Error(`tag ${tagToken.getText()} not closed`);
    }
    render() {
      return this.tokens.map((token) => token.getText()).join("");
    }
  };
  var TablerowloopDrop = class extends ForloopDrop {
    constructor(length, cols, collection, variable) {
      super(length, collection, variable);
      this.length = length;
      this.cols = cols;
    }
    row() {
      return Math.floor(this.i / this.cols) + 1;
    }
    col0() {
      return this.i % this.cols;
    }
    col() {
      return this.col0() + 1;
    }
    col_first() {
      return this.col0() === 0;
    }
    col_last() {
      return this.col() === this.cols;
    }
  };
  var TablerowTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      const variable = this.tokenizer.readIdentifier();
      this.tokenizer.skipBlank();
      const predicate = this.tokenizer.readIdentifier();
      const collectionToken = this.tokenizer.readValue();
      if (predicate.content !== "in" || !collectionToken) {
        throw new Error(`illegal tag: ${tagToken.getText()}`);
      }
      this.variable = variable.content;
      this.collection = collectionToken;
      this.args = new Hash(this.tokenizer.remaining());
      this.templates = [];
      let p;
      const stream = this.liquid.parser.parseStream(remainTokens).on("start", () => p = this.templates).on("tag:endtablerow", () => stream.stop()).on("template", (tpl) => p.push(tpl)).on("end", () => {
        throw new Error(`tag ${tagToken.getText()} not closed`);
      });
      stream.start();
    }
    *render(ctx, emitter) {
      let collection = toEnumerable(yield evalToken(this.collection, ctx));
      const args = yield this.args.render(ctx);
      const offset2 = args.offset || 0;
      const limit2 = args.limit === void 0 ? collection.length : args.limit;
      collection = collection.slice(offset2, offset2 + limit2);
      const cols = args.cols || collection.length;
      const r = this.liquid.renderer;
      const tablerowloop = new TablerowloopDrop(collection.length, cols, this.collection.getText(), this.variable);
      const scope = { tablerowloop };
      ctx.push(scope);
      for (let idx = 0; idx < collection.length; idx++, tablerowloop.next()) {
        scope[this.variable] = collection[idx];
        if (tablerowloop.col0() === 0) {
          if (tablerowloop.row() !== 1)
            emitter.write("</tr>");
          emitter.write(`<tr class="row${tablerowloop.row()}">`);
        }
        emitter.write(`<td class="col${tablerowloop.col()}">`);
        yield r.renderTemplates(this.templates, ctx, emitter);
        emitter.write("</td>");
      }
      if (collection.length)
        emitter.write("</tr>");
      ctx.pop();
    }
  };
  var UnlessTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      this.branches = [];
      this.elseTemplates = [];
      let p = [];
      let elseCount = 0;
      this.liquid.parser.parseStream(remainTokens).on("start", () => this.branches.push({
        value: new Value(tagToken.args, this.liquid),
        test: isFalsy,
        templates: p = []
      })).on("tag:elsif", (token) => {
        if (elseCount > 0) {
          p = [];
          return;
        }
        this.branches.push({
          value: new Value(token.args, this.liquid),
          test: isTruthy,
          templates: p = []
        });
      }).on("tag:else", () => {
        elseCount++;
        p = this.elseTemplates;
      }).on("tag:endunless", function() {
        this.stop();
      }).on("template", (tpl) => {
        if (p !== this.elseTemplates || elseCount === 1) {
          p.push(tpl);
        }
      }).on("end", () => {
        throw new Error(`tag ${tagToken.getText()} not closed`);
      }).start();
    }
    *render(ctx, emitter) {
      const r = this.liquid.renderer;
      for (const { value, test, templates } of this.branches) {
        const v = yield value.value(ctx, ctx.opts.lenientIf);
        if (test(v, ctx)) {
          yield r.renderTemplates(templates, ctx, emitter);
          return;
        }
      }
      yield r.renderTemplates(this.elseTemplates, ctx, emitter);
    }
  };
  var BreakTag = class extends Tag {
    render(ctx, emitter) {
      emitter["break"] = true;
    }
  };
  var ContinueTag = class extends Tag {
    render(ctx, emitter) {
      emitter["continue"] = true;
    }
  };
  var EchoTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      this.tokenizer.skipBlank();
      if (!this.tokenizer.end()) {
        this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
      }
    }
    *render(ctx, emitter) {
      if (!this.value)
        return;
      const val = yield this.value.value(ctx, false);
      emitter.write(val);
    }
  };
  var LiquidTag = class extends Tag {
    constructor(token, remainTokens, liquid) {
      super(token, remainTokens, liquid);
      const tokens = this.tokenizer.readLiquidTagTokens(this.liquid.options);
      this.templates = this.liquid.parser.parseTokens(tokens);
    }
    *render(ctx, emitter) {
      yield this.liquid.renderer.renderTemplates(this.templates, ctx, emitter);
    }
  };
  var InlineCommentTag = class extends Tag {
    constructor(tagToken, remainTokens, liquid) {
      super(tagToken, remainTokens, liquid);
      if (tagToken.args.search(/\n\s*[^#\s]/g) !== -1) {
        throw new Error("every line of an inline comment must start with a '#' character");
      }
    }
    render() {
    }
  };
  var tags = {
    assign: AssignTag,
    "for": ForTag,
    capture: CaptureTag,
    "case": CaseTag,
    comment: CommentTag,
    include: IncludeTag,
    render: RenderTag,
    decrement: DecrementTag,
    increment: IncrementTag,
    cycle: CycleTag,
    "if": IfTag,
    layout: LayoutTag,
    block: BlockTag,
    raw: RawTag,
    tablerow: TablerowTag,
    unless: UnlessTag,
    "break": BreakTag,
    "continue": ContinueTag,
    echo: EchoTag,
    liquid: LiquidTag,
    "#": InlineCommentTag
  };
  var Liquid = class {
    constructor(opts = {}) {
      this.renderer = new Render();
      this.filters = {};
      this.tags = {};
      this.options = normalize(opts);
      this.parser = new Parser(this);
      forOwn(tags, (conf, name) => this.registerTag(name, conf));
      forOwn(filters, (handler, name) => this.registerFilter(name, handler));
    }
    parse(html, filepath) {
      return this.parser.parse(html, filepath);
    }
    _render(tpl, scope, renderOptions) {
      const ctx = scope instanceof Context ? scope : new Context(scope, this.options, renderOptions);
      return this.renderer.renderTemplates(tpl, ctx);
    }
    render(tpl, scope, renderOptions) {
      return __awaiter(this, void 0, void 0, function* () {
        return toPromise(this._render(tpl, scope, Object.assign(Object.assign({}, renderOptions), { sync: false })));
      });
    }
    renderSync(tpl, scope, renderOptions) {
      return toValueSync(this._render(tpl, scope, Object.assign(Object.assign({}, renderOptions), { sync: true })));
    }
    renderToNodeStream(tpl, scope, renderOptions = {}) {
      const ctx = new Context(scope, this.options, renderOptions);
      return this.renderer.renderTemplatesToNodeStream(tpl, ctx);
    }
    _parseAndRender(html, scope, renderOptions) {
      const tpl = this.parse(html);
      return this._render(tpl, scope, renderOptions);
    }
    parseAndRender(html, scope, renderOptions) {
      return __awaiter(this, void 0, void 0, function* () {
        return toPromise(this._parseAndRender(html, scope, Object.assign(Object.assign({}, renderOptions), { sync: false })));
      });
    }
    parseAndRenderSync(html, scope, renderOptions) {
      return toValueSync(this._parseAndRender(html, scope, Object.assign(Object.assign({}, renderOptions), { sync: true })));
    }
    _parsePartialFile(file, sync, currentFile) {
      return this.parser.parseFile(file, sync, LookupType.Partials, currentFile);
    }
    _parseLayoutFile(file, sync, currentFile) {
      return this.parser.parseFile(file, sync, LookupType.Layouts, currentFile);
    }
    _parseFile(file, sync, lookupType, currentFile) {
      return this.parser.parseFile(file, sync, lookupType, currentFile);
    }
    parseFile(file, lookupType) {
      return __awaiter(this, void 0, void 0, function* () {
        return toPromise(this.parser.parseFile(file, false, lookupType));
      });
    }
    parseFileSync(file, lookupType) {
      return toValueSync(this.parser.parseFile(file, true, lookupType));
    }
    *_renderFile(file, ctx, renderFileOptions) {
      const templates = yield this._parseFile(file, renderFileOptions.sync, renderFileOptions.lookupType);
      return yield this._render(templates, ctx, renderFileOptions);
    }
    renderFile(file, ctx, renderFileOptions) {
      return __awaiter(this, void 0, void 0, function* () {
        return toPromise(this._renderFile(file, ctx, Object.assign(Object.assign({}, renderFileOptions), { sync: false })));
      });
    }
    renderFileSync(file, ctx, renderFileOptions) {
      return toValueSync(this._renderFile(file, ctx, Object.assign(Object.assign({}, renderFileOptions), { sync: true })));
    }
    renderFileToNodeStream(file, scope, renderOptions) {
      return __awaiter(this, void 0, void 0, function* () {
        const templates = yield this.parseFile(file);
        return this.renderToNodeStream(templates, scope, renderOptions);
      });
    }
    _evalValue(str, scope) {
      const value = new Value(str, this);
      const ctx = scope instanceof Context ? scope : new Context(scope, this.options);
      return value.value(ctx);
    }
    evalValue(str, scope) {
      return __awaiter(this, void 0, void 0, function* () {
        return toPromise(this._evalValue(str, scope));
      });
    }
    evalValueSync(str, scope) {
      return toValueSync(this._evalValue(str, scope));
    }
    registerFilter(name, filter) {
      this.filters[name] = filter;
    }
    registerTag(name, tag) {
      this.tags[name] = isFunction(tag) ? tag : createTagClass(tag);
    }
    plugin(plugin) {
      return plugin.call(this, Liquid);
    }
    express() {
      const self2 = this;
      let firstCall = true;
      return function(filePath, ctx, callback) {
        if (firstCall) {
          firstCall = false;
          const dirs = normalizeDirectoryList(this.root);
          self2.options.root.unshift(...dirs);
          self2.options.layouts.unshift(...dirs);
          self2.options.partials.unshift(...dirs);
        }
        self2.renderFile(filePath, ctx).then((html) => callback(null, html), callback);
      };
    }
  };

  // src/pages/background/utils.ts
  var engine = new Liquid();
  var logseqTimeFormat = (date2) => {
    return format(date2, "HH:mm");
  };
  var mappingVersionToNumbers = (version) => {
    return version.split(".").slice(0, 3).map((x2) => {
      return parseInt(x2.split("0")[0]);
    });
  };
  var versionCompare = (versionA, versionB) => {
    const [majorA, minorA, patchA] = mappingVersionToNumbers(versionA);
    const [majorB, minorB, patchB] = mappingVersionToNumbers(versionB);
    if (majorA < majorB)
      return -1;
    if (majorA > majorB)
      return 1;
    if (minorA < minorB)
      return -1;
    if (minorA > minorB)
      return 1;
    if (patchA < patchB)
      return -1;
    if (patchA > patchB)
      return 1;
    return 0;
  };
  function logseqEscape(str) {
    return str.replaceAll(/([\[\{\(]{2})/g, "\\$1");
  }
  function blockRending({
    url,
    title,
    data,
    clipNoteTemplate,
    preferredDateFormat,
    time
  }) {
    const render = engine.parseAndRenderSync(clipNoteTemplate, {
      date: format(time, preferredDateFormat),
      content: logseqEscape(data),
      url,
      time: logseqTimeFormat(time),
      dt: time,
      title
    }).trim();
    return render;
  }

  // src/utils.ts
  var debounce = (func, waitFor) => {
    let timeout = void 0;
    return (...args) => new Promise((resolve2) => {
      if (timeout) {
        clearTimeout(timeout);
      }
      timeout = setTimeout(() => resolve2(func(...args)), waitFor);
    });
  };

  // src/pages/background/upgrade.ts
  var changeOptionsHostToHostNameAndPort = async () => {
    const { logseqHost } = await getLogseqCopliotConfig();
    if (logseqHost) {
      const url = new URL(logseqHost);
      await saveLogseqCopliotConfig({
        logseqHostName: url.hostname,
        logseqPort: parseInt(url.port)
      });
      browser.storage.local.remove("logseqHost");
    }
  };

  // node_modules/marked/lib/marked.esm.js
  function getDefaults() {
    return {
      async: false,
      baseUrl: null,
      breaks: false,
      extensions: null,
      gfm: true,
      headerIds: true,
      headerPrefix: "",
      highlight: null,
      hooks: null,
      langPrefix: "language-",
      mangle: true,
      pedantic: false,
      renderer: null,
      sanitize: false,
      sanitizer: null,
      silent: false,
      smartypants: false,
      tokenizer: null,
      walkTokens: null,
      xhtml: false
    };
  }
  var defaults = getDefaults();
  function changeDefaults(newDefaults) {
    defaults = newDefaults;
  }
  var escapeTest = /[&<>"']/;
  var escapeReplace = new RegExp(escapeTest.source, "g");
  var escapeTestNoEncode = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/;
  var escapeReplaceNoEncode = new RegExp(escapeTestNoEncode.source, "g");
  var escapeReplacements = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var getEscapeReplacement = (ch) => escapeReplacements[ch];
  function escape2(html, encode) {
    if (encode) {
      if (escapeTest.test(html)) {
        return html.replace(escapeReplace, getEscapeReplacement);
      }
    } else {
      if (escapeTestNoEncode.test(html)) {
        return html.replace(escapeReplaceNoEncode, getEscapeReplacement);
      }
    }
    return html;
  }
  var unescapeTest = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
  function unescape2(html) {
    return html.replace(unescapeTest, (_, n) => {
      n = n.toLowerCase();
      if (n === "colon")
        return ":";
      if (n.charAt(0) === "#") {
        return n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1));
      }
      return "";
    });
  }
  var caret = /(^|[^\[])\^/g;
  function edit(regex, opt) {
    regex = typeof regex === "string" ? regex : regex.source;
    opt = opt || "";
    const obj = {
      replace: (name, val) => {
        val = val.source || val;
        val = val.replace(caret, "$1");
        regex = regex.replace(name, val);
        return obj;
      },
      getRegex: () => {
        return new RegExp(regex, opt);
      }
    };
    return obj;
  }
  var nonWordAndColonTest = /[^\w:]/g;
  var originIndependentUrl = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;
  function cleanUrl(sanitize, base, href) {
    if (sanitize) {
      let prot;
      try {
        prot = decodeURIComponent(unescape2(href)).replace(nonWordAndColonTest, "").toLowerCase();
      } catch (e2) {
        return null;
      }
      if (prot.indexOf("javascript:") === 0 || prot.indexOf("vbscript:") === 0 || prot.indexOf("data:") === 0) {
        return null;
      }
    }
    if (base && !originIndependentUrl.test(href)) {
      href = resolveUrl(base, href);
    }
    try {
      href = encodeURI(href).replace(/%25/g, "%");
    } catch (e2) {
      return null;
    }
    return href;
  }
  var baseUrls = {};
  var justDomain = /^[^:]+:\/*[^/]*$/;
  var protocol = /^([^:]+:)[\s\S]*$/;
  var domain = /^([^:]+:\/*[^/]*)[\s\S]*$/;
  function resolveUrl(base, href) {
    if (!baseUrls[" " + base]) {
      if (justDomain.test(base)) {
        baseUrls[" " + base] = base + "/";
      } else {
        baseUrls[" " + base] = rtrim(base, "/", true);
      }
    }
    base = baseUrls[" " + base];
    const relativeBase = base.indexOf(":") === -1;
    if (href.substring(0, 2) === "//") {
      if (relativeBase) {
        return href;
      }
      return base.replace(protocol, "$1") + href;
    } else if (href.charAt(0) === "/") {
      if (relativeBase) {
        return href;
      }
      return base.replace(domain, "$1") + href;
    } else {
      return base + href;
    }
  }
  var noopTest = { exec: function noopTest2() {
  } };
  function splitCells(tableRow, count) {
    const row = tableRow.replace(/\|/g, (match2, offset2, str) => {
      let escaped = false, curr = offset2;
      while (--curr >= 0 && str[curr] === "\\")
        escaped = !escaped;
      if (escaped) {
        return "|";
      } else {
        return " |";
      }
    }), cells = row.split(/ \|/);
    let i2 = 0;
    if (!cells[0].trim()) {
      cells.shift();
    }
    if (cells.length > 0 && !cells[cells.length - 1].trim()) {
      cells.pop();
    }
    if (cells.length > count) {
      cells.splice(count);
    } else {
      while (cells.length < count)
        cells.push("");
    }
    for (; i2 < cells.length; i2++) {
      cells[i2] = cells[i2].trim().replace(/\\\|/g, "|");
    }
    return cells;
  }
  function rtrim(str, c2, invert) {
    const l = str.length;
    if (l === 0) {
      return "";
    }
    let suffLen = 0;
    while (suffLen < l) {
      const currChar = str.charAt(l - suffLen - 1);
      if (currChar === c2 && !invert) {
        suffLen++;
      } else if (currChar !== c2 && invert) {
        suffLen++;
      } else {
        break;
      }
    }
    return str.slice(0, l - suffLen);
  }
  function findClosingBracket(str, b2) {
    if (str.indexOf(b2[1]) === -1) {
      return -1;
    }
    const l = str.length;
    let level = 0, i2 = 0;
    for (; i2 < l; i2++) {
      if (str[i2] === "\\") {
        i2++;
      } else if (str[i2] === b2[0]) {
        level++;
      } else if (str[i2] === b2[1]) {
        level--;
        if (level < 0) {
          return i2;
        }
      }
    }
    return -1;
  }
  function checkSanitizeDeprecation(opt) {
    if (opt && opt.sanitize && !opt.silent) {
      console.warn("marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options");
    }
  }
  function repeatString(pattern, count) {
    if (count < 1) {
      return "";
    }
    let result = "";
    while (count > 1) {
      if (count & 1) {
        result += pattern;
      }
      count >>= 1;
      pattern += pattern;
    }
    return result + pattern;
  }
  function outputLink(cap, link, raw2, lexer2) {
    const href = link.href;
    const title = link.title ? escape2(link.title) : null;
    const text = cap[1].replace(/\\([\[\]])/g, "$1");
    if (cap[0].charAt(0) !== "!") {
      lexer2.state.inLink = true;
      const token = {
        type: "link",
        raw: raw2,
        href,
        title,
        text,
        tokens: lexer2.inlineTokens(text)
      };
      lexer2.state.inLink = false;
      return token;
    }
    return {
      type: "image",
      raw: raw2,
      href,
      title,
      text: escape2(text)
    };
  }
  function indentCodeCompensation(raw2, text) {
    const matchIndentToCode = raw2.match(/^(\s+)(?:```)/);
    if (matchIndentToCode === null) {
      return text;
    }
    const indentToCode = matchIndentToCode[1];
    return text.split("\n").map((node) => {
      const matchIndentInNode = node.match(/^\s+/);
      if (matchIndentInNode === null) {
        return node;
      }
      const [indentInNode] = matchIndentInNode;
      if (indentInNode.length >= indentToCode.length) {
        return node.slice(indentToCode.length);
      }
      return node;
    }).join("\n");
  }
  var Tokenizer2 = class {
    constructor(options2) {
      this.options = options2 || defaults;
    }
    space(src) {
      const cap = this.rules.block.newline.exec(src);
      if (cap && cap[0].length > 0) {
        return {
          type: "space",
          raw: cap[0]
        };
      }
    }
    code(src) {
      const cap = this.rules.block.code.exec(src);
      if (cap) {
        const text = cap[0].replace(/^ {1,4}/gm, "");
        return {
          type: "code",
          raw: cap[0],
          codeBlockStyle: "indented",
          text: !this.options.pedantic ? rtrim(text, "\n") : text
        };
      }
    }
    fences(src) {
      const cap = this.rules.block.fences.exec(src);
      if (cap) {
        const raw2 = cap[0];
        const text = indentCodeCompensation(raw2, cap[3] || "");
        return {
          type: "code",
          raw: raw2,
          lang: cap[2] ? cap[2].trim().replace(this.rules.inline._escapes, "$1") : cap[2],
          text
        };
      }
    }
    heading(src) {
      const cap = this.rules.block.heading.exec(src);
      if (cap) {
        let text = cap[2].trim();
        if (/#$/.test(text)) {
          const trimmed = rtrim(text, "#");
          if (this.options.pedantic) {
            text = trimmed.trim();
          } else if (!trimmed || / $/.test(trimmed)) {
            text = trimmed.trim();
          }
        }
        return {
          type: "heading",
          raw: cap[0],
          depth: cap[1].length,
          text,
          tokens: this.lexer.inline(text)
        };
      }
    }
    hr(src) {
      const cap = this.rules.block.hr.exec(src);
      if (cap) {
        return {
          type: "hr",
          raw: cap[0]
        };
      }
    }
    blockquote(src) {
      const cap = this.rules.block.blockquote.exec(src);
      if (cap) {
        const text = cap[0].replace(/^ *>[ \t]?/gm, "");
        const top = this.lexer.state.top;
        this.lexer.state.top = true;
        const tokens = this.lexer.blockTokens(text);
        this.lexer.state.top = top;
        return {
          type: "blockquote",
          raw: cap[0],
          tokens,
          text
        };
      }
    }
    list(src) {
      let cap = this.rules.block.list.exec(src);
      if (cap) {
        let raw2, istask, ischecked, indent, i2, blankLine, endsWithBlankLine, line, nextLine, rawLine, itemContents, endEarly;
        let bull = cap[1].trim();
        const isordered = bull.length > 1;
        const list = {
          type: "list",
          raw: "",
          ordered: isordered,
          start: isordered ? +bull.slice(0, -1) : "",
          loose: false,
          items: []
        };
        bull = isordered ? `\\d{1,9}\\${bull.slice(-1)}` : `\\${bull}`;
        if (this.options.pedantic) {
          bull = isordered ? bull : "[*+-]";
        }
        const itemRegex = new RegExp(`^( {0,3}${bull})((?:[	 ][^\\n]*)?(?:\\n|$))`);
        while (src) {
          endEarly = false;
          if (!(cap = itemRegex.exec(src))) {
            break;
          }
          if (this.rules.block.hr.test(src)) {
            break;
          }
          raw2 = cap[0];
          src = src.substring(raw2.length);
          line = cap[2].split("\n", 1)[0].replace(/^\t+/, (t2) => " ".repeat(3 * t2.length));
          nextLine = src.split("\n", 1)[0];
          if (this.options.pedantic) {
            indent = 2;
            itemContents = line.trimLeft();
          } else {
            indent = cap[2].search(/[^ ]/);
            indent = indent > 4 ? 1 : indent;
            itemContents = line.slice(indent);
            indent += cap[1].length;
          }
          blankLine = false;
          if (!line && /^ *$/.test(nextLine)) {
            raw2 += nextLine + "\n";
            src = src.substring(nextLine.length + 1);
            endEarly = true;
          }
          if (!endEarly) {
            const nextBulletRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`);
            const hrRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`);
            const fencesBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`);
            const headingBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`);
            while (src) {
              rawLine = src.split("\n", 1)[0];
              nextLine = rawLine;
              if (this.options.pedantic) {
                nextLine = nextLine.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ");
              }
              if (fencesBeginRegex.test(nextLine)) {
                break;
              }
              if (headingBeginRegex.test(nextLine)) {
                break;
              }
              if (nextBulletRegex.test(nextLine)) {
                break;
              }
              if (hrRegex.test(src)) {
                break;
              }
              if (nextLine.search(/[^ ]/) >= indent || !nextLine.trim()) {
                itemContents += "\n" + nextLine.slice(indent);
              } else {
                if (blankLine) {
                  break;
                }
                if (line.search(/[^ ]/) >= 4) {
                  break;
                }
                if (fencesBeginRegex.test(line)) {
                  break;
                }
                if (headingBeginRegex.test(line)) {
                  break;
                }
                if (hrRegex.test(line)) {
                  break;
                }
                itemContents += "\n" + nextLine;
              }
              if (!blankLine && !nextLine.trim()) {
                blankLine = true;
              }
              raw2 += rawLine + "\n";
              src = src.substring(rawLine.length + 1);
              line = nextLine.slice(indent);
            }
          }
          if (!list.loose) {
            if (endsWithBlankLine) {
              list.loose = true;
            } else if (/\n *\n *$/.test(raw2)) {
              endsWithBlankLine = true;
            }
          }
          if (this.options.gfm) {
            istask = /^\[[ xX]\] /.exec(itemContents);
            if (istask) {
              ischecked = istask[0] !== "[ ] ";
              itemContents = itemContents.replace(/^\[[ xX]\] +/, "");
            }
          }
          list.items.push({
            type: "list_item",
            raw: raw2,
            task: !!istask,
            checked: ischecked,
            loose: false,
            text: itemContents
          });
          list.raw += raw2;
        }
        list.items[list.items.length - 1].raw = raw2.trimRight();
        list.items[list.items.length - 1].text = itemContents.trimRight();
        list.raw = list.raw.trimRight();
        const l = list.items.length;
        for (i2 = 0; i2 < l; i2++) {
          this.lexer.state.top = false;
          list.items[i2].tokens = this.lexer.blockTokens(list.items[i2].text, []);
          if (!list.loose) {
            const spacers = list.items[i2].tokens.filter((t2) => t2.type === "space");
            const hasMultipleLineBreaks = spacers.length > 0 && spacers.some((t2) => /\n.*\n/.test(t2.raw));
            list.loose = hasMultipleLineBreaks;
          }
        }
        if (list.loose) {
          for (i2 = 0; i2 < l; i2++) {
            list.items[i2].loose = true;
          }
        }
        return list;
      }
    }
    html(src) {
      const cap = this.rules.block.html.exec(src);
      if (cap) {
        const token = {
          type: "html",
          raw: cap[0],
          pre: !this.options.sanitizer && (cap[1] === "pre" || cap[1] === "script" || cap[1] === "style"),
          text: cap[0]
        };
        if (this.options.sanitize) {
          const text = this.options.sanitizer ? this.options.sanitizer(cap[0]) : escape2(cap[0]);
          token.type = "paragraph";
          token.text = text;
          token.tokens = this.lexer.inline(text);
        }
        return token;
      }
    }
    def(src) {
      const cap = this.rules.block.def.exec(src);
      if (cap) {
        const tag = cap[1].toLowerCase().replace(/\s+/g, " ");
        const href = cap[2] ? cap[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline._escapes, "$1") : "";
        const title = cap[3] ? cap[3].substring(1, cap[3].length - 1).replace(this.rules.inline._escapes, "$1") : cap[3];
        return {
          type: "def",
          tag,
          raw: cap[0],
          href,
          title
        };
      }
    }
    table(src) {
      const cap = this.rules.block.table.exec(src);
      if (cap) {
        const item = {
          type: "table",
          header: splitCells(cap[1]).map((c2) => {
            return { text: c2 };
          }),
          align: cap[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
          rows: cap[3] && cap[3].trim() ? cap[3].replace(/\n[ \t]*$/, "").split("\n") : []
        };
        if (item.header.length === item.align.length) {
          item.raw = cap[0];
          let l = item.align.length;
          let i2, j, k2, row;
          for (i2 = 0; i2 < l; i2++) {
            if (/^ *-+: *$/.test(item.align[i2])) {
              item.align[i2] = "right";
            } else if (/^ *:-+: *$/.test(item.align[i2])) {
              item.align[i2] = "center";
            } else if (/^ *:-+ *$/.test(item.align[i2])) {
              item.align[i2] = "left";
            } else {
              item.align[i2] = null;
            }
          }
          l = item.rows.length;
          for (i2 = 0; i2 < l; i2++) {
            item.rows[i2] = splitCells(item.rows[i2], item.header.length).map((c2) => {
              return { text: c2 };
            });
          }
          l = item.header.length;
          for (j = 0; j < l; j++) {
            item.header[j].tokens = this.lexer.inline(item.header[j].text);
          }
          l = item.rows.length;
          for (j = 0; j < l; j++) {
            row = item.rows[j];
            for (k2 = 0; k2 < row.length; k2++) {
              row[k2].tokens = this.lexer.inline(row[k2].text);
            }
          }
          return item;
        }
      }
    }
    lheading(src) {
      const cap = this.rules.block.lheading.exec(src);
      if (cap) {
        return {
          type: "heading",
          raw: cap[0],
          depth: cap[2].charAt(0) === "=" ? 1 : 2,
          text: cap[1],
          tokens: this.lexer.inline(cap[1])
        };
      }
    }
    paragraph(src) {
      const cap = this.rules.block.paragraph.exec(src);
      if (cap) {
        const text = cap[1].charAt(cap[1].length - 1) === "\n" ? cap[1].slice(0, -1) : cap[1];
        return {
          type: "paragraph",
          raw: cap[0],
          text,
          tokens: this.lexer.inline(text)
        };
      }
    }
    text(src) {
      const cap = this.rules.block.text.exec(src);
      if (cap) {
        return {
          type: "text",
          raw: cap[0],
          text: cap[0],
          tokens: this.lexer.inline(cap[0])
        };
      }
    }
    escape(src) {
      const cap = this.rules.inline.escape.exec(src);
      if (cap) {
        return {
          type: "escape",
          raw: cap[0],
          text: escape2(cap[1])
        };
      }
    }
    tag(src) {
      const cap = this.rules.inline.tag.exec(src);
      if (cap) {
        if (!this.lexer.state.inLink && /^<a /i.test(cap[0])) {
          this.lexer.state.inLink = true;
        } else if (this.lexer.state.inLink && /^<\/a>/i.test(cap[0])) {
          this.lexer.state.inLink = false;
        }
        if (!this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(cap[0])) {
          this.lexer.state.inRawBlock = true;
        } else if (this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(cap[0])) {
          this.lexer.state.inRawBlock = false;
        }
        return {
          type: this.options.sanitize ? "text" : "html",
          raw: cap[0],
          inLink: this.lexer.state.inLink,
          inRawBlock: this.lexer.state.inRawBlock,
          text: this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(cap[0]) : escape2(cap[0]) : cap[0]
        };
      }
    }
    link(src) {
      const cap = this.rules.inline.link.exec(src);
      if (cap) {
        const trimmedUrl = cap[2].trim();
        if (!this.options.pedantic && /^</.test(trimmedUrl)) {
          if (!/>$/.test(trimmedUrl)) {
            return;
          }
          const rtrimSlash = rtrim(trimmedUrl.slice(0, -1), "\\");
          if ((trimmedUrl.length - rtrimSlash.length) % 2 === 0) {
            return;
          }
        } else {
          const lastParenIndex = findClosingBracket(cap[2], "()");
          if (lastParenIndex > -1) {
            const start = cap[0].indexOf("!") === 0 ? 5 : 4;
            const linkLen = start + cap[1].length + lastParenIndex;
            cap[2] = cap[2].substring(0, lastParenIndex);
            cap[0] = cap[0].substring(0, linkLen).trim();
            cap[3] = "";
          }
        }
        let href = cap[2];
        let title = "";
        if (this.options.pedantic) {
          const link = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(href);
          if (link) {
            href = link[1];
            title = link[3];
          }
        } else {
          title = cap[3] ? cap[3].slice(1, -1) : "";
        }
        href = href.trim();
        if (/^</.test(href)) {
          if (this.options.pedantic && !/>$/.test(trimmedUrl)) {
            href = href.slice(1);
          } else {
            href = href.slice(1, -1);
          }
        }
        return outputLink(cap, {
          href: href ? href.replace(this.rules.inline._escapes, "$1") : href,
          title: title ? title.replace(this.rules.inline._escapes, "$1") : title
        }, cap[0], this.lexer);
      }
    }
    reflink(src, links) {
      let cap;
      if ((cap = this.rules.inline.reflink.exec(src)) || (cap = this.rules.inline.nolink.exec(src))) {
        let link = (cap[2] || cap[1]).replace(/\s+/g, " ");
        link = links[link.toLowerCase()];
        if (!link) {
          const text = cap[0].charAt(0);
          return {
            type: "text",
            raw: text,
            text
          };
        }
        return outputLink(cap, link, cap[0], this.lexer);
      }
    }
    emStrong(src, maskedSrc, prevChar = "") {
      let match2 = this.rules.inline.emStrong.lDelim.exec(src);
      if (!match2)
        return;
      if (match2[3] && prevChar.match(/[\p{L}\p{N}]/u))
        return;
      const nextChar = match2[1] || match2[2] || "";
      if (!nextChar || nextChar && (prevChar === "" || this.rules.inline.punctuation.exec(prevChar))) {
        const lLength = match2[0].length - 1;
        let rDelim, rLength, delimTotal = lLength, midDelimTotal = 0;
        const endReg = match2[0][0] === "*" ? this.rules.inline.emStrong.rDelimAst : this.rules.inline.emStrong.rDelimUnd;
        endReg.lastIndex = 0;
        maskedSrc = maskedSrc.slice(-1 * src.length + lLength);
        while ((match2 = endReg.exec(maskedSrc)) != null) {
          rDelim = match2[1] || match2[2] || match2[3] || match2[4] || match2[5] || match2[6];
          if (!rDelim)
            continue;
          rLength = rDelim.length;
          if (match2[3] || match2[4]) {
            delimTotal += rLength;
            continue;
          } else if (match2[5] || match2[6]) {
            if (lLength % 3 && !((lLength + rLength) % 3)) {
              midDelimTotal += rLength;
              continue;
            }
          }
          delimTotal -= rLength;
          if (delimTotal > 0)
            continue;
          rLength = Math.min(rLength, rLength + delimTotal + midDelimTotal);
          const raw2 = src.slice(0, lLength + match2.index + (match2[0].length - rDelim.length) + rLength);
          if (Math.min(lLength, rLength) % 2) {
            const text2 = raw2.slice(1, -1);
            return {
              type: "em",
              raw: raw2,
              text: text2,
              tokens: this.lexer.inlineTokens(text2)
            };
          }
          const text = raw2.slice(2, -2);
          return {
            type: "strong",
            raw: raw2,
            text,
            tokens: this.lexer.inlineTokens(text)
          };
        }
      }
    }
    codespan(src) {
      const cap = this.rules.inline.code.exec(src);
      if (cap) {
        let text = cap[2].replace(/\n/g, " ");
        const hasNonSpaceChars = /[^ ]/.test(text);
        const hasSpaceCharsOnBothEnds = /^ /.test(text) && / $/.test(text);
        if (hasNonSpaceChars && hasSpaceCharsOnBothEnds) {
          text = text.substring(1, text.length - 1);
        }
        text = escape2(text, true);
        return {
          type: "codespan",
          raw: cap[0],
          text
        };
      }
    }
    br(src) {
      const cap = this.rules.inline.br.exec(src);
      if (cap) {
        return {
          type: "br",
          raw: cap[0]
        };
      }
    }
    del(src) {
      const cap = this.rules.inline.del.exec(src);
      if (cap) {
        return {
          type: "del",
          raw: cap[0],
          text: cap[2],
          tokens: this.lexer.inlineTokens(cap[2])
        };
      }
    }
    autolink(src, mangle2) {
      const cap = this.rules.inline.autolink.exec(src);
      if (cap) {
        let text, href;
        if (cap[2] === "@") {
          text = escape2(this.options.mangle ? mangle2(cap[1]) : cap[1]);
          href = "mailto:" + text;
        } else {
          text = escape2(cap[1]);
          href = text;
        }
        return {
          type: "link",
          raw: cap[0],
          text,
          href,
          tokens: [
            {
              type: "text",
              raw: text,
              text
            }
          ]
        };
      }
    }
    url(src, mangle2) {
      let cap;
      if (cap = this.rules.inline.url.exec(src)) {
        let text, href;
        if (cap[2] === "@") {
          text = escape2(this.options.mangle ? mangle2(cap[0]) : cap[0]);
          href = "mailto:" + text;
        } else {
          let prevCapZero;
          do {
            prevCapZero = cap[0];
            cap[0] = this.rules.inline._backpedal.exec(cap[0])[0];
          } while (prevCapZero !== cap[0]);
          text = escape2(cap[0]);
          if (cap[1] === "www.") {
            href = "http://" + cap[0];
          } else {
            href = cap[0];
          }
        }
        return {
          type: "link",
          raw: cap[0],
          text,
          href,
          tokens: [
            {
              type: "text",
              raw: text,
              text
            }
          ]
        };
      }
    }
    inlineText(src, smartypants2) {
      const cap = this.rules.inline.text.exec(src);
      if (cap) {
        let text;
        if (this.lexer.state.inRawBlock) {
          text = this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(cap[0]) : escape2(cap[0]) : cap[0];
        } else {
          text = escape2(this.options.smartypants ? smartypants2(cap[0]) : cap[0]);
        }
        return {
          type: "text",
          raw: cap[0],
          text
        };
      }
    }
  };
  var block = {
    newline: /^(?: *(?:\n|$))+/,
    code: /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,
    fences: /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
    hr: /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
    heading: /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
    blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
    list: /^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/,
    html: "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",
    def: /^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,
    table: noopTest,
    lheading: /^((?:.|\n(?!\n))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    // regex template, placeholders will be replaced according to different paragraph
    // interruption rules of commonmark and the original markdown spec:
    _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,
    text: /^[^\n]+/
  };
  block._label = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
  block._title = /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/;
  block.def = edit(block.def).replace("label", block._label).replace("title", block._title).getRegex();
  block.bullet = /(?:[*+-]|\d{1,9}[.)])/;
  block.listItemStart = edit(/^( *)(bull) */).replace("bull", block.bullet).getRegex();
  block.list = edit(block.list).replace(/bull/g, block.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def", "\\n+(?=" + block.def.source + ")").getRegex();
  block._tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
  block._comment = /<!--(?!-?>)[\s\S]*?(?:-->|$)/;
  block.html = edit(block.html, "i").replace("comment", block._comment).replace("tag", block._tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
  block.paragraph = edit(block._paragraph).replace("hr", block.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", block._tag).getRegex();
  block.blockquote = edit(block.blockquote).replace("paragraph", block.paragraph).getRegex();
  block.normal = { ...block };
  block.gfm = {
    ...block.normal,
    table: "^ *([^\\n ].*\\|.*)\\n {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
    // Cells
  };
  block.gfm.table = edit(block.gfm.table).replace("hr", block.hr).replace("heading", " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", block._tag).getRegex();
  block.gfm.paragraph = edit(block._paragraph).replace("hr", block.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("table", block.gfm.table).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", block._tag).getRegex();
  block.pedantic = {
    ...block.normal,
    html: edit(
      `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
    ).replace("comment", block._comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
    heading: /^(#{1,6})(.*)(?:\n+|$)/,
    fences: noopTest,
    // fences not supported
    lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    paragraph: edit(block.normal._paragraph).replace("hr", block.hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", block.lheading).replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").getRegex()
  };
  var inline = {
    escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
    autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
    url: noopTest,
    tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
    // CDATA section
    link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
    reflink: /^!?\[(label)\]\[(ref)\]/,
    nolink: /^!?\[(ref)\](?:\[\])?/,
    reflinkSearch: "reflink|nolink(?!\\()",
    emStrong: {
      lDelim: /^(?:\*+(?:([punct_])|[^\s*]))|^_+(?:([punct*])|([^\s_]))/,
      //        (1) and (2) can only be a Right Delimiter. (3) and (4) can only be Left.  (5) and (6) can be either Left or Right.
      //          () Skip orphan inside strong                                      () Consume to delim     (1) #***                (2) a***#, a***                             (3) #***a, ***a                 (4) ***#              (5) #***#                 (6) a***a
      rDelimAst: /^(?:[^_*\\]|\\.)*?\_\_(?:[^_*\\]|\\.)*?\*(?:[^_*\\]|\\.)*?(?=\_\_)|(?:[^*\\]|\\.)+(?=[^*])|[punct_](\*+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\*+)(?=[punct_\s]|$)|[punct_\s](\*+)(?=[^punct*_\s])|[\s](\*+)(?=[punct_])|[punct_](\*+)(?=[punct_])|(?:[^punct*_\s\\]|\\.)(\*+)(?=[^punct*_\s])/,
      rDelimUnd: /^(?:[^_*\\]|\\.)*?\*\*(?:[^_*\\]|\\.)*?\_(?:[^_*\\]|\\.)*?(?=\*\*)|(?:[^_\\]|\\.)+(?=[^_])|[punct*](\_+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\_+)(?=[punct*\s]|$)|[punct*\s](\_+)(?=[^punct*_\s])|[\s](\_+)(?=[punct*])|[punct*](\_+)(?=[punct*])/
      // ^- Not allowed for _
    },
    code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
    br: /^( {2,}|\\)\n(?!\s*$)/,
    del: noopTest,
    text: /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
    punctuation: /^([\spunctuation])/
  };
  inline._punctuation = "!\"#$%&'()+\\-.,/:;<=>?@\\[\\]`^{|}~";
  inline.punctuation = edit(inline.punctuation).replace(/punctuation/g, inline._punctuation).getRegex();
  inline.blockSkip = /\[[^\]]*?\]\([^\)]*?\)|`[^`]*?`|<[^>]*?>/g;
  inline.escapedEmSt = /(?:^|[^\\])(?:\\\\)*\\[*_]/g;
  inline._comment = edit(block._comment).replace("(?:-->|$)", "-->").getRegex();
  inline.emStrong.lDelim = edit(inline.emStrong.lDelim).replace(/punct/g, inline._punctuation).getRegex();
  inline.emStrong.rDelimAst = edit(inline.emStrong.rDelimAst, "g").replace(/punct/g, inline._punctuation).getRegex();
  inline.emStrong.rDelimUnd = edit(inline.emStrong.rDelimUnd, "g").replace(/punct/g, inline._punctuation).getRegex();
  inline._escapes = /\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g;
  inline._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/;
  inline._email = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/;
  inline.autolink = edit(inline.autolink).replace("scheme", inline._scheme).replace("email", inline._email).getRegex();
  inline._attribute = /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/;
  inline.tag = edit(inline.tag).replace("comment", inline._comment).replace("attribute", inline._attribute).getRegex();
  inline._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
  inline._href = /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/;
  inline._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/;
  inline.link = edit(inline.link).replace("label", inline._label).replace("href", inline._href).replace("title", inline._title).getRegex();
  inline.reflink = edit(inline.reflink).replace("label", inline._label).replace("ref", block._label).getRegex();
  inline.nolink = edit(inline.nolink).replace("ref", block._label).getRegex();
  inline.reflinkSearch = edit(inline.reflinkSearch, "g").replace("reflink", inline.reflink).replace("nolink", inline.nolink).getRegex();
  inline.normal = { ...inline };
  inline.pedantic = {
    ...inline.normal,
    strong: {
      start: /^__|\*\*/,
      middle: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
      endAst: /\*\*(?!\*)/g,
      endUnd: /__(?!_)/g
    },
    em: {
      start: /^_|\*/,
      middle: /^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,
      endAst: /\*(?!\*)/g,
      endUnd: /_(?!_)/g
    },
    link: edit(/^!?\[(label)\]\((.*?)\)/).replace("label", inline._label).getRegex(),
    reflink: edit(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", inline._label).getRegex()
  };
  inline.gfm = {
    ...inline.normal,
    escape: edit(inline.escape).replace("])", "~|])").getRegex(),
    _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
    url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
    _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
    del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
    text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
  };
  inline.gfm.url = edit(inline.gfm.url, "i").replace("email", inline.gfm._extended_email).getRegex();
  inline.breaks = {
    ...inline.gfm,
    br: edit(inline.br).replace("{2,}", "*").getRegex(),
    text: edit(inline.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
  };
  function smartypants(text) {
    return text.replace(/---/g, "\u2014").replace(/--/g, "\u2013").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1\u2018").replace(/'/g, "\u2019").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1\u201C").replace(/"/g, "\u201D").replace(/\.{3}/g, "\u2026");
  }
  function mangle(text) {
    let out = "", i2, ch;
    const l = text.length;
    for (i2 = 0; i2 < l; i2++) {
      ch = text.charCodeAt(i2);
      if (Math.random() > 0.5) {
        ch = "x" + ch.toString(16);
      }
      out += "&#" + ch + ";";
    }
    return out;
  }
  var Lexer = class {
    constructor(options2) {
      this.tokens = [];
      this.tokens.links = /* @__PURE__ */ Object.create(null);
      this.options = options2 || defaults;
      this.options.tokenizer = this.options.tokenizer || new Tokenizer2();
      this.tokenizer = this.options.tokenizer;
      this.tokenizer.options = this.options;
      this.tokenizer.lexer = this;
      this.inlineQueue = [];
      this.state = {
        inLink: false,
        inRawBlock: false,
        top: true
      };
      const rules = {
        block: block.normal,
        inline: inline.normal
      };
      if (this.options.pedantic) {
        rules.block = block.pedantic;
        rules.inline = inline.pedantic;
      } else if (this.options.gfm) {
        rules.block = block.gfm;
        if (this.options.breaks) {
          rules.inline = inline.breaks;
        } else {
          rules.inline = inline.gfm;
        }
      }
      this.tokenizer.rules = rules;
    }
    /**
     * Expose Rules
     */
    static get rules() {
      return {
        block,
        inline
      };
    }
    /**
     * Static Lex Method
     */
    static lex(src, options2) {
      const lexer2 = new Lexer(options2);
      return lexer2.lex(src);
    }
    /**
     * Static Lex Inline Method
     */
    static lexInline(src, options2) {
      const lexer2 = new Lexer(options2);
      return lexer2.inlineTokens(src);
    }
    /**
     * Preprocessing
     */
    lex(src) {
      src = src.replace(/\r\n|\r/g, "\n");
      this.blockTokens(src, this.tokens);
      let next;
      while (next = this.inlineQueue.shift()) {
        this.inlineTokens(next.src, next.tokens);
      }
      return this.tokens;
    }
    /**
     * Lexing
     */
    blockTokens(src, tokens = []) {
      if (this.options.pedantic) {
        src = src.replace(/\t/g, "    ").replace(/^ +$/gm, "");
      } else {
        src = src.replace(/^( *)(\t+)/gm, (_, leading, tabs) => {
          return leading + "    ".repeat(tabs.length);
        });
      }
      let token, lastToken, cutSrc, lastParagraphClipped;
      while (src) {
        if (this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((extTokenizer) => {
          if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
            src = src.substring(token.raw.length);
            tokens.push(token);
            return true;
          }
          return false;
        })) {
          continue;
        }
        if (token = this.tokenizer.space(src)) {
          src = src.substring(token.raw.length);
          if (token.raw.length === 1 && tokens.length > 0) {
            tokens[tokens.length - 1].raw += "\n";
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.code(src)) {
          src = src.substring(token.raw.length);
          lastToken = tokens[tokens.length - 1];
          if (lastToken && (lastToken.type === "paragraph" || lastToken.type === "text")) {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.fences(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.heading(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.hr(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.blockquote(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.list(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.html(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.def(src)) {
          src = src.substring(token.raw.length);
          lastToken = tokens[tokens.length - 1];
          if (lastToken && (lastToken.type === "paragraph" || lastToken.type === "text")) {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.raw;
            this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
          } else if (!this.tokens.links[token.tag]) {
            this.tokens.links[token.tag] = {
              href: token.href,
              title: token.title
            };
          }
          continue;
        }
        if (token = this.tokenizer.table(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.lheading(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        cutSrc = src;
        if (this.options.extensions && this.options.extensions.startBlock) {
          let startIndex = Infinity;
          const tempSrc = src.slice(1);
          let tempStart;
          this.options.extensions.startBlock.forEach(function(getStartIndex) {
            tempStart = getStartIndex.call({ lexer: this }, tempSrc);
            if (typeof tempStart === "number" && tempStart >= 0) {
              startIndex = Math.min(startIndex, tempStart);
            }
          });
          if (startIndex < Infinity && startIndex >= 0) {
            cutSrc = src.substring(0, startIndex + 1);
          }
        }
        if (this.state.top && (token = this.tokenizer.paragraph(cutSrc))) {
          lastToken = tokens[tokens.length - 1];
          if (lastParagraphClipped && lastToken.type === "paragraph") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue.pop();
            this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
          } else {
            tokens.push(token);
          }
          lastParagraphClipped = cutSrc.length !== src.length;
          src = src.substring(token.raw.length);
          continue;
        }
        if (token = this.tokenizer.text(src)) {
          src = src.substring(token.raw.length);
          lastToken = tokens[tokens.length - 1];
          if (lastToken && lastToken.type === "text") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue.pop();
            this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (src) {
          const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
          if (this.options.silent) {
            console.error(errMsg);
            break;
          } else {
            throw new Error(errMsg);
          }
        }
      }
      this.state.top = true;
      return tokens;
    }
    inline(src, tokens = []) {
      this.inlineQueue.push({ src, tokens });
      return tokens;
    }
    /**
     * Lexing/Compiling
     */
    inlineTokens(src, tokens = []) {
      let token, lastToken, cutSrc;
      let maskedSrc = src;
      let match2;
      let keepPrevChar, prevChar;
      if (this.tokens.links) {
        const links = Object.keys(this.tokens.links);
        if (links.length > 0) {
          while ((match2 = this.tokenizer.rules.inline.reflinkSearch.exec(maskedSrc)) != null) {
            if (links.includes(match2[0].slice(match2[0].lastIndexOf("[") + 1, -1))) {
              maskedSrc = maskedSrc.slice(0, match2.index) + "[" + repeatString("a", match2[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex);
            }
          }
        }
      }
      while ((match2 = this.tokenizer.rules.inline.blockSkip.exec(maskedSrc)) != null) {
        maskedSrc = maskedSrc.slice(0, match2.index) + "[" + repeatString("a", match2[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
      }
      while ((match2 = this.tokenizer.rules.inline.escapedEmSt.exec(maskedSrc)) != null) {
        maskedSrc = maskedSrc.slice(0, match2.index + match2[0].length - 2) + "++" + maskedSrc.slice(this.tokenizer.rules.inline.escapedEmSt.lastIndex);
        this.tokenizer.rules.inline.escapedEmSt.lastIndex--;
      }
      while (src) {
        if (!keepPrevChar) {
          prevChar = "";
        }
        keepPrevChar = false;
        if (this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((extTokenizer) => {
          if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
            src = src.substring(token.raw.length);
            tokens.push(token);
            return true;
          }
          return false;
        })) {
          continue;
        }
        if (token = this.tokenizer.escape(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.tag(src)) {
          src = src.substring(token.raw.length);
          lastToken = tokens[tokens.length - 1];
          if (lastToken && token.type === "text" && lastToken.type === "text") {
            lastToken.raw += token.raw;
            lastToken.text += token.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.link(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.reflink(src, this.tokens.links)) {
          src = src.substring(token.raw.length);
          lastToken = tokens[tokens.length - 1];
          if (lastToken && token.type === "text" && lastToken.type === "text") {
            lastToken.raw += token.raw;
            lastToken.text += token.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.emStrong(src, maskedSrc, prevChar)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.codespan(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.br(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.del(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.autolink(src, mangle)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (!this.state.inLink && (token = this.tokenizer.url(src, mangle))) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        cutSrc = src;
        if (this.options.extensions && this.options.extensions.startInline) {
          let startIndex = Infinity;
          const tempSrc = src.slice(1);
          let tempStart;
          this.options.extensions.startInline.forEach(function(getStartIndex) {
            tempStart = getStartIndex.call({ lexer: this }, tempSrc);
            if (typeof tempStart === "number" && tempStart >= 0) {
              startIndex = Math.min(startIndex, tempStart);
            }
          });
          if (startIndex < Infinity && startIndex >= 0) {
            cutSrc = src.substring(0, startIndex + 1);
          }
        }
        if (token = this.tokenizer.inlineText(cutSrc, smartypants)) {
          src = src.substring(token.raw.length);
          if (token.raw.slice(-1) !== "_") {
            prevChar = token.raw.slice(-1);
          }
          keepPrevChar = true;
          lastToken = tokens[tokens.length - 1];
          if (lastToken && lastToken.type === "text") {
            lastToken.raw += token.raw;
            lastToken.text += token.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (src) {
          const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
          if (this.options.silent) {
            console.error(errMsg);
            break;
          } else {
            throw new Error(errMsg);
          }
        }
      }
      return tokens;
    }
  };
  var Renderer = class {
    constructor(options2) {
      this.options = options2 || defaults;
    }
    code(code, infostring, escaped) {
      const lang = (infostring || "").match(/\S*/)[0];
      if (this.options.highlight) {
        const out = this.options.highlight(code, lang);
        if (out != null && out !== code) {
          escaped = true;
          code = out;
        }
      }
      code = code.replace(/\n$/, "") + "\n";
      if (!lang) {
        return "<pre><code>" + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
      }
      return '<pre><code class="' + this.options.langPrefix + escape2(lang) + '">' + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
    }
    /**
     * @param {string} quote
     */
    blockquote(quote) {
      return `<blockquote>
${quote}</blockquote>
`;
    }
    html(html) {
      return html;
    }
    /**
     * @param {string} text
     * @param {string} level
     * @param {string} raw
     * @param {any} slugger
     */
    heading(text, level, raw2, slugger) {
      if (this.options.headerIds) {
        const id = this.options.headerPrefix + slugger.slug(raw2);
        return `<h${level} id="${id}">${text}</h${level}>
`;
      }
      return `<h${level}>${text}</h${level}>
`;
    }
    hr() {
      return this.options.xhtml ? "<hr/>\n" : "<hr>\n";
    }
    list(body, ordered, start) {
      const type = ordered ? "ol" : "ul", startatt = ordered && start !== 1 ? ' start="' + start + '"' : "";
      return "<" + type + startatt + ">\n" + body + "</" + type + ">\n";
    }
    /**
     * @param {string} text
     */
    listitem(text) {
      return `<li>${text}</li>
`;
    }
    checkbox(checked) {
      return "<input " + (checked ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> ";
    }
    /**
     * @param {string} text
     */
    paragraph(text) {
      return `<p>${text}</p>
`;
    }
    /**
     * @param {string} header
     * @param {string} body
     */
    table(header, body) {
      if (body)
        body = `<tbody>${body}</tbody>`;
      return "<table>\n<thead>\n" + header + "</thead>\n" + body + "</table>\n";
    }
    /**
     * @param {string} content
     */
    tablerow(content) {
      return `<tr>
${content}</tr>
`;
    }
    tablecell(content, flags) {
      const type = flags.header ? "th" : "td";
      const tag = flags.align ? `<${type} align="${flags.align}">` : `<${type}>`;
      return tag + content + `</${type}>
`;
    }
    /**
     * span level renderer
     * @param {string} text
     */
    strong(text) {
      return `<strong>${text}</strong>`;
    }
    /**
     * @param {string} text
     */
    em(text) {
      return `<em>${text}</em>`;
    }
    /**
     * @param {string} text
     */
    codespan(text) {
      return `<code>${text}</code>`;
    }
    br() {
      return this.options.xhtml ? "<br/>" : "<br>";
    }
    /**
     * @param {string} text
     */
    del(text) {
      return `<del>${text}</del>`;
    }
    /**
     * @param {string} href
     * @param {string} title
     * @param {string} text
     */
    link(href, title, text) {
      href = cleanUrl(this.options.sanitize, this.options.baseUrl, href);
      if (href === null) {
        return text;
      }
      let out = '<a href="' + href + '"';
      if (title) {
        out += ' title="' + title + '"';
      }
      out += ">" + text + "</a>";
      return out;
    }
    /**
     * @param {string} href
     * @param {string} title
     * @param {string} text
     */
    image(href, title, text) {
      href = cleanUrl(this.options.sanitize, this.options.baseUrl, href);
      if (href === null) {
        return text;
      }
      let out = `<img src="${href}" alt="${text}"`;
      if (title) {
        out += ` title="${title}"`;
      }
      out += this.options.xhtml ? "/>" : ">";
      return out;
    }
    text(text) {
      return text;
    }
  };
  var TextRenderer = class {
    // no need for block level renderers
    strong(text) {
      return text;
    }
    em(text) {
      return text;
    }
    codespan(text) {
      return text;
    }
    del(text) {
      return text;
    }
    html(text) {
      return text;
    }
    text(text) {
      return text;
    }
    link(href, title, text) {
      return "" + text;
    }
    image(href, title, text) {
      return "" + text;
    }
    br() {
      return "";
    }
  };
  var Slugger = class {
    constructor() {
      this.seen = {};
    }
    /**
     * @param {string} value
     */
    serialize(value) {
      return value.toLowerCase().trim().replace(/<[!\/a-z].*?>/ig, "").replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-");
    }
    /**
     * Finds the next safe (unique) slug to use
     * @param {string} originalSlug
     * @param {boolean} isDryRun
     */
    getNextSafeSlug(originalSlug, isDryRun) {
      let slug = originalSlug;
      let occurenceAccumulator = 0;
      if (this.seen.hasOwnProperty(slug)) {
        occurenceAccumulator = this.seen[originalSlug];
        do {
          occurenceAccumulator++;
          slug = originalSlug + "-" + occurenceAccumulator;
        } while (this.seen.hasOwnProperty(slug));
      }
      if (!isDryRun) {
        this.seen[originalSlug] = occurenceAccumulator;
        this.seen[slug] = 0;
      }
      return slug;
    }
    /**
     * Convert string to unique id
     * @param {object} [options]
     * @param {boolean} [options.dryrun] Generates the next unique slug without
     * updating the internal accumulator.
     */
    slug(value, options2 = {}) {
      const slug = this.serialize(value);
      return this.getNextSafeSlug(slug, options2.dryrun);
    }
  };
  var Parser2 = class {
    constructor(options2) {
      this.options = options2 || defaults;
      this.options.renderer = this.options.renderer || new Renderer();
      this.renderer = this.options.renderer;
      this.renderer.options = this.options;
      this.textRenderer = new TextRenderer();
      this.slugger = new Slugger();
    }
    /**
     * Static Parse Method
     */
    static parse(tokens, options2) {
      const parser2 = new Parser2(options2);
      return parser2.parse(tokens);
    }
    /**
     * Static Parse Inline Method
     */
    static parseInline(tokens, options2) {
      const parser2 = new Parser2(options2);
      return parser2.parseInline(tokens);
    }
    /**
     * Parse Loop
     */
    parse(tokens, top = true) {
      let out = "", i2, j, k2, l2, l3, row, cell, header, body, token, ordered, start, loose, itemBody, item, checked, task, checkbox, ret;
      const l = tokens.length;
      for (i2 = 0; i2 < l; i2++) {
        token = tokens[i2];
        if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[token.type]) {
          ret = this.options.extensions.renderers[token.type].call({ parser: this }, token);
          if (ret !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(token.type)) {
            out += ret || "";
            continue;
          }
        }
        switch (token.type) {
          case "space": {
            continue;
          }
          case "hr": {
            out += this.renderer.hr();
            continue;
          }
          case "heading": {
            out += this.renderer.heading(
              this.parseInline(token.tokens),
              token.depth,
              unescape2(this.parseInline(token.tokens, this.textRenderer)),
              this.slugger
            );
            continue;
          }
          case "code": {
            out += this.renderer.code(
              token.text,
              token.lang,
              token.escaped
            );
            continue;
          }
          case "table": {
            header = "";
            cell = "";
            l2 = token.header.length;
            for (j = 0; j < l2; j++) {
              cell += this.renderer.tablecell(
                this.parseInline(token.header[j].tokens),
                { header: true, align: token.align[j] }
              );
            }
            header += this.renderer.tablerow(cell);
            body = "";
            l2 = token.rows.length;
            for (j = 0; j < l2; j++) {
              row = token.rows[j];
              cell = "";
              l3 = row.length;
              for (k2 = 0; k2 < l3; k2++) {
                cell += this.renderer.tablecell(
                  this.parseInline(row[k2].tokens),
                  { header: false, align: token.align[k2] }
                );
              }
              body += this.renderer.tablerow(cell);
            }
            out += this.renderer.table(header, body);
            continue;
          }
          case "blockquote": {
            body = this.parse(token.tokens);
            out += this.renderer.blockquote(body);
            continue;
          }
          case "list": {
            ordered = token.ordered;
            start = token.start;
            loose = token.loose;
            l2 = token.items.length;
            body = "";
            for (j = 0; j < l2; j++) {
              item = token.items[j];
              checked = item.checked;
              task = item.task;
              itemBody = "";
              if (item.task) {
                checkbox = this.renderer.checkbox(checked);
                if (loose) {
                  if (item.tokens.length > 0 && item.tokens[0].type === "paragraph") {
                    item.tokens[0].text = checkbox + " " + item.tokens[0].text;
                    if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
                      item.tokens[0].tokens[0].text = checkbox + " " + item.tokens[0].tokens[0].text;
                    }
                  } else {
                    item.tokens.unshift({
                      type: "text",
                      text: checkbox
                    });
                  }
                } else {
                  itemBody += checkbox;
                }
              }
              itemBody += this.parse(item.tokens, loose);
              body += this.renderer.listitem(itemBody, task, checked);
            }
            out += this.renderer.list(body, ordered, start);
            continue;
          }
          case "html": {
            out += this.renderer.html(token.text);
            continue;
          }
          case "paragraph": {
            out += this.renderer.paragraph(this.parseInline(token.tokens));
            continue;
          }
          case "text": {
            body = token.tokens ? this.parseInline(token.tokens) : token.text;
            while (i2 + 1 < l && tokens[i2 + 1].type === "text") {
              token = tokens[++i2];
              body += "\n" + (token.tokens ? this.parseInline(token.tokens) : token.text);
            }
            out += top ? this.renderer.paragraph(body) : body;
            continue;
          }
          default: {
            const errMsg = 'Token with "' + token.type + '" type was not found.';
            if (this.options.silent) {
              console.error(errMsg);
              return;
            } else {
              throw new Error(errMsg);
            }
          }
        }
      }
      return out;
    }
    /**
     * Parse Inline Tokens
     */
    parseInline(tokens, renderer) {
      renderer = renderer || this.renderer;
      let out = "", i2, token, ret;
      const l = tokens.length;
      for (i2 = 0; i2 < l; i2++) {
        token = tokens[i2];
        if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[token.type]) {
          ret = this.options.extensions.renderers[token.type].call({ parser: this }, token);
          if (ret !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(token.type)) {
            out += ret || "";
            continue;
          }
        }
        switch (token.type) {
          case "escape": {
            out += renderer.text(token.text);
            break;
          }
          case "html": {
            out += renderer.html(token.text);
            break;
          }
          case "link": {
            out += renderer.link(token.href, token.title, this.parseInline(token.tokens, renderer));
            break;
          }
          case "image": {
            out += renderer.image(token.href, token.title, token.text);
            break;
          }
          case "strong": {
            out += renderer.strong(this.parseInline(token.tokens, renderer));
            break;
          }
          case "em": {
            out += renderer.em(this.parseInline(token.tokens, renderer));
            break;
          }
          case "codespan": {
            out += renderer.codespan(token.text);
            break;
          }
          case "br": {
            out += renderer.br();
            break;
          }
          case "del": {
            out += renderer.del(this.parseInline(token.tokens, renderer));
            break;
          }
          case "text": {
            out += renderer.text(token.text);
            break;
          }
          default: {
            const errMsg = 'Token with "' + token.type + '" type was not found.';
            if (this.options.silent) {
              console.error(errMsg);
              return;
            } else {
              throw new Error(errMsg);
            }
          }
        }
      }
      return out;
    }
  };
  var Hooks = class {
    constructor(options2) {
      this.options = options2 || defaults;
    }
    /**
     * Process markdown before marked
     */
    preprocess(markdown) {
      return markdown;
    }
    /**
     * Process HTML after marked is finished
     */
    postprocess(html) {
      return html;
    }
  };
  __publicField(Hooks, "passThroughHooks", /* @__PURE__ */ new Set([
    "preprocess",
    "postprocess"
  ]));
  function onError(silent, async, callback) {
    return (e2) => {
      e2.message += "\nPlease report this to https://github.com/markedjs/marked.";
      if (silent) {
        const msg = "<p>An error occurred:</p><pre>" + escape2(e2.message + "", true) + "</pre>";
        if (async) {
          return Promise.resolve(msg);
        }
        if (callback) {
          callback(null, msg);
          return;
        }
        return msg;
      }
      if (async) {
        return Promise.reject(e2);
      }
      if (callback) {
        callback(e2);
        return;
      }
      throw e2;
    };
  }
  function parseMarkdown(lexer2, parser2) {
    return (src, opt, callback) => {
      if (typeof opt === "function") {
        callback = opt;
        opt = null;
      }
      const origOpt = { ...opt };
      opt = { ...marked.defaults, ...origOpt };
      const throwError = onError(opt.silent, opt.async, callback);
      if (typeof src === "undefined" || src === null) {
        return throwError(new Error("marked(): input parameter is undefined or null"));
      }
      if (typeof src !== "string") {
        return throwError(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(src) + ", string expected"));
      }
      checkSanitizeDeprecation(opt);
      if (opt.hooks) {
        opt.hooks.options = opt;
      }
      if (callback) {
        const highlight = opt.highlight;
        let tokens;
        try {
          if (opt.hooks) {
            src = opt.hooks.preprocess(src);
          }
          tokens = lexer2(src, opt);
        } catch (e2) {
          return throwError(e2);
        }
        const done = function(err) {
          let out;
          if (!err) {
            try {
              if (opt.walkTokens) {
                marked.walkTokens(tokens, opt.walkTokens);
              }
              out = parser2(tokens, opt);
              if (opt.hooks) {
                out = opt.hooks.postprocess(out);
              }
            } catch (e2) {
              err = e2;
            }
          }
          opt.highlight = highlight;
          return err ? throwError(err) : callback(null, out);
        };
        if (!highlight || highlight.length < 3) {
          return done();
        }
        delete opt.highlight;
        if (!tokens.length)
          return done();
        let pending = 0;
        marked.walkTokens(tokens, function(token) {
          if (token.type === "code") {
            pending++;
            setTimeout(() => {
              highlight(token.text, token.lang, function(err, code) {
                if (err) {
                  return done(err);
                }
                if (code != null && code !== token.text) {
                  token.text = code;
                  token.escaped = true;
                }
                pending--;
                if (pending === 0) {
                  done();
                }
              });
            }, 0);
          }
        });
        if (pending === 0) {
          done();
        }
        return;
      }
      if (opt.async) {
        return Promise.resolve(opt.hooks ? opt.hooks.preprocess(src) : src).then((src2) => lexer2(src2, opt)).then((tokens) => opt.walkTokens ? Promise.all(marked.walkTokens(tokens, opt.walkTokens)).then(() => tokens) : tokens).then((tokens) => parser2(tokens, opt)).then((html) => opt.hooks ? opt.hooks.postprocess(html) : html).catch(throwError);
      }
      try {
        if (opt.hooks) {
          src = opt.hooks.preprocess(src);
        }
        const tokens = lexer2(src, opt);
        if (opt.walkTokens) {
          marked.walkTokens(tokens, opt.walkTokens);
        }
        let html = parser2(tokens, opt);
        if (opt.hooks) {
          html = opt.hooks.postprocess(html);
        }
        return html;
      } catch (e2) {
        return throwError(e2);
      }
    };
  }
  function marked(src, opt, callback) {
    return parseMarkdown(Lexer.lex, Parser2.parse)(src, opt, callback);
  }
  marked.options = marked.setOptions = function(opt) {
    marked.defaults = { ...marked.defaults, ...opt };
    changeDefaults(marked.defaults);
    return marked;
  };
  marked.getDefaults = getDefaults;
  marked.defaults = defaults;
  marked.use = function(...args) {
    const extensions = marked.defaults.extensions || { renderers: {}, childTokens: {} };
    args.forEach((pack) => {
      const opts = { ...pack };
      opts.async = marked.defaults.async || opts.async || false;
      if (pack.extensions) {
        pack.extensions.forEach((ext) => {
          if (!ext.name) {
            throw new Error("extension name required");
          }
          if (ext.renderer) {
            const prevRenderer = extensions.renderers[ext.name];
            if (prevRenderer) {
              extensions.renderers[ext.name] = function(...args2) {
                let ret = ext.renderer.apply(this, args2);
                if (ret === false) {
                  ret = prevRenderer.apply(this, args2);
                }
                return ret;
              };
            } else {
              extensions.renderers[ext.name] = ext.renderer;
            }
          }
          if (ext.tokenizer) {
            if (!ext.level || ext.level !== "block" && ext.level !== "inline") {
              throw new Error("extension level must be 'block' or 'inline'");
            }
            if (extensions[ext.level]) {
              extensions[ext.level].unshift(ext.tokenizer);
            } else {
              extensions[ext.level] = [ext.tokenizer];
            }
            if (ext.start) {
              if (ext.level === "block") {
                if (extensions.startBlock) {
                  extensions.startBlock.push(ext.start);
                } else {
                  extensions.startBlock = [ext.start];
                }
              } else if (ext.level === "inline") {
                if (extensions.startInline) {
                  extensions.startInline.push(ext.start);
                } else {
                  extensions.startInline = [ext.start];
                }
              }
            }
          }
          if (ext.childTokens) {
            extensions.childTokens[ext.name] = ext.childTokens;
          }
        });
        opts.extensions = extensions;
      }
      if (pack.renderer) {
        const renderer = marked.defaults.renderer || new Renderer();
        for (const prop in pack.renderer) {
          const prevRenderer = renderer[prop];
          renderer[prop] = (...args2) => {
            let ret = pack.renderer[prop].apply(renderer, args2);
            if (ret === false) {
              ret = prevRenderer.apply(renderer, args2);
            }
            return ret;
          };
        }
        opts.renderer = renderer;
      }
      if (pack.tokenizer) {
        const tokenizer = marked.defaults.tokenizer || new Tokenizer2();
        for (const prop in pack.tokenizer) {
          const prevTokenizer = tokenizer[prop];
          tokenizer[prop] = (...args2) => {
            let ret = pack.tokenizer[prop].apply(tokenizer, args2);
            if (ret === false) {
              ret = prevTokenizer.apply(tokenizer, args2);
            }
            return ret;
          };
        }
        opts.tokenizer = tokenizer;
      }
      if (pack.hooks) {
        const hooks = marked.defaults.hooks || new Hooks();
        for (const prop in pack.hooks) {
          const prevHook = hooks[prop];
          if (Hooks.passThroughHooks.has(prop)) {
            hooks[prop] = (arg) => {
              if (marked.defaults.async) {
                return Promise.resolve(pack.hooks[prop].call(hooks, arg)).then((ret2) => {
                  return prevHook.call(hooks, ret2);
                });
              }
              const ret = pack.hooks[prop].call(hooks, arg);
              return prevHook.call(hooks, ret);
            };
          } else {
            hooks[prop] = (...args2) => {
              let ret = pack.hooks[prop].apply(hooks, args2);
              if (ret === false) {
                ret = prevHook.apply(hooks, args2);
              }
              return ret;
            };
          }
        }
        opts.hooks = hooks;
      }
      if (pack.walkTokens) {
        const walkTokens2 = marked.defaults.walkTokens;
        opts.walkTokens = function(token) {
          let values = [];
          values.push(pack.walkTokens.call(this, token));
          if (walkTokens2) {
            values = values.concat(walkTokens2.call(this, token));
          }
          return values;
        };
      }
      marked.setOptions(opts);
    });
  };
  marked.walkTokens = function(tokens, callback) {
    let values = [];
    for (const token of tokens) {
      values = values.concat(callback.call(marked, token));
      switch (token.type) {
        case "table": {
          for (const cell of token.header) {
            values = values.concat(marked.walkTokens(cell.tokens, callback));
          }
          for (const row of token.rows) {
            for (const cell of row) {
              values = values.concat(marked.walkTokens(cell.tokens, callback));
            }
          }
          break;
        }
        case "list": {
          values = values.concat(marked.walkTokens(token.items, callback));
          break;
        }
        default: {
          if (marked.defaults.extensions && marked.defaults.extensions.childTokens && marked.defaults.extensions.childTokens[token.type]) {
            marked.defaults.extensions.childTokens[token.type].forEach(function(childTokens) {
              values = values.concat(marked.walkTokens(token[childTokens], callback));
            });
          } else if (token.tokens) {
            values = values.concat(marked.walkTokens(token.tokens, callback));
          }
        }
      }
    }
    return values;
  };
  marked.parseInline = parseMarkdown(Lexer.lexInline, Parser2.parseInline);
  marked.Parser = Parser2;
  marked.parser = Parser2.parse;
  marked.Renderer = Renderer;
  marked.TextRenderer = TextRenderer;
  marked.Lexer = Lexer;
  marked.lexer = Lexer.lex;
  marked.Tokenizer = Tokenizer2;
  marked.Slugger = Slugger;
  marked.Hooks = Hooks;
  marked.parse = marked;
  var options = marked.options;
  var setOptions = marked.setOptions;
  var use = marked.use;
  var walkTokens = marked.walkTokens;
  var parseInline = marked.parseInline;
  var parser = Parser2.parse;
  var lexer = Lexer.lex;

  // src/pages/logseq/client.ts
  var LogseqClientBase = class {
    constructor() {
      this.baseFetch = async (method, args) => {
        const config = await getLogseqCopliotConfig();
        const endPoint = new URL(config.logseqHost);
        const apiUrl = new URL(`${endPoint.origin}/api`);
        const resp = await fetch(apiUrl, {
          mode: "cors",
          method: "POST",
          headers: {
            Authorization: `Bearer ${config.logseqAuthToken}`,
            "Content-Type": "application/json; charset=utf-8"
          },
          body: JSON.stringify({
            method,
            args
          })
        });
        if (resp.status !== 200) {
          throw resp;
        }
        return resp;
      };
      this.baseJson = async (method, args) => {
        const resp = await this.baseFetch(method, args);
        const data = await resp.json();
        console.debug(`Logseq Method ${method}, Response -> 
`, data);
        return data;
      };
      this.isDBGraph = async () => {
        return await this.baseJson("check_current_is_db_graph", []);
      };
    }
  };

  // src/pages/logseq/error.ts
  var TokenNotCurrect = {
    msg: "Token not correct, Please checking your Logseq Authorization Setting.",
    status: 401,
    response: null
  };
  var LogseqVersionIsLower = {
    msg: "Logseq version is lower, Please upgrade your Logseq version.\nhttps://logseq.com/downloads",
    status: 500,
    response: null
  };
  var CannotConnectWithLogseq = {
    msg: "Cannot connect to Logseq, Please open your Logseq and config well.",
    status: 500,
    response: null
  };
  var NoSearchingResult = {
    msg: "Not found.",
    status: 404,
    response: null
  };
  var UnknownIssues = {
    msg: "Unknow issues, may you can connect with author.",
    status: 500,
    response: null
  };

  // src/pages/logseq/db/client.ts
  var LogseqClient = class extends LogseqClientBase {
    constructor() {
      super(...arguments);
      this.getCurrentGraph = async () => {
        return await this.baseJson("logseq.getCurrentGraph", []);
      };
      this.appendBlock = async (page, content) => {
        const resp = await this.baseJson("logseq.Editor.appendBlockInPage", [
          page,
          content
        ]);
        return resp;
      };
      this.getCurrentPage = async () => {
        return await this.catchIssues(async () => {
          return await this.baseJson("logseq.Editor.getCurrentPage", []);
        });
      };
      this.getAllPage = async () => {
        return await this.baseJson("logseq.Editor.getAllPages", []);
      };
      this.getPage = async (pageIdenity) => {
        const resp = await this.baseJson(
          "get_page",
          [pageIdenity.id || pageIdenity.uuid || pageIdenity.name]
        );
        return resp;
      };
      this.search = async (query) => {
        const resp = await this.baseJson("logseq.App.search", [query]);
        if (resp.error) {
          throw LogseqVersionIsLower;
        }
        return resp;
      };
      this.getBlockViaUuid = async (uuid, opt) => {
        return await this.baseJson("logseq.Editor.getBlock", [uuid, opt]);
      };
      this.isDBGraph = async () => {
        return await this.baseJson("logseq.checkCurrentIsDbGraph", []);
      };
      this.showMsgInternal = async (message) => {
        await this.baseFetch("logseq.App.showMsg", [message]);
        return {
          status: 200,
          msg: "success",
          response: null
        };
      };
      this.getVersionInternal = async () => {
        return await this.baseJson("logseq.App.getAppInfo", []);
      };
      this.find = async (query) => {
        const data = await this.baseJson("logseq.DB.q", [
          `"${query.replaceAll('"', '"')}"`
        ]);
        return data;
      };
      this.getUserConfig = async () => {
        return await this.catchIssues(
          async () => await this.baseJson("logseq.App.getUserConfigs", [])
        );
      };
      this.showMsg = async (message) => {
        return await this.catchIssues(
          async () => await this.showMsgInternal(message)
        );
      };
      this.getAllPages = async () => {
        return await this.catchIssues(async () => await this.getAllPage());
      };
      this.getGraph = async () => {
        return await this.catchIssues(async () => await this.getCurrentGraph());
      };
      this.getVersion = async () => {
        return await this.catchIssues(async () => await this.getVersionInternal());
      };
      this.updateBlock = async (block2) => {
        return await this.baseJson("logseq.Editor.updateBlock", [
          block2.uuid,
          block2.content
        ]);
      };
    }
    async catchIssues(func) {
      try {
        return await func();
      } catch (e2) {
        console.info(1, e2);
        if (e2.status === 401) {
          return TokenNotCurrect;
        } else if (e2.toString() === "TypeError: Failed to fetch" || e2.toString().includes("Invalid URL")) {
          return CannotConnectWithLogseq;
        } else if (e2 === LogseqVersionIsLower || e2 === NoSearchingResult) {
          return e2;
        } else {
          return UnknownIssues;
        }
      }
    }
  };

  // src/pages/logseq/db/service.ts
  var LogseqDBService = class {
    constructor() {
      this.client = new LogseqClient();
    }
    async getGraph() {
      return (await this.client.getGraph()).name.replace("logseq_db_", "");
      ;
    }
    async showMsg(message) {
      return await this.client.showMsg(message);
    }
    async getVersion() {
      return (await this.client.getVersion()).version;
    }
    async searchGraph(graphName, query) {
      const resp = await this.client.search(query);
      const response = {
        blocks: [],
        pages: [],
        count: 0,
        graph: graphName
      };
      response.pages = await Promise.all(
        resp.blocks.filter((item) => item["page?"] === true).map(async (item) => {
          return await this.client.getPage({
            uuid: item["block/uuid"]["uuid"]
          });
        })
      );
      response.blocks = await Promise.all(
        resp.blocks.filter((item) => item["page?"] === false).map(
          async (item) => await this.getBlock(item["block/uuid"]["uuid"], graphName, query)
        )
      );
      return response;
    }
    async search(query) {
      const graph = await this.getGraph();
      console.debug(`DG Graph Name: ${graph}`);
      const resp = {
        msg: "success",
        status: 200,
        response: await this.searchGraph(graph, query)
      };
      return resp;
    }
    async getBlock(blockUuid, graph, query, includeChildren = false) {
      const block2 = await this.client.getBlockViaUuid(blockUuid, {
        includeChildren
      });
      block2.page = await this.client.getPage(block2.page);
      return renderBlock(block2, graph, query);
    }
    async urlSearch(url, opt = { fuzzy: false }) {
      const graph = await this.getGraph();
      const blockUuidSet = /* @__PURE__ */ new Set();
      const blocks = [];
      const blockAdd = (block2) => {
        if (blockUuidSet.has(block2.uuid)) {
          return;
        }
        blockUuidSet.add(block2.uuid);
        blocks.push(block2);
      };
      const find = async (url2) => {
        const results = await this.searchGraph(graph, url2);
        results.blocks.forEach(blockAdd);
      };
      if (url.pathname) {
        await find(url.host + url.pathname);
      }
      const count = blocks.length;
      if (url.host && opt.fuzzy) {
        await find(url.host);
      }
      return {
        status: 200,
        msg: "success",
        response: {
          blocks: blocks.map((block2) => {
            return renderBlock(block2, graph, url.href);
          }),
          graph
        },
        count
      };
    }
    async changeBlockMarker(uuid, marker) {
      const graph = await this.getGraph();
      const block2 = await this.getBlock(uuid, graph);
      if (block2.content.includes("SCHEDULED:")) {
        return {
          type: "change-block-marker-result",
          uuid,
          status: "failed",
          msg: "Not support scheduled task."
        };
      }
      block2.content = block2.content.replace(block2.marker, marker);
      const result = await this.client.updateBlock(block2);
      console.debug(result);
      if (Object.hasOwnProperty(result, "error")) {
        return {
          type: "change-block-marker-result",
          uuid,
          status: "failed",
          msg: "error"
        };
      }
      return {
        type: "change-block-marker-result",
        uuid,
        status: "success",
        marker
      };
    }
  };

  // src/pages/logseq/normal/client.ts
  var LogseqClient2 = class extends LogseqClientBase {
    constructor() {
      super(...arguments);
      this.getCurrentGraph = async () => {
        return await this.baseJson("logseq.getCurrentGraph", []);
      };
      this.appendBlock = async (page, content) => {
        const resp = await this.baseJson("logseq.Editor.appendBlockInPage", [
          page,
          content
        ]);
        return resp;
      };
      this.getCurrentPage = async () => {
        return await this.catchIssues(async () => {
          return await this.baseJson("logseq.Editor.getCurrentPage", []);
        });
      };
      this.getAllPage = async () => {
        return await this.baseJson("logseq.Editor.getAllPages", []);
      };
      this.getPage = async (pageIdenity) => {
        const resp = await this.baseJson(
          "logseq.Editor.getPage",
          [pageIdenity.id || pageIdenity.uuid || pageIdenity.name]
        );
        return resp;
      };
      this.getPageDB = async (pageIdenity) => {
        const resp = await this.baseJson("get_page", [
          pageIdenity.uuid || pageIdenity.name || pageIdenity.id
        ]);
        return resp;
      };
      this.search = async (query) => {
        const resp = await this.baseJson("logseq.App.search", [query]);
        if (resp.error) {
          throw LogseqVersionIsLower;
        }
        return resp;
      };
      this.getBlockViaUuid = async (uuid, opt) => {
        return await this.baseJson("logseq.Editor.getBlock", [uuid, opt]);
      };
      this.getBlockViaUuidDB = async (uuid, opt) => {
        return await this.baseJson("get_block", [uuid, opt]);
      };
      this.isDBGraph = async () => {
        return await this.baseJson("check_current_is_db_graph", []);
      };
      this.showMsgInternal = async (message) => {
        await this.baseFetch("logseq.showMsg", [message]);
        return {
          status: 200,
          msg: "success",
          response: null
        };
      };
      this.getVersionInternal = async () => {
        return await this.baseJson("logseq.App.getAppInfo", []);
      };
      this.find = async (query) => {
        const data = await this.baseJson("logseq.DB.q", [
          `"${query.replaceAll('"', '"')}"`
        ]);
        return data;
      };
      this.getUserConfig = async () => {
        return await this.catchIssues(
          async () => await this.baseJson("logseq.App.getUserConfigs", [])
        );
      };
      this.showMsg = async (message) => {
        return await this.catchIssues(
          async () => await this.showMsgInternal(message)
        );
      };
      this.getAllPages = async () => {
        return await this.catchIssues(async () => await this.getAllPage());
      };
      this.getGraph = async () => {
        return await this.catchIssues(async () => await this.getCurrentGraph());
      };
      this.getVersion = async () => {
        return await this.catchIssues(async () => await this.getVersionInternal());
      };
      this.updateBlock = async (block2) => {
        console.log(block2.content);
        return await this.baseJson("logseq.Editor.updateBlock", [
          block2.uuid,
          block2.content
        ]);
      };
    }
    async catchIssues(func) {
      try {
        return await func();
      } catch (e2) {
        console.info(e2);
        if (e2.status === 401) {
          return TokenNotCurrect;
        } else if (e2.toString() === "TypeError: Failed to fetch" || e2.toString().includes("Invalid URL")) {
          return CannotConnectWithLogseq;
        } else if (e2 === LogseqVersionIsLower || e2 === NoSearchingResult) {
          return e2;
        } else {
          return UnknownIssues;
        }
      }
    }
  };

  // src/pages/logseq/normal/service.ts
  var LogseqService = class {
    constructor() {
      this.client = new LogseqClient2();
    }
    async getGraph() {
      return (await this.client.getGraph()).name;
    }
    async showMsg(message) {
      return await this.client.showMsg(message);
    }
    async getVersion() {
      return (await this.client.getVersion()).version;
    }
    async searchGraph(graphName, query) {
      const result = await this.client.search(query);
      result.blocks = await Promise.all(
        result.blocks.map(async (block2) => {
          return await this.getBlock(block2["block/uuid"], graphName, query);
        })
      );
      result.pages = await Promise.all(
        result.pages.map(async (page) => {
          return await this.client.getPage({
            name: page
          });
        })
      );
      result.count = result.blocks.length + result.pages.length;
      result.graph = graphName;
      return result;
    }
    async search(query) {
      const graph = await this.getGraph();
      console.debug(`Normal Graph Name: ${graph}`);
      const resp = {
        msg: "success",
        status: 200,
        response: await this.searchGraph(graph, query)
      };
      return resp;
    }
    async getBlock(blockUuid, graph, query, includeChildren = false) {
      const block2 = await this.client.getBlockViaUuid(blockUuid, {
        includeChildren
      });
      block2.page = await this.client.getPage(block2.page);
      return renderBlock(block2, graph, query);
    }
    async urlSearch(url, opt = { fuzzy: false }) {
      const graph = await this.getGraph();
      const blockUuidSet = /* @__PURE__ */ new Set();
      const blocks = [];
      const blockAdd = (block2) => {
        if (blockUuidSet.has(block2.uuid)) {
          return;
        }
        blockUuidSet.add(block2.uuid);
        blocks.push(block2);
      };
      const find = async (url2) => {
        const results = await this.client.find(url2);
        results.forEach(blockAdd);
      };
      if (url.hash) {
        await find(url.host + url.pathname + url.search + url.hash);
      }
      if (url.search) {
        await find(url.host + url.pathname + url.search);
      }
      if (url.pathname) {
        await find(url.host + url.pathname);
      }
      const count = blocks.length;
      if (url.host && opt.fuzzy) {
        await find(url.host);
      }
      return {
        status: 200,
        msg: "success",
        response: {
          blocks: blocks.map((block2) => {
            return renderBlock(block2, graph, url.href);
          }),
          graph
        },
        count
      };
    }
    async changeBlockMarker(uuid, marker) {
      const graph = await this.getGraph();
      const block2 = await this.getBlock(uuid, graph);
      if (block2.content.includes("SCHEDULED:")) {
        return {
          type: "change-block-marker-result",
          uuid,
          status: "failed",
          msg: "Not support scheduled task."
        };
      }
      block2.content = block2.content.replace(block2.marker, marker);
      const result = await this.client.updateBlock(block2);
      console.debug(result);
      if (Object.hasOwnProperty(result, "error")) {
        return {
          type: "change-block-marker-result",
          uuid,
          status: "failed",
          msg: "error"
        };
      }
      return {
        type: "change-block-marker-result",
        uuid,
        status: "success",
        marker
      };
    }
  };

  // src/pages/logseq/tool.ts
  var client = new LogseqClientBase();
  var logseqServiceDB = new LogseqDBService();
  var logseqService = new LogseqService();
  var cleanBlock = (block2) => {
    let result = block2.content;
    if (!result) {
      return "";
    }
    if (block2.marker) {
      result = result.replace(block2.marker, "");
    }
    if (block2.priority) {
      result = result.replace(`[#${block2.priority}]`, "");
    }
    return result.replaceAll(/!\[.*?\]\(\.\.\/assets.*?\)/gim, "").replaceAll(/^[\w-]+::.*?$/gim, "").replaceAll(/{{renderer .*?}}/gim, "").replaceAll(/^deadline: <.*?>$/gim, "").replaceAll(/^scheduled: <.*?>$/gim, "").replaceAll(/^:logbook:[\S\s]*?:end:$/gim, "").replaceAll(/^:LOGBOOK:[\S\s]*?:END:$/gim, "").replaceAll(/\$pfts_2lqh>\$(.*?)\$<pfts_2lqh\$/gim, "<em>$1</em>").replaceAll(/{{video .*?}}/gm, "").replaceAll(/^\s*?-\s*?$/gim, "").trim();
  };
  var highlightTokens = (query) => {
    const re = new RegExp(`^(?!<mark>)${query}(?!</mark>)`, "g");
    return (token) => {
      if (token.type !== "code" && token.type !== "codespan" && token.type !== "logseqLink" && token.text) {
        token.text = query ? token.text.replaceAll(re, "<mark>" + query + "</mark>") : token.text;
      }
    };
  };
  var logseqLinkExt = (graph, query) => {
    return {
      name: "logseqLink",
      level: "inline",
      tokenizer: function(src) {
        const match2 = src.match(/^#?\[\[(.*?)\]\]/);
        if (match2) {
          return {
            type: "logseqLink",
            raw: match2[0],
            text: match2[1],
            href: match2[1].trim(),
            tokens: []
          };
        }
        return false;
      },
      renderer: function(token) {
        const { text, href } = token;
        const fillText = query ? text.replaceAll(query, "<mark>" + query + "</mark>") : text;
        return `<a class="logseq-page-link" href="logseq://graph/${graph}?page=${href}"><span class="tie tie-page"></span>${fillText}</a>`;
      }
    };
  };
  var renderBlock = (block2, graphName, query) => {
    const cleanContent = cleanBlock(block2);
    marked.use({
      gfm: true,
      tables: true,
      walkTokens: query ? highlightTokens(query) : void 0,
      extensions: [logseqLinkExt(graphName, query)]
    });
    const html = marked.parse(cleanContent).trim();
    block2.html = html;
    return block2;
  };
  var getLogseqService = async () => {
    try {
      const resp = await client.isDBGraph();
      if (resp === "true" || resp === true || resp === false) {
        return logseqServiceDB;
      }
    } catch (error) {
    }
    return logseqService;
  };

  // src/pages/background/index.ts
  browser2.runtime.onConnect.addListener((port) => {
    port.onMessage.addListener((msg) => {
      if (msg.type === "query") {
        const promise = new Promise(async () => {
          const logseqService2 = await getLogseqService();
          const searchRes = await logseqService2.search(msg.query);
          console.debug("search result", searchRes);
          port.postMessage(searchRes);
        });
        promise.catch((err) => console.error(err));
      } else if (msg.type === "open-options") {
        browser2.runtime.openOptionsPage();
      } else {
        console.debug(msg);
      }
    });
  });
  browser2.runtime.onMessage.addListener((msg, sender) => {
    if (msg.type === "open-options") {
      browser2.runtime.openOptionsPage();
    } else if (msg.type === "clip-with-selection") {
      quickCapture(msg.data);
    } else if (msg.type === "clip-page") {
      quickCapture("");
    } else if (msg.type === "open-page") {
      openPage(msg.url);
    } else if (msg.type === "change-block-marker") {
      changeBlockMarker(msg.uuid, msg.marker);
    } else {
      console.debug(msg);
    }
  });
  var changeBlockMarker = async (uuid, marker) => {
    const tab = await getCurrentTab();
    if (!tab) {
      return;
    }
    const logseqService2 = await getLogseqService();
    const result = await logseqService2.changeBlockMarker(uuid, marker);
    browser2.tabs.sendMessage(tab.id, result);
  };
  var getCurrentTab = async () => {
    const tab = await browser2.tabs.query({ active: true, currentWindow: true });
    return tab[0];
  };
  var openPage = async (url) => {
    console.debug(url);
    const tab = await getCurrentTab();
    if (!tab) {
      browser2.tabs.create({ url });
      return;
    }
    const activeTab = tab;
    if (activeTab.url !== url)
      await browser2.tabs.update(activeTab.id, { url });
  };
  var quickCapture = async (data) => {
    const tab = await getCurrentTab();
    if (!tab)
      return;
    const activeTab = tab;
    const { clipNoteLocation, clipNoteCustomPage, clipNoteTemplate } = await getLogseqCopliotConfig();
    const now = /* @__PURE__ */ new Date();
    const logseqService2 = await getLogseqService();
    const resp = await logseqService2.client.getUserConfig();
    const block2 = blockRending({
      url: activeTab.url,
      title: activeTab.title,
      data,
      clipNoteTemplate,
      preferredDateFormat: resp["preferredDateFormat"],
      time: now
    });
    if (clipNoteLocation === "customPage") {
      await logseqService2.client.appendBlock(clipNoteCustomPage, block2);
    } else if (clipNoteLocation === "currentPage") {
      const { name: currentPage } = await logseqService2.client.getCurrentPage();
      await logseqService2.client.appendBlock(currentPage, block2);
    } else {
      const journalPage = format(now, resp["preferredDateFormat"]);
      await logseqService2.client.appendBlock(journalPage, block2);
    }
    debounceBadgeSearch(activeTab.url, activeTab.id);
  };
  browser2.tabs.onActivated.addListener((activeInfo) => {
    const promise = new Promise(async () => {
      const tab = await browser2.tabs.get(activeInfo.tabId);
      await debounceBadgeSearch(tab.url, activeInfo.tabId);
    });
    promise.catch((err) => console.error(err));
  });
  browser2.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.active && changeInfo.status === "complete") {
      const promise = new Promise(async () => {
        await debounceBadgeSearch(tab.url, tabId);
      });
      promise.catch((err) => console.error(err));
    }
  });
  var badgeSearch = async (url, tabId) => {
    if (!url)
      return;
    const searchURL = new URL(url);
    const logseqService2 = await getLogseqService();
    const searchRes = await logseqService2.urlSearch(searchURL);
    const resultCount = searchRes.count ? searchRes.count.toString() : "";
    await setExtensionBadge(resultCount, tabId);
  };
  var debounceBadgeSearch = debounce(badgeSearch, 1e3);
  try {
    browser2.contextMenus.create({
      id: "clip-with-selection",
      title: 'Clip "%s"',
      visible: true,
      contexts: ["selection"]
    });
  } catch (error) {
    console.log(error);
  }
  try {
    browser2.contextMenus.create({
      id: "clip-page",
      title: "Clip page link",
      visible: true,
      contexts: ["page"]
    });
  } catch (error) {
    console.log(error);
  }
  browser2.contextMenus.onClicked.addListener((info, tab) => {
    browser2.tabs.sendMessage(tab.id, { type: info.menuItemId }, {});
  });
  browser2.runtime.onInstalled.addListener((event) => {
    if (event.reason === "install") {
      browser2.runtime.openOptionsPage();
    } else if (event.reason === "update") {
      if (versionCompare(event.previousVersion, "1.10.19") < 0) {
        changeOptionsHostToHostNameAndPort();
      }
    }
  });
  browser2.commands.onCommand.addListener((command, tab) => {
    if (command === "clip" && tab !== void 0) {
      browser2.tabs.sendMessage(tab.id, { type: "clip" });
    }
  });
  async function setExtensionBadge(text, tabId) {
    await browser2.action.setBadgeText({
      text,
      tabId
    });
    await browser2.action.setBadgeBackgroundColor({ color: "#4caf50", tabId });
    await browser2.action.setBadgeTextColor({ color: "#ffffff", tabId });
  }
})();
